---
name: seo-body-content
description: Use this skill whenever a partner page needs body copy written to match a technical SEO package that's already been produced. Takes the seo-technical-package output (H1, H2/H3 outline, internal linking plan, FAQ set, image slots, primary and secondary keywords) plus the partner profile (sourced from Airtable) and produces the full body copy for the page. Critically, honors the internal linking plan exactly — every specified link appears in the copy with the specified anchor text in the specified placement section. Produces markdown output by default (HTML on request). Do NOT use this skill to generate the technical wrapper (use seo-technical-package first), to decide what pages to create (use seo-strategy-light), or to invent partner-specific claims not documented in the partner profile.
---

# SEO Body Content

This skill writes the body copy for a partner page after the technical SEO package has been produced. The skill extends the technical package's structural skeleton — it does not replace or override it. Every structural decision (H1, H2s, H3s, internal links, FAQ questions, keyword placement) is inherited from the technical package; this skill fills in the paragraphs.

The skill's value is threefold: it produces copy that matches the partner's voice, it honors the internal linking plan exactly, and it avoids the common AI-generated tells that make content read as machine-written.

## When to use this skill

Activate when a partner page has an approved technical package (from `seo-technical-package`) and needs body copy written. Specifically:

- After the technical package JSON has been produced and reviewed
- Before publishing to the CMS (body copy and technical wrapper both need to ship together)
- When refreshing an existing page's copy (re-run against the existing page's technical package)

Do not use for:
- Generating the technical wrapper → `seo-technical-package`
- Deciding what pages to create → `seo-strategy-light`
- Writing outreach emails → `seo-outreach-draft`
- Analytical questions or reporting → `seo-reporting-analyst`
- Writing blog posts without a pre-approved outline (pitch the outline through strategy first)

## Required inputs

1. **Technical package output** (object — full JSON from `seo-technical-package`)
   - This is the single most important input. The body content skill reads this and extends it.
   - Key fields consumed: `h1`, `headers.h2_list` (including H3s per H2), `internal_links`, `image_specs`, and the schema's FAQPage questions (if present)
   - The skill never overrides or ignores fields from the technical package. If something in the technical package is wrong, fix it there and regenerate — don't work around it in body content.

2. **Partner profile** (object — sourced from Airtable)
   - Pulled from the partner's Airtable record via the connector
   - Required fields: `business_name`, `business_type`, `services`, `service_areas`, `primary_location`
   - Strongly recommended fields: `unique_differentiators` (specific, verifiable facts about the partner that can be woven into copy), `brand_voice_notes` (if the partner has defined tone preferences), `years_in_business`, `notable_credentials` (licenses, certifications, memberships)
   - Optional fields: `preferred_CTAs` (how the partner wants users to take action — call, form, book online, etc.), `geographic_context` (local references the partner wants highlighted), `things_to_avoid` (claims or language the partner has asked be excluded)

3. **Target word count** (integer)
   - Usually inherited from the `seo-strategy-light` roadmap; passed through the technical package to this skill
   - Typical ranges: 1,000–1,500 for service pages, 800–1,200 for location pages, 1,200–2,000 for pillar pages, 1,000–1,500 for blog posts
   - The skill targets ±10% of the specified count; documents deviations in `skill_notes`

4. **Output format preference** (optional enum)
   - `markdown` (default) — returned as markdown-formatted text, ready for CMS paste or conversion
   - `html` — returned as HTML, ready for direct paste into WordPress/Webflow without conversion
   - `both` — returned as both formats in the output object

5. **Tone overrides** (optional object)
   - Usually defaults to what's specified in `brand_voice_notes` from the partner profile
   - Can override per-page if the caller wants a different tone than the partner default
   - `formality` (enum: `casual` | `professional` | `formal`, default: `professional`)
   - `person` (enum: `first_plural` — "we, our" | `first_singular` — "I, my" | `third` — "[Business Name] offers...", default: `first_plural`)
   - `reading_level` (enum: `conversational` | `informed_layperson` | `technical`, default: `informed_layperson`)

## Output format

Return a single JSON object:

```json
{
  "body_content": "string — the full body copy in the requested format (markdown by default)",
  "body_content_html": "string — only populated if format is 'html' or 'both'",

  "linking_plan_execution_report": {
    "all_links_placed": "boolean — true if every link from the technical package's internal_links appears in the body",
    "links_placed": [
      {
        "destination_url": "string",
        "anchor_text_used": "string — the exact anchor text as it appears in the body",
        "placement_section": "string — which H2 section the link appears in",
        "matches_plan": "boolean — true if placement and anchor text match the technical package's specification"
      }
    ],
    "links_not_placed": ["array of destination URLs that couldn't be placed, with reasons"]
  },

  "image_slots_in_copy": [
    {
      "position": "string",
      "placement_note": "string — where in the markdown the image slot reference appears, e.g. 'before the Services Overview H2'"
    }
  ],

  "word_count": "integer",

  "faq_answers_included": "boolean — true if FAQPage questions from technical package all have answers in the body",

  "skill_notes": {
    "voice_applied": "string — description of voice calibration used",
    "partner_differentiators_used": ["array of unique_differentiators that made it into copy"],
    "partner_differentiators_not_used": ["array of unique_differentiators that didn't fit; with brief reason"],
    "word_count_deviation": "string — if target was 1,200 and output is 1,280, note 'within tolerance'; if significantly off, explain",
    "flags_for_reviewer": ["array of caveats worth surfacing"]
  }
}
```

## Execution procedure

Follow these steps in order.

1. **Load the execution rules** from `rules/linking_plan_execution.md`. This is the single most important reference — it governs how internal links from the technical package are placed in the body copy. Every internal link must end up in the body copy; the rules file describes the non-negotiable requirements.

2. **Load voice and quality rules** from `rules/voice_and_quality.md` for tone calibration and AI-tell avoidance.

3. **Load factual accuracy rules** from `rules/factual_accuracy.md` for what can and cannot be written about the partner.

4. **Parse the technical package inputs**:
   - Extract H1, H2 list, H3 list per H2 (this is the structural skeleton)
   - Extract `internal_links` array (placement requirements — these MUST all be honored)
   - Extract FAQPage schema questions (these all need answers written)
   - Extract primary_keyword and secondary_keywords (for organic placement in copy)
   - Extract image_specs (for image slot markers)

5. **Parse the partner profile**:
   - Extract unique_differentiators (candidate facts to weave into copy where they fit naturally)
   - Extract brand_voice_notes (tone calibration)
   - Extract geographic_context (local-flavor phrases and references)
   - Extract preferred_CTAs (how CTAs should be phrased)
   - Extract things_to_avoid (hard exclusions)

6. **Write the introduction** (the section before the first H2):
   - Opens with a statement that demonstrates the page is about the target keyword without keyword-stuffing
   - Establishes the partner as a local authority in 1-2 sentences (credential-based, not self-congratulatory)
   - Sets up what the reader will find on the page
   - Typical length: 80-150 words
   - Primary keyword appears naturally in the first paragraph, ideally in the first sentence

7. **Write each H2 section in order**:
   - Section opens with 1-2 sentences establishing what this section covers
   - If there are H3s within the H2, write them as subsections with 2-4 sentences each
   - If no H3s, write the H2 as 2-4 cohesive paragraphs
   - Each H2 section is typically 150-300 words depending on target word count
   - Internal links from the plan are placed as specified — see linking plan execution rules
   - Images referenced as markdown image syntax with descriptive filename and alt text

8. **Write the FAQ section** (if FAQPage schema is present in the technical package):
   - FAQ section uses an H2 labeled "Frequently Asked Questions" or similar
   - Each FAQ question becomes an H3
   - Each answer is 2-4 sentences, written in a direct conversational tone
   - Answers must be partner-accurate — if the technical package's FAQ question requires partner-specific data (pricing, warranty length, response time) the skill only includes that data if it's in the partner profile
   - Questions are written exactly as they appear in the technical package's FAQPage schema (to match visible content with schema content)

9. **Write the closing** (the section after the last major H2, before any final CTA):
   - Short — typically 50-100 words
   - Reinforces the partner's value without repeating earlier content verbatim
   - Includes a preferred CTA from the partner profile (call, form, book, quote request, etc.)

10. **Execute the internal linking plan check**:
    - Before returning output, verify every link in the technical package's `internal_links` array appears in the body copy
    - Verify each link's anchor text matches the specified anchor text (or one of the anchor_text_variants)
    - Verify each link's placement section matches the specified `placement_note`
    - Populate `linking_plan_execution_report` with the result
    - If any link could not be placed (e.g. the specified section doesn't have a natural hook for the link), flag it in `links_not_placed` rather than silently dropping

11. **Verify word count** against target. If significantly off (±15% or more), rewrite to target before finalizing.

12. **Populate `skill_notes`** with:
    - Voice calibration description
    - Partner differentiators used in copy (from unique_differentiators field)
    - Partner differentiators not used (with brief reason)
    - Any flags for reviewer attention

13. **Return the JSON output**.

## The non-negotiable: honoring the linking plan

This is the single most important thing this skill does well. The technical package's `internal_links` array is not a suggestion. Every link specified there must appear in the body copy, with the specified anchor text (or one of the anchor_text_variants), in the specified placement section.

**Rules summary** (full rules in `rules/linking_plan_execution.md`):

1. **Every internal link from the plan appears in the body**. No exceptions. If a sentence can't naturally accommodate the link, rewrite the surrounding content until it can.
2. **Anchor text must match the specified anchor text exactly** (or match one of `anchor_text_variants` if provided). No "click here," no substitutions, no paraphrasing.
3. **Placement must match the specified section**. If the plan says "in the Services section," the link goes in the Services section, not the introduction or conclusion.
4. **No more than two internal links per paragraph**. Consecutive sentences should not both contain internal links.
5. **One link per destination, one placement**. The same destination URL should not be linked multiple times in the body.
6. **Natural integration**. Links are woven into sentences, not dropped as bare URLs or "Click here" phrases.

If a link genuinely cannot be placed naturally in the specified section (very rare), document in `links_not_placed` with reason. This is a failure state that requires engineer review — it should almost never happen.

## Voice calibration principles

The skill produces copy that sounds like a real local service business wrote it. Guidance:

- **Concrete over abstract**. "Our team has repaired over 3,000 Denver roofs since 2012" beats "We have extensive experience in roofing services."
- **Specific over vague**. "Repairs start at $400 for minor damage and scale with the scope of work" beats "Our pricing is competitive."
- **Direct over hedged**. "We install only GAF-certified shingles" beats "We endeavor to use high-quality materials when possible."
- **Local over generic**. "Denver's hail season can produce golf-ball-sized stones" beats "Severe weather can cause roof damage."
- **Partner-person over business-entity**. "Our owner Jim has inspected every roof we've replaced" beats "Mile High Roofing Co. prides itself on quality."

See `rules/voice_and_quality.md` for detailed tone guidance, including formality variants, person variants (first-plural vs. third-person), and reading-level variants.

## Anti-patterns the skill avoids

Common AI-generated content tells that the skill recognizes and avoids:

- **"In today's world of..." / "In the modern era..."** — corporate-filler openers
- **"When it comes to [topic]..."** — filler transition phrase
- **"Look no further than [partner]"** — cliché marketing phrasing
- **"[Partner] understands that..."** — condescending and generic
- **"At [Partner], we pride ourselves on..."** — self-congratulatory opener
- **Excessive adjective stacking**: "professional, reliable, experienced, trusted"
- **Promising universal excellence**: "we handle every type of roof perfectly" — unverifiable hyperbole
- **Repetitive keyword insertion**: "Our roof repair Denver services offer roof repair in Denver for all Denver homeowners needing roof repair" (keyword stuffing)
- **Weak transitions**: "Furthermore," "Moreover," "Additionally" at the start of paragraphs — reads as templated
- **Fake urgency**: "Don't wait until it's too late!" — manipulative framing

See `rules/voice_and_quality.md` for the full list.

## Factual accuracy constraints

The skill is strict about what it will and will not claim about the partner:

- **Never invents partner-specific facts.** Pricing, warranty length, response time, years in business, certifications — these only appear in copy if they're in the partner profile.
- **Never makes competitive claims without backing.** "Best roofer in Denver" is not a claim the skill makes unless it's in `unique_differentiators` with evidence (specific awards, third-party rankings, etc.).
- **Never promises outcomes.** "We guarantee you'll love your new roof" is out; "Our work is backed by [specific warranty from partner profile]" is in, if that warranty is documented.
- **Never claims certifications or credentials unless provided.** If `notable_credentials` is empty, the copy does not mention certifications.
- **Never references specific prices unless provided.** Generic ranges OK if framed as approximate ("repairs typically fall between $X and $Y"), but only if those ranges are in the partner profile.

See `rules/factual_accuracy.md` for the full rule set.

## Constraints and guardrails

- **The skill writes body copy only.** It does not modify the technical package's structural decisions (H1, H2s, H3s, internal linking plan, schema). If those need changes, regenerate the technical package first.
- **The skill cannot invent the absent.** If the partner profile is thin, the copy will be more generic. The skill flags this in `skill_notes` rather than fabricating to compensate.
- **The skill does not generate images** — it marks where image slots go in the markdown so the engineer can insert them at publish time. Actual image production/selection is out of scope.
- **The skill does not publish content** — output is markdown (or HTML) for the engineer to review and paste into the CMS manually.
- **The skill does not override the technical package under any circumstances.** If something in the technical package seems wrong, flag it in `flags_for_reviewer`; don't work around it.

## Reference files

- `rules/linking_plan_execution.md` — THE critical rules file for honoring the technical package's internal linking plan
- `rules/voice_and_quality.md` — voice calibration, anti-patterns, tone variants
- `rules/factual_accuracy.md` — what can and cannot be claimed about the partner
- `examples/service_page_body_example.json` — worked example showing how the body content skill extends a technical package output, with full linking plan execution report
