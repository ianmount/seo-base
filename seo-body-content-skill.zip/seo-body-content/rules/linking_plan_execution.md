# Internal Linking Plan Execution

The single most important reference in the `seo-body-content` skill. When the main SKILL.md is ambiguous about how to handle internal links, this file is the source of truth.

The technical package's `internal_links` array represents decisions already made in strategy. Those decisions don't get overridden in body content. They get executed.

---

## The core commitment

**Every link specified in the technical package's `internal_links` array appears in the body copy. No exceptions without explicit documentation.**

This is not a preference or a best effort. It is a hard requirement. The skill's `linking_plan_execution_report.all_links_placed` field is the audit of whether this commitment was met.

---

## The five non-negotiable rules

### Rule 1: Every link is placed

Every destination URL in the technical package's `internal_links` array appears in the body copy. If a planned link cannot be placed naturally in the specified section, the skill rewrites the surrounding content until it can. Dropping a planned link is a failure state, not a stylistic choice.

The only acceptable reason for a link not being placed is a genuine impossibility — the section doesn't exist in the outline, or the destination URL is malformed, or similar. These cases go in `links_not_placed` with explicit reason and are surfaced for engineer review.

### Rule 2: Anchor text matches exactly (or one of the provided variants)

The technical package specifies `suggested_anchor_text` and optionally `anchor_text_variants`. The skill uses the `suggested_anchor_text` by default. If multiple occurrences of a related concept in the copy make exact repetition awkward, the skill may substitute one of the `anchor_text_variants`. Never both variants in the same page; never invented variants.

Never use "click here," "learn more," "read more," or similar non-descriptive anchors. These fail the linking plan even if the link is in the right section.

### Rule 3: Placement matches the specified section

The technical package specifies `placement_note` for each link — e.g. "first paragraph," "in the Services section," "closing CTA section." The skill places the link in that section.

If the planned section doesn't exist in the outline (possible if the H2 list has changed since the technical package was generated), that's a failure state requiring re-generation of the technical package — not a workaround.

### Rule 4: No more than two internal links per paragraph

Even when multiple links are specified for the same section, they do not stack up in a single paragraph. Over-linked paragraphs read as AI-generated SEO content. Spread links across paragraphs or, if a section genuinely needs multiple links, split the section into multiple paragraphs first.

Consecutive sentences should not both contain internal links, even if the two links fit naturally in each. Break them apart with a link-free sentence between.

### Rule 5: One link per destination, one placement

The same destination URL appears exactly once in the body copy. Don't link the same page multiple times on the partner's own page — dilutes signal and looks manipulative to both Google and users.

If a destination has real reason to be referenced multiple times (e.g. the partner's homepage referenced twice in a location page), only the first reference gets linked; subsequent references are plain text or use the partner's brand name without a link.

---

## How to execute links naturally

### Integrate into the surrounding sentence

Links should feel like natural references, not inserted SEO elements. Compare:

**Bad** (link feels bolted on):
> The roof repair process starts with an inspection. [Our full roofing services](link) include more than just repair.

**Good** (link integrated into sentence flow):
> Beyond repair, [our full roofing services](link) cover replacement, gutter installation, and storm damage response across the Denver metro.

### Use the anchor text as a grammatical element

The anchor text should function as a noun phrase, noun, or verb phrase in the sentence — not as an orphan clause or a standalone mention.

**Bad** (anchor text dangles):
> For more information, see [our gutter services page](link).

**Good** (anchor text is part of the sentence):
> Partners often pair roof repairs with [new gutter installation](link) when existing gutters are showing wear.

### Keep placement contextually appropriate

If the `placement_note` says "first paragraph," the link goes in the first paragraph after the H1 or the first paragraph of the section named in the note — not "somewhere near the top."

If the `placement_note` says "in the Services Overview section," the link goes under that specific H2 heading. Not under a nearby H2 that seems related.

### Vary anchor text across occurrences to the same destination

This rule applies across the site, not within a single page (where Rule 5 caps occurrences at one). When the caller is generating body copy for multiple partner pages that link to the same destination, the skill uses different variants from `anchor_text_variants` across the pages.

Since this skill runs on one page at a time, it doesn't have visibility into other pages' anchor choices. The variation responsibility sits with the technical package, which provides `anchor_text_variants` explicitly for this purpose. The body content skill picks the suggested anchor by default and only deviates for within-page grammatical reasons.

---

## The execution report

After writing the body copy, the skill generates a `linking_plan_execution_report` that documents what happened. This report is the audit trail. It includes:

```json
{
  "all_links_placed": true,
  "links_placed": [
    {
      "destination_url": "https://example.com/services/",
      "anchor_text_used": "our full roofing services",
      "placement_section": "Introduction (first paragraph)",
      "matches_plan": true
    },
    {
      "destination_url": "https://example.com/services/roof-replacement/",
      "anchor_text_used": "full roof replacement",
      "placement_section": "When Repair Isn't Enough (H3 subsection)",
      "matches_plan": true
    }
  ],
  "links_not_placed": []
}
```

When `all_links_placed` is false, the skill has failed its core job and the engineer must review. Ideally, this field is always true.

---

## Common execution errors to avoid

### Using "click here" or "learn more"

Never. Always use the specified anchor text. These generic phrases strip the link of topical signal and are a common AI-generated content tell.

### Linking the anchor text at a word boundary

Wrong:
> We also offer [full roof replacement](link) services.

Right:
> We also offer [full roof replacement services](link). (if the anchor text variant is "full roof replacement services")

OR:
> Our team also handles [full roof replacement](link). (if the anchor text variant is "full roof replacement")

Match the exact character range of the specified anchor text.

### Dropping a link because the sentence "doesn't flow"

Never. Rewrite the sentence. The linking plan is not optional based on writing convenience.

### Linking the partner's own homepage in body copy

Rare edge case — the partner's homepage is linked from headers, footers, and navigation; linking it in body copy is usually redundant. If the technical package's linking plan specifies a homepage link, place it once. If it doesn't, don't add one.

### Linking to noindex or disallowed pages

The technical package should never specify a link to a noindex page, but if the caller provides one, the skill places the link as specified and flags the concern in `flags_for_reviewer`.
