# Factual Accuracy Rules

What can and cannot be claimed about the partner. This file is the source of truth when the skill is tempted to fill gaps in the partner profile with plausible-sounding details.

---

## The central rule

**If it's not in the partner profile, don't say it.**

Every partner-specific claim in body copy — years in business, number of jobs completed, certifications, warranty terms, response times, service areas, pricing, awards, memberships — must be sourced from a specific field in the partner profile. The skill never fills gaps with plausible inventions.

This is not a stylistic preference. Partner-facing claims that turn out to be wrong damage trust with the partner (who knows their own business) and with their customers (who may rely on the claims when making purchasing decisions). The cost of a single fabrication outweighs the cost of many generic-but-honest paragraphs.

---

## What requires a source field

### Years in business / founding date

- **Allowed with source**: "Since 2012" or "We've been serving Denver roofers for over 12 years" — if `years_in_business` or `founding_date` is populated
- **Not allowed without source**: "For years," "For decades," "For a generation" — these imply specific duration without documentation

### Number of jobs / projects completed

- **Allowed with source**: "3,000+ roofs repaired" — if this number is in `unique_differentiators` or equivalent
- **Not allowed without source**: "Hundreds of satisfied customers," "Thousands of completed projects" — these are numeric claims that need documentation

### Certifications and credentials

- **Allowed with source**: Specific named credentials (CRA certified, BBB A+ rated, GAF Master Elite, licensed and insured with license number) — only if listed in `notable_credentials`
- **Not allowed without source**: "Certified professionals," "Licensed experts," "Industry-recognized" — these imply specific credentials without naming them

### Warranty terms

- **Allowed with source**: Specific warranty details ("10-year workmanship warranty," "lifetime material warranty on GAF shingles") — only if in the partner profile
- **Not allowed without source**: "Backed by a comprehensive warranty," "Our work is guaranteed" — vague warranty language that can't be verified

### Pricing

- **Allowed with source**: Specific ranges or starting prices — only if in the partner profile
- **Allowed without source**: General framings like "Pricing varies by scope" or "We provide free estimates to establish exact pricing"
- **Not allowed without source**: Specific numbers or ranges ("starts at $500," "typically $2,000-$5,000") that aren't documented

### Response times / service level

- **Allowed with source**: "Most emergency calls get a tarp in place within 4 hours" — only if in the partner profile or `unique_differentiators`
- **Not allowed without source**: "Rapid response," "Fastest in the area," "24/7 availability" (unless the partner explicitly documents this)

### Service areas

- **Allowed with source**: Cities listed in `service_areas`
- **Not allowed without source**: Expanding beyond the listed cities, even to adjacent ones the partner "probably" serves

### Competitive superlatives

- **Almost never allowed**: "Best," "#1," "Top-rated," "Most trusted" — require explicit third-party evidence
- **Allowed with specific source**: "Voted Best of Denver Roofers 2024 by Westword" — if that specific award is documented in `unique_differentiators`

### Awards and recognitions

- **Allowed with source**: Named awards with years ("2024 Angie's List Super Service Award")
- **Not allowed without source**: "Award-winning," "Recognized for excellence"

---

## What doesn't require a source field

Some claims are generic enough to local service businesses that they don't require partner-specific documentation:

- General service descriptions ("We repair asphalt shingle, metal, and tile roofs")
- Process descriptions ("A typical repair begins with an on-site assessment")
- Industry knowledge ("Hail damage is often invisible until a leak develops")
- Educational content ("Asphalt shingles typically last 20-30 years depending on climate")
- Geographic context ("Denver's climate includes significant hail, UV, and freeze-thaw stress on roofs")

The rule of thumb: if the claim would apply equally to most roofers in the area, it doesn't need partner-specific documentation. If the claim distinguishes the partner from competitors, it does.

---

## How to handle thin partner profiles

When the partner profile is light on unique_differentiators and notable_credentials, the copy ends up more generic. That's the correct outcome — preferable to invention.

When a thin profile produces generic copy, the skill flags this in `skill_notes.flags_for_reviewer` with something like:

> "Partner profile has limited unique_differentiators; copy leans generic. Partner or MD/MC may want to add specific credentials, job numbers, or differentiation points to strengthen future generation."

This isn't a failure of the skill — it's an accurate signal that the partner profile needs more content.

---

## Things_to_avoid handling

The partner profile's `things_to_avoid` field is a hard exclusion list. Anything in this field:

- Never appears in the copy as positive claim
- Never appears in the copy as negative claim (e.g. if partner says "don't mention specific prices," the copy doesn't say "we don't publish specific prices" either)
- Never appears at all unless the copy explicitly needs to address the topic for accuracy

Common things partners list:
- Specific pricing (even ranges)
- Competitors by name
- Specific installation timelines (due to weather variability)
- Guarantees beyond documented warranty terms
- Claims about specific materials or brands they don't stock

When a linking plan or technical package requires content that conflicts with `things_to_avoid`, flag in `flags_for_reviewer` rather than producing the content.

---

## Testimonial and review handling

- **The skill never writes testimonial quotes.** Testimonials are partner-supplied content, not generated content.
- **The skill can reference that testimonials exist** if `unique_differentiators` or similar fields document specific testimonials — "As one Aurora homeowner put it..." only works if the exact quote is provided.
- **The skill never attributes generic testimonials to made-up names.** "'Great service!' - John S." is fabrication, even if it sounds innocuous.

---

## Reviews and ratings

- **The skill can reference documented review metrics** if they're in the partner profile ("4.8-star average across 200+ Google reviews")
- **The skill never invents review metrics** ("highly rated," "customers love us") if no specific data is documented
- **The skill never claims specific review counts** without documentation

---

## Photos and portfolio claims

- **The skill marks image slots** where the technical package specifies them
- **The skill never describes specific partner projects** (addresses, specific client names, before/after specifics) unless those are documented in the partner profile or provided as case study inputs
- **Generic project framings are OK**: "One recent Denver repair involved a storm-damaged ridge cap that had gone unnoticed for months" is allowed if framed as illustrative, but if the partner profile has real case studies those should be preferred

---

## What to do when the partner profile is clearly wrong

If the partner profile contains something that appears factually incorrect (wrong address, wrong phone number format, service areas that don't match what the technical package implies), the skill:

1. Uses the partner profile value as provided (skill doesn't overrule the source of truth)
2. Flags the discrepancy in `flags_for_reviewer`
3. Does not try to reconcile — that's an engineer/MD decision

The partner profile in Airtable is the source of truth. The skill's job is to use it, not edit it.

---

## The core test

Before any partner-specific claim makes it into the body copy, the skill asks:

> "Can I cite the specific field in the partner profile this claim comes from?"

If yes, the claim goes in the copy.
If no, the claim either (a) is edited to be a generic industry claim that doesn't require partner-specific backing, or (b) is removed entirely.

Every partner-specific claim in the final output should pass this test.
