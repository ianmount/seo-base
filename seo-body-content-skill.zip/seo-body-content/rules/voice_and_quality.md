# Voice and Quality Rules

Tone calibration, anti-patterns to avoid, and quality standards for body content. When SKILL.md is ambiguous about how copy should read, this file is the source of truth.

---

## The central voice principle

**The copy should read like a specific local service business wrote it, not like a marketing agency wrote it about a local service business.**

Marketing agency writing tends toward: abstract value statements, third-person distance, credential inflation, adjective stacking, universal excellence claims. Local service business writing tends toward: concrete specifics, first-person voice, modest credentials stated plainly, direct sentences, honest limitations.

Every voice rule in this file serves this central principle.

---

## Formality variants

### Casual

- First-person plural ("we, our, us")
- Contractions encouraged ("we're," "don't," "it's")
- Shorter sentences, some sentence fragments OK
- Occasional conversational asides ("worth mentioning — this is where most homeowners get surprised")
- Active voice dominant
- Everyday vocabulary; minimal jargon

Example opening:
> Hail in Denver doesn't play around. Most roofs in the metro area see at least one major hail event every five years, and when it happens, the damage usually isn't obvious until a leak shows up months later. We'll walk you through what to look for, what a repair typically costs, and how insurance claims actually work.

### Professional (default)

- First-person plural ("we, our")
- Contractions acceptable but used selectively
- Complete sentences, moderate length
- Informative tone without being academic
- Active voice preferred; passive acceptable when the actor isn't important
- Some domain vocabulary; defined when used

Example opening:
> Denver's climate makes roof damage one of the most common homeowner concerns in the metro area. Between hail season, high-altitude UV exposure, and winter freeze-thaw cycles, even well-maintained roofs eventually need repair work. This page walks through common repair situations, how we approach them, and what homeowners should expect in terms of timeline and cost.

### Formal

- Third-person or first-person plural ("the company," "our team")
- Contractions minimized
- Longer, more structured sentences
- Deferential professional tone
- Active voice preferred but passive more acceptable
- Full professional vocabulary

Example opening:
> Roof repair services in the Denver metropolitan area require specific expertise in the region's unique climate conditions. Hail events, elevated UV exposure, and significant temperature variability each create distinct repair requirements. This page provides a detailed overview of common repair scenarios, our assessment and repair process, and the considerations homeowners typically encounter when engaging roofing services.

---

## Person variants

### First-person plural ("we, our") — default

Natural for most local service businesses. Reads as the business speaking directly to the reader.

> We've repaired more than 3,000 roofs in the Denver metro since 2012, and we handle every job with our own crews — no subcontractors.

### First-person singular ("I, my")

Rare but appropriate for single-operator partners or when the copy is signed by a specific named person.

> I founded Mile High Roofing after fifteen years working for larger contractors, and I still inspect every replacement job personally.

### Third-person ("[Business Name] offers...")

Creates distance from the reader. Use sparingly and only when the partner's brand voice specifically calls for it.

> Mile High Roofing Co. serves the Denver metro area with a full range of roofing services, from minor repairs to complete replacements.

---

## Reading level variants

### Conversational

- Plain English, no jargon
- Assumes no prior knowledge
- Defines any technical terms in context
- Short paragraphs

### Informed layperson (default)

- Assumes the reader is a homeowner doing research
- Uses moderate industry vocabulary (asphalt shingle, flashing, underlayment) without defining every term
- Longer paragraphs acceptable
- Explains technical concepts when relevant but doesn't over-explain

### Technical

- Assumes the reader has some industry familiarity
- Uses full industry vocabulary (IRC code references, specific material specs, underlayment types)
- Appropriate for B2B partners, architects, insurance adjusters, commercial clients
- Rare for standard local service partners — default to informed layperson unless partner profile specifies otherwise

---

## Anti-patterns the skill never produces

These phrases and patterns signal AI-generated content. Avoid all of them.

### Filler openers

- "In today's world of..."
- "In the modern era..."
- "When it comes to..."
- "More than ever before..."
- "In a world where..."
- "As you know..."

### Corporate-speak clichés

- "Look no further than [partner]"
- "At [partner], we pride ourselves on..."
- "[Partner] understands that..."
- "We believe that every homeowner deserves..."
- "[Partner] is committed to providing..."
- "The importance of [topic] cannot be overstated"
- "In this comprehensive guide..."

### Adjective stacking

Three or more qualitative adjectives in sequence reads as AI-generated:

- "professional, reliable, experienced, trusted" — pick one
- "high-quality, premium, top-tier, best-in-class" — pick one
- "expert, skilled, seasoned, knowledgeable" — pick one

### Universal excellence claims

- "We handle every type of roof perfectly"
- "Our service is always exceptional"
- "Every customer is completely satisfied"
- "We never miss a deadline"

Unverifiable absolutes don't build credibility — they erode it. Specific claims build credibility.

### Weak transition phrases

- "Furthermore..."
- "Moreover..."
- "Additionally..."
- "In conclusion..."
- "To sum up..."

These read as templated essay structure. Transitions should emerge from the content, not announce themselves.

### Fake urgency

- "Don't wait until it's too late!"
- "Act now before your roof fails!"
- "Time is of the essence!"
- "Every moment counts!"

Local service business copy is informational and persuasive, not panic-inducing.

### Empty authority claims

- "Trust the experts at..."
- "Our expertise speaks for itself"
- "We are the leading provider of..."

Authority is demonstrated through specifics (years in business, number of jobs completed, named credentials), not asserted.

---

## Specific-over-abstract principle

The single highest-impact quality rule: prefer concrete specifics over abstract generalizations.

### Bad vs. good pairs

| Abstract (bad) | Specific (good) |
|---|---|
| "We have extensive experience" | "We've repaired more than 3,000 Denver roofs since 2012" |
| "Our pricing is competitive" | "Minor repairs start around $400; full replacements range from $8,500 to $22,000 depending on material" |
| "We use high-quality materials" | "We install only GAF-certified shingles with a 50-year manufacturer warranty" |
| "We respond quickly to emergencies" | "For active leaks, we aim to have a tarp in place within 4 hours of your call" |
| "Our team is highly trained" | "Our lead installers each have CRA certification and average 12 years of field experience" |
| "We serve the Denver area" | "We serve Denver, Aurora, Lakewood, Arvada, Centennial, and surrounding areas — typically within a 30-mile radius of central Denver" |

When the partner profile provides specifics, use them. When it doesn't, the copy flags the gap rather than filling with vague placeholder claims.

---

## Keyword placement principles

Target keywords should appear naturally in the body copy, not stuffed. Specifically:

- **Primary keyword appears in the first paragraph**, ideally in the first sentence
- **Primary keyword appears in at least one H2 or H3** (inherited from technical package)
- **Primary keyword appears 2-4 times total in body copy** for a 1,000-1,500 word page (rough density ~0.3-0.5%)
- **Secondary keywords appear at least once each** but don't force them — if they fit, use them; if forcing them hurts readability, skip them and flag in `skill_notes`
- **Never use the exact primary keyword more than 5 times** in any page regardless of length
- **Partial keyword matches count**: "roof repair" appearing as part of "roof repair services" or "our roof repair team" counts as usage

Keyword stuffing is more detectable by Google than most operators realize. The safer heuristic: write the copy as if you didn't know what the keyword was, then verify the keyword appears naturally where you'd expect it. If the copy needs to be edited to insert the keyword, you're probably stuffing.

---

## Paragraph and sentence structure

- **Paragraphs**: 3-5 sentences on average. Occasional 1-2 sentence paragraphs for emphasis OK.
- **Sentences**: mostly 15-25 words. Some shorter, some longer. Variation is important — uniform sentence length reads as AI-generated.
- **Opening sentences**: vary structure. Don't open every paragraph with "We..." or "Our..." or the same subject.
- **Lists**: use when the content is genuinely list-like. Don't turn every third paragraph into a bullet list.

---

## Final quality check

Before returning output, the skill does a final pass asking:

1. Does every paragraph communicate a specific idea (not just words filling space)?
2. Are there any sentences that feel like they could apply to any partner in this industry? (If yes, they're too abstract — revise.)
3. Does the copy reference the partner's actual differentiators and specifics, not just generic industry claims?
4. Is the primary keyword placement natural, or does it feel forced?
5. Are internal links integrated naturally into sentences, not bolted on?
6. Does the closing paragraph/CTA reflect the partner's actual CTA preference (call, form, book, etc.)?

Any "no" answer triggers a revision of the affected section.
