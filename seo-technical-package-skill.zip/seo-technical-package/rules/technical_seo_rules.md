# Technical SEO Rules — Full Reference

Authoritative rules for every element the `seo-technical-package` skill produces. When the main SKILL.md summary is ambiguous, this file is the source of truth.

---

## Title tag

### Length
- **Target:** 50–60 characters displayed length
- **Hard maximum:** 70 characters — beyond this, Google is highly likely to rewrite the title in SERPs, which defeats the optimization
- **Hard minimum:** 30 characters — below this, the title is under-utilizing available ranking real estate

### Structure
- Target keyword appears in the first half of the title
- Brand name at the end, separated by a pipe (`|`) or dash (`—` or `-`)
- Exception: skip the brand name on hyper-competitive keywords where every character counts

### Content rules
- No keyword stuffing (repeating the target keyword or close variants more than once)
- No ALL CAPS words unless a proper noun
- No clickbait phrasing ("You won't believe..." etc.)
- Write for click-through, not just ranking. A title that ranks #3 and gets 20% CTR beats one that ranks #2 and gets 8%

### Uniqueness
- Must be unique per page across the partner site
- The skill cannot verify uniqueness across the site — flag for engineer review in `validation_report` if the site has existing pages that may share similar titles

### Example patterns (good)
- `Roof Repair in Denver | Mile High Roofing Co.`
- `Emergency Plumbing Services — Open 24/7 in Austin`
- `Teeth Whitening Cost & Options in Phoenix | Dr. Smith DDS`

### Example patterns (bad)
- `Roof Repair, Roofing Contractor, Roofers Denver CO` (keyword stuffing)
- `We're the Best Plumbers You'll Ever Find in Austin TX!!!` (unprofessional, over 60 chars)
- `Dental Services` (too short, no keyword specificity, no brand, no location)

---

## Meta description

### Length
- **Target:** 140–160 characters
- **Hard maximum:** 165 characters — Google truncates around this point
- **Hard minimum:** 120 characters — below this is under-utilized

### Structure
- Primary keyword included naturally (not forced)
- Includes a CTA where appropriate: "Get a free estimate," "Book online in 60 seconds," "Serving [city] since [year]," "Call for a same-day quote"
- Describes what the user will find on the page, not what the page does

### Uniqueness
- Unique per page across the partner site
- Never a copy of the page's first sentence

### Important note about Google's behavior
- Google rewrites meta descriptions ~70% of the time, using content from the page that better matches the query
- This is not a failure of your meta description — it's Google's default behavior
- Write a good meta description anyway, because the cases where Google uses it are the ones that matter most (direct URL searches, brand searches, non-query contexts)

### Example patterns (good)
- `Need fast roof repair in Denver? Our certified roofers respond same-day, work with all insurance, and back every job with a 10-year warranty. Free estimates.`
- `Walk-in dental emergencies welcome at Dr. Smith DDS in Phoenix. Same-day appointments for toothaches, broken teeth, and lost fillings. Insurance accepted.`

### Example patterns (bad)
- `We offer the best roofing services.` (too short, no keyword, no CTA)
- `Roof repair Denver roofing contractor roofers Denver CO roofing services...` (keyword stuffing)
- `This page is about roof repair.` (describes the page, not the value)

---

## Canonical URL

### Format
- Absolute URL including protocol (https)
- Trailing slash matches site convention — assume trailing slash unless the caller provides explicit override
- All lowercase

### Self-referencing
- By default, canonical points to the page's own URL (this is correct and expected)
- If the page is an alternate version of another page (pagination, tracking parameters, slight variants), the canonical points to the authoritative version

### Common mistakes to avoid
- Mixing http and https (site should enforce https site-wide)
- Mixing www and non-www (pick one and redirect the other)
- Trailing slash inconsistency across the site

---

## URL slug

### Format
- Lowercase only
- Hyphens between words (not underscores, not spaces, not encoded characters)
- Target keyword included where natural
- Under 75 characters total path where possible
- No parameters (use path structure instead)

### Structure
- Logical hierarchy: `/services/`, `/locations/`, `/blog/` at first level
- Specific page at second level: `/services/roof-repair/`, `/locations/denver/`
- Avoid deep nesting beyond 3 levels

### Example patterns (good)
- `/services/roof-repair/`
- `/locations/denver/`
- `/blog/how-to-choose-a-roofer/`

### Example patterns (bad)
- `/Services/RoofRepair/` (mixed case)
- `/services/roof_repair/` (underscores)
- `/services/page-123/` (no keyword)
- `/services/roof-repair-services-in-denver-colorado-by-mile-high-roofing/` (too long)

---

## Meta robots

### Default
- `index, follow`
- Always explicit in output, never omitted

### Non-default cases
- `noindex, follow` — thank-you pages, cart pages, internal search results, thin tag archives
- `noindex, nofollow` — rare; staging environments
- Never `nofollow` on normal partner pages

---

## H1

### Rules
- Exactly one H1 per page
- Distinct from the title tag (not identical — they serve different purposes)
- Includes or closely matches the target keyword
- 8–12 words ideal, up to 15 acceptable
- Descriptive of page content, not just a keyword dump

### Example (good — for target keyword "roof repair in Denver")
- **Title:** `Roof Repair in Denver | Mile High Roofing Co.`
- **H1:** `Reliable Roof Repair Services for Denver Homeowners`

### Example (bad — identical to title)
- **Title:** `Roof Repair in Denver | Mile High Roofing Co.`
- **H1:** `Roof Repair in Denver | Mile High Roofing Co.`

---

## Header hierarchy (H2/H3/etc.)

### Rules
- H1 → H2 → H3 → H4 — never skip levels (no H1 directly to H3)
- H2s divide the page into major sections
- H3s only appear within an H2
- Use semantic keyword variations where natural (don't repeat the exact target keyword in every H2)
- Descriptive and short, 8–12 words ideal
- Never use headers for visual styling — if something needs to be larger or bolder but isn't structurally a heading, that's a CSS concern

### Example (good — for a roof repair service page)
- H1: `Reliable Roof Repair Services for Denver Homeowners`
  - H2: `Signs You Need a Roof Repair`
    - H3: `Missing or Damaged Shingles`
    - H3: `Water Stains on Ceilings`
  - H2: `Our Roof Repair Process`
    - H3: `Free Inspection and Estimate`
    - H3: `Same-Day Emergency Repairs`
  - H2: `Roof Repair Pricing`
  - H2: `Service Areas Around Denver`

---

## Internal links

### Quantity
- Minimum 2 per page
- Typical 3–5 per page
- Up to 8 on content-heavy pages (pillar pages, long-form blog posts)

### Anchor text rules
- Descriptive and keyword-relevant to the destination page
- Vary anchor text across links pointing to the same destination across the site — rotate through provided variants (`suggested_anchor_text` is one option; `anchor_text_variants` contains rotation options)
- Never 100% exact-match anchor text on any single destination — this is a red flag pattern

### Placement
- At least one link in the first third of the page (early context)
- Contextual within body copy is preferred over a "related links" block
- Include at least one link to a pillar page or top-level service hub

### Avoid
- "Click here," "Learn more," "Read more" as anchor text (non-descriptive)
- Anchor text that doesn't match destination content
- Links that open in new windows by default unless to external sites

---

## Image specs

### Filename
- Lowercase
- Hyphens between words
- Descriptive of image content
- Keyword inclusion where natural (never forced)

### Alt text
- Describes image content for users who cannot see it
- Keyword inclusion only where genuinely relevant
- Never keyword stuffing — alt text like `roof repair denver roofing contractor` is ignored by Google and hurts accessibility
- Good: `Roofer installing asphalt shingles on a residential home in Denver`
- Bad: `roof repair denver roofing contractor roofers`

### Format
- **WebP** — preferred for photos
- **SVG** — for logos and icons
- **JPEG** — acceptable fallback for photos
- **PNG** — only when transparency is required and SVG isn't suitable

### File size
- Body images: under 200KB
- Hero images: up to 500KB
- Any image over 1MB on a production page is a red flag

### Dimensions
- Size to maximum display size, not larger
- Always include explicit width and height to prevent CLS
- Use `<picture>` element or `srcset` for responsive images (recommendation level, implementation is CMS/theme concern)

### Lazy loading
- Native `loading="lazy"` on images below the fold
- Critical above-the-fold images (especially hero) should NOT be lazy-loaded

---

## JSON-LD schema

### Format
- JSON-LD format only (not Microdata, not RDFa)
- Wrapped in `<script type="application/ld+json">` tags
- Placed in the page `<head>` via plugin (Schema Pro, Rank Math) or Embed element (Webflow)

### Required schema by page type

**Homepage**
- `LocalBusiness` with specific subtype (e.g. `Plumber`, `RoofingContractor`, `Dentist`)
- `Organization` (can be combined or separate)

**Service page**
- `Service` referencing the LocalBusiness entity
- `BreadcrumbList`

**Location page**
- `LocalBusiness` with `areaServed` for the specific geographic area, OR a branch/department structure
- `BreadcrumbList`

**Blog post**
- `BlogPosting` or `Article` with author, publisher, datePublished, dateModified
- `BreadcrumbList`

**Any page with an FAQ section**
- `FAQPage` (as a separate JSON-LD block, not merged into the main entity)

**All pages except homepage**
- `BreadcrumbList`

**Optional (only when Review Generation provides data)**
- `Review` / `AggregateRating` — never fabricate this data, never generate from on-site testimonials without verified source

### Validation
- All schema must pass Google Rich Results Test validation
- Schema templates for each type are in `schema_templates/` — use them as the starting structure

### Common mistakes to avoid
- Fabricating `priceRange`, `foundingDate`, `numberOfEmployees`, or any other data not in the partner profile — omit optional fields rather than inventing
- Using deprecated schema types (e.g. `Store` when a more specific `LocalBusiness` subtype exists)
- Mismatch between schema and visible page content (schema says "24/7" but page says "Mon–Fri 8–5")
- Missing required fields (e.g. LocalBusiness without `name` or `address`)

---

## Breadcrumb hierarchy

### Rules
- Match the URL hierarchy exactly
- Start with "Home" at the site root
- End with the current page
- Current page has no URL link (it's the current location)
- Marked up with `BreadcrumbList` schema

### Example (for `/services/roof-repair/`)
1. Home → `https://example.com/`
2. Services → `https://example.com/services/`
3. Roof Repair → (current page, no link)
