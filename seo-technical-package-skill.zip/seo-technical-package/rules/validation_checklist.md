# Self-Validation Checklist

Before returning the final output, the skill runs through this checklist and populates `validation_report` with the result of every check. Every check must have a status of `pass`, `fail`, or `flag_for_review`.

- `pass` — check passed, no engineer attention needed
- `fail` — check failed, skill must regenerate that element and re-check. If regeneration cannot resolve without upstream input changes, set overall `passed: false` on the report
- `flag_for_review` — check cannot be fully validated within the skill (e.g. uniqueness across a partner site); engineer must verify manually

## Title tag
- `title_length` — character count is between 50 and 60 (acceptable range; flag if 45–50 or 60–70, fail if outside 30–70)
- `title_contains_keyword` — target keyword or close variant appears in the title
- `title_keyword_position` — target keyword appears in the first half of the title
- `title_has_brand` — brand name is present, at the end, separated by pipe or dash (unless hyper-competitive keyword exception)
- `title_no_stuffing` — target keyword and close variants appear at most once
- `title_uniqueness` — flag_for_review (cannot verify within skill)

## Meta description
- `meta_length` — character count is between 140 and 160 (acceptable; flag if 130–140 or 160–165, fail if outside 120–165)
- `meta_contains_keyword` — primary keyword appears naturally
- `meta_has_cta` — a CTA phrase is present where appropriate
- `meta_not_body_copy_first_sentence` — flag_for_review (cannot verify without body copy)
- `meta_uniqueness` — flag_for_review (cannot verify within skill)

## Canonical URL
- `canonical_absolute` — starts with `https://`
- `canonical_protocol_https` — uses https, not http
- `canonical_lowercase` — all lowercase
- `canonical_trailing_slash_consistent` — matches the convention specified by caller (default: trailing slash present)
- `canonical_self_referencing` — matches the page's own URL unless page is explicitly an alternate

## URL slug
- `slug_lowercase` — all lowercase
- `slug_hyphens_only` — no underscores, spaces, or encoded characters
- `slug_contains_keyword` — target keyword appears
- `slug_length` — total path length ≤ 75 characters (flag if 60–75, fail if > 75)
- `slug_no_parameters` — no `?param=value` in the path

## Meta robots
- `robots_explicit` — output includes explicit `meta_robots` value
- `robots_standard` — value is `index, follow` unless exception documented

## H1
- `h1_exists` — exactly one H1 in the output
- `h1_distinct_from_title` — H1 is not identical to title tag
- `h1_contains_keyword` — target keyword or close variant appears
- `h1_length` — 8–15 words (flag if < 6 or > 18)

## Header hierarchy
- `hierarchy_no_skips` — no skipped levels (no H1 → H3, no H2 → H4)
- `hierarchy_one_h1` — exactly one H1
- `hierarchy_semantic_variation` — H2s use varied language (not all "Our [keyword] X", "Your [keyword] Y" etc.)

## Internal links
- `links_min_count` — at least 2 internal links
- `links_descriptive_anchors` — no "click here," "learn more," or similar non-descriptive anchors
- `links_anchor_variation` — if multiple links point to the same destination, anchor text varies across them
- `links_no_exact_match_overuse` — no single destination has 100% exact-match target keyword as anchor text

## Image specs
- `image_filenames_lowercase` — all filenames lowercase with hyphens
- `image_alt_descriptive` — alt text describes content, not keyword stuffed
- `image_format_appropriate` — WebP/JPEG/PNG/SVG chosen appropriately
- `image_sizes_reasonable` — max sizes within spec (200KB body, 500KB hero)

## Schema (JSON-LD)
- `schema_exists` — at least one schema block generated
- `schema_valid_json` — JSON is syntactically valid
- `schema_type_appropriate` — schema type(s) match page type per rules
- `schema_required_fields_present` — all required fields for each schema type are populated
- `schema_no_fabrication` — optional fields that require partner-specific data (e.g. `priceRange`, `foundingDate`) are only populated if data was provided in partner profile
- `schema_faq_if_present` — if FAQ set provided, FAQPage schema generated
- `schema_breadcrumb_if_not_homepage` — if page_type is not `homepage`, BreadcrumbList generated
- `schema_localbusiness_subtype_specific` — for LocalBusiness, a specific subtype is used where possible (`Plumber`, `RoofingContractor`, `Dentist`) rather than generic `LocalBusiness`

## Breadcrumb hierarchy
- `breadcrumb_starts_home` — first item is "Home" pointing to site root
- `breadcrumb_ends_current` — last item is the current page
- `breadcrumb_matches_url_hierarchy` — breadcrumb structure matches URL path structure

## Overall
- `overall_passed` — all checks above are `pass` or `flag_for_review`. If any are `fail` and cannot be resolved via regeneration, overall is `false`.

## Output format for validation_report

```json
{
  "passed": true,
  "checks": [
    {
      "check": "title_length",
      "status": "pass",
      "note": "57 characters"
    },
    {
      "check": "title_uniqueness",
      "status": "flag_for_review",
      "note": "Cannot verify uniqueness across partner site. Engineer must confirm no other page on the site uses this exact title."
    },
    {
      "check": "meta_length",
      "status": "fail",
      "note": "168 characters (exceeds 165 hard max). Regenerated."
    }
  ],
  "regenerations_performed": [
    {
      "element": "meta_description",
      "reason": "Length exceeded hard max",
      "original_length": 168,
      "new_length": 155
    }
  ]
}
```
