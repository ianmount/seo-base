---
name: seo-technical-package
description: Use this skill whenever a new web page needs to be created or an existing page's technical SEO elements need to be regenerated. Produces the complete technical SEO wrapper for a single page — title tag, meta description, canonical URL, URL slug, meta robots directive, H1, H2/H3 structural outline, internal link placements with anchor text, image slot specs with alt text, and JSON-LD schema markup (LocalBusiness, Service, FAQPage, BreadcrumbList as applicable). Designed for local service business partners. Do NOT use this skill to generate body copy — body copy belongs to the seo-body-content skill and runs as a separate step after this skill's output is validated.
---

# SEO Technical Package

This skill generates the complete technical SEO wrapper for a single partner page. It is deterministic and rules-based — every output element follows a specific standard with a defined acceptable range. The skill includes a self-validation step that runs before returning output, catching common errors before they reach the engineer review stage.

## When to use this skill

Activate when the engineer (or tool) needs the technical SEO layer for a single new partner page, or when regenerating technical elements for an existing page (e.g., a title rewrite for CTR, a schema retrofit, a canonical correction).

Do not use for:
- Body copy generation → use `seo-body-content`
- Keyword research → use `seo-keyword-research`
- Strategy / page roadmap decisions → use `seo-strategy-light`
- Cycle performance reports → use `seo-cycle-report`

## Required inputs

The caller must provide, in structured form:

1. **Partner profile** (object)
   - `business_name` (string)
   - `business_type` (string — e.g. "Plumber", "RoofingContractor", "Dentist" — maps to schema.org LocalBusiness subtype)
   - `nap` (object: `street_address`, `locality`, `region`, `postal_code`, `country`, `phone`)
   - `hours` (string, e.g. "Mo-Fr 07:00-18:00")
   - `service_areas` (array of city or region names)
   - `services` (array of service names)
   - `price_range` (optional string, e.g. "$$")
   - `website_url` (string — the partner's root domain, with protocol)

2. **Page details** (object)
   - `page_type` (enum: `homepage` | `service` | `location` | `blog` | `other`)
   - `target_keyword` (string — primary keyword for the page)
   - `secondary_keywords` (array of strings, optional)
   - `intent` (enum: `informational` | `commercial` | `transactional` | `navigational`)
   - `proposed_url_path` (string — e.g. "/services/roof-repair/", no domain)
   - `service_name` (string, if `page_type` is `service`)
   - `location_name` (string, if `page_type` is `location`)

3. **Content outline** (object, from the Strategy skill or provided manually)
   - `h1` (string — can be refined by this skill)
   - `h2_list` (array of strings — section headings)
   - `h3_list_per_h2` (optional object mapping H2 strings to arrays of H3s)
   - `word_count_target` (integer)

4. **Internal linking plan** (array of objects — provided by the Strategy skill)
   - Each object: `destination_url` (string), `suggested_anchor_text` (string), `anchor_text_variants` (array of strings), `context_hint` (string — where in the page this link should be placed)

5. **FAQ set** (optional array of objects) — if provided, must be marked up as FAQPage schema
   - Each object: `question` (string), `answer` (string, plain text)

6. **Image slots** (optional array of objects) — if the page will use images
   - Each object: `position` (e.g. "hero", "mid-body", "gallery"), `description_hint` (brief description of intended image)

## Output format

Return a single JSON object with this structure. All fields are required unless marked optional.

```json
{
  "title_tag": "string (50–60 chars, target keyword early, brand at end)",
  "meta_description": "string (140–160 chars, keyword included, includes a CTA)",
  "canonical_url": "string (absolute, https, trailing slash per convention)",
  "url_slug": "string (lowercase, hyphens, keyword inclusion)",
  "meta_robots": "string (usually 'index, follow' — only differs if explicitly required)",
  "h1": "string (distinct from title_tag, keyword-inclusive, 8–12 words)",
  "headers": {
    "h1": "string",
    "h2_list": [
      {
        "text": "string (8–12 words, semantic keyword variation where natural)",
        "h3_list": ["string", "..."]
      }
    ]
  },
  "internal_links": [
    {
      "destination_url": "string",
      "anchor_text": "string (chosen from provided variants to avoid over-optimization)",
      "placement_note": "string (e.g. 'first paragraph', 'closing CTA section')"
    }
  ],
  "image_specs": [
    {
      "position": "string",
      "filename": "string (lowercase, hyphens, keyword-inclusive where natural, e.g. 'roof-repair-denver-home.webp')",
      "alt_text": "string (describes image content for users; keyword inclusion only where genuinely relevant — never keyword stuffing)",
      "format_recommendation": "webp|jpeg|png|svg",
      "max_file_size_kb": "integer (200 for body, 500 for hero)"
    }
  ],
  "schema_jsonld": [
    {
      "type": "LocalBusiness|Service|FAQPage|BreadcrumbList|Article|BlogPosting",
      "json": "object (valid JSON-LD matching schema.org spec)"
    }
  ],
  "breadcrumb_hierarchy": [
    {"name": "Home", "url": "string"},
    {"name": "string", "url": "string"},
    "..."
  ],
  "validation_report": {
    "passed": true,
    "checks": [
      {"check": "title_length", "status": "pass|fail", "note": "string"},
      {"check": "meta_description_length", "status": "pass|fail", "note": "string"},
      "... (full list — see validation checklist in rules/)"
    ]
  }
}
```

## Execution procedure

Follow these steps in order. Do not skip the validation step.

1. **Load the rules reference file** at `rules/technical_seo_rules.md` if available in the skill context. This file contains the authoritative rules for every element produced by this skill. When in doubt, the rules file is the source of truth.

2. **Generate each element in this order** (later elements sometimes depend on earlier ones):
   1. URL slug (derives from target keyword and proposed URL path)
   2. Canonical URL (derives from partner `website_url` + URL slug)
   3. Title tag
   4. Meta description
   5. H1
   6. H2/H3 structure (refine from input outline)
   7. Internal link placements (choose anchor text variants to avoid over-optimization)
   8. Image specs (if image slots provided)
   9. Breadcrumb hierarchy
   10. Schema JSON-LD (generate all applicable types for the page type)

3. **Run the self-validation checklist** (see `rules/validation_checklist.md` for the full list). Every check must pass OR be flagged explicitly in the `validation_report`. Common checks:
   - Title tag 50–60 characters
   - Meta description 140–160 characters
   - Canonical URL absolute, uses https, trailing slash matches site convention
   - URL slug lowercase, hyphens only, no special characters, no parameters
   - H1 distinct from title tag
   - Exactly one H1
   - H2/H3 structure does not skip levels
   - JSON-LD has required fields for each type (see schema templates in `schema_templates/`)
   - Internal link anchor text not identical across all links (rotate variants)
   - No keyword stuffing in title, meta, H1, or alt text
   - Image filenames lowercase with hyphens

4. **If any validation check fails**, regenerate that specific element (not the whole package) with explicit context about the failure, then re-run the validation check. Continue until all checks pass, or flag in the `validation_report` if the failure cannot be resolved without upstream input changes.

5. **Return the final JSON output** with a complete `validation_report`.

## Rules summary (full rules in `rules/technical_seo_rules.md`)

### Title tag
- 50–60 characters displayed length
- Target keyword in the first half
- Brand name at the end, separated by a pipe or dash, unless hyper-competitive keyword where every character matters
- Unique per page across the partner site (cannot check uniqueness within this skill — flag for engineer review in `validation_report`)
- No keyword stuffing
- Write for CTR, not just ranking

### Meta description
- 140–160 characters
- Primary keyword included naturally
- Includes a CTA where appropriate ("Get a free estimate," "Book online," "Serving [city] since [year]")
- Unique per page across the partner site
- Not a copy of the first sentence of body copy

### Canonical URL
- Absolute URL including protocol (https)
- Trailing slash matches site convention — ASSUME trailing slash unless caller provides explicit override in partner profile
- Self-referencing by default (canonical points to the page's own URL)
- Lowercase

### URL slug
- Lowercase, hyphens between words
- Includes target keyword where natural
- Under 75 characters total path where possible
- No parameters (use path structure instead)
- No underscores, no spaces, no encoded characters

### Meta robots
- Default: `index, follow`
- Always explicit in output, never assumed

### H1
- One per page, exactly
- Distinct from title tag (not identical)
- Includes or closely matches target keyword
- 8–12 words ideal

### Header hierarchy
- H1 → H2 → H3 → etc. Never skip levels.
- H2s divide the page into major sections
- H3s only within an H2
- Use semantic keyword variations where natural
- Descriptive, not decorative (don't use headers for styling)

### Internal links
- Minimum 2, typical 3–5 per page
- Anchor text descriptive and keyword-relevant to destination
- Vary anchor text across links to the same destination across the site — rotate through provided variants
- Include at least one link to a pillar page or top-level service hub
- Never 100% exact-match anchor text on any single destination

### Image specs
- Filename: lowercase, hyphens, descriptive, keyword-inclusive where natural
- Alt text: describes image content for users; keyword inclusion only where genuinely relevant
- Format: WebP for photos preferred, SVG for logos/icons, JPEG as fallback, PNG only when transparency needed
- Max size: 200KB body images, 500KB hero images
- Include explicit width and height (dimensions) recommendation to prevent CLS

### Schema (JSON-LD)
- JSON-LD format only (not Microdata, not RDFa)
- Placed in page `<head>` via plugin or Embed element
- Per page type:
  - **Homepage**: LocalBusiness (with specific subtype like `Plumber`, `RoofingContractor`) + Organization
  - **Service page**: Service referencing the LocalBusiness entity
  - **Location page**: LocalBusiness with `areaServed` for the specific geographic area, OR a branch/department
  - **Blog post**: BlogPosting with author, publisher, datePublished
  - **FAQ section on any page**: FAQPage (separate JSON-LD block)
  - **All pages except homepage**: BreadcrumbList
  - **Review display (optional, only when Review Generation has provided data)**: AggregateRating — never fabricate this data
- All schema must pass Google Rich Results Test validation
- Schema templates for each type are in `schema_templates/` for reference

### Breadcrumb hierarchy
- Match the URL hierarchy
- Start with "Home" at the site root
- End with the current page (no link on the last item)

## Constraints and guardrails

- **Never invent partner data.** If the partner profile doesn't provide a field that's required for schema generation (e.g. `priceRange` for LocalBusiness, `foundingDate` for Organization), omit the optional field rather than fabricating. Required fields that are missing should be flagged in the `validation_report` with `status: fail` and a note indicating which input is missing.
- **Never invent certifications, awards, or trust signals.** These are partner-specific facts that cannot be inferred.
- **Never produce body copy.** If the caller expects body copy, direct them to the `seo-body-content` skill. This skill produces only the technical wrapper.
- **Validation is not optional.** Every output must include a complete `validation_report`. The `seo-body-content` skill and any downstream tool (like the skill-runner tool) should treat `passed: false` as a blocking condition.

## Reference files

The skill includes these reference files, loaded on demand when their content is needed:

- `rules/technical_seo_rules.md` — full rule set for every output element
- `rules/validation_checklist.md` — the self-validation checklist run before returning output
- `schema_templates/localbusiness.json` — LocalBusiness schema template with field guidance
- `schema_templates/service.json` — Service schema template
- `schema_templates/faqpage.json` — FAQPage schema template
- `schema_templates/breadcrumblist.json` — BreadcrumbList schema template
- `schema_templates/organization.json` — Organization schema template
- `schema_templates/blogposting.json` — BlogPosting schema template
- `examples/service_page_example.json` — worked example of a service page output
- `examples/location_page_example.json` — worked example of a location page output
