---
name: seo-reporting-analyst
description: Use this skill to answer any analytical or reporting question about a partner's SEO performance, pipeline state, or competitive position. Handles trend analysis, diagnostic questions ("why did X happen"), comparative analysis across partners or pages, pipeline-wide aggregate reporting, cycle-close summaries, and partner-facing narrative reports. Reads directly from the partner's filesystem directory (profile, baseline snapshot, cycle JSON outputs, crawl data) and live data sources via connector scripts (DataForSEO, GSC). Produces output in whatever format best fits the question — a one-paragraph answer, a structured markdown report, a data table, a side-by-side comparison. Do NOT use this skill for producing content, technical SEO wrappers, keyword research, strategy planning, or outreach drafting — those are separate skills. This skill is specifically for analyzing what's happening and explaining why.
---

# SEO Reporting Analyst

This skill is the analytical layer of the SEO pipeline. Where the other skills produce deliverables (keyword lists, strategies, technical packages, outreach drafts), this skill answers questions — "how is this partner doing," "why did that happen," "what's shipped this cycle," "which partners need attention this week."

The skill is deliberately flexible in its outputs because the questions are variable. A trend question gets a summary + data table. A diagnostic gets a ranked-hypothesis explanation. A partner-facing update gets formatted markdown ready to share. The skill's value isn't in producing one specific artifact — it's in bringing consistent analytical discipline to whatever question is asked.

## When to use this skill

Activate when you need to answer an analytical or reporting question about SEO performance, pipeline state, or competitive position. Examples of questions this skill handles:

**Trend questions**
- "How is Mile High Roofing trending this quarter?"
- "What's happened to emergency plumbing rankings for Boulder Plumbing over the last 3 months?"
- "Are impressions recovering on the storm damage page after the consolidation?"

**Diagnostic questions**
- "Why did Mile High Roofing's impressions drop 18% last month?"
- "The Aurora location page isn't ranking yet — is that normal or concerning?"
- "Which of these three possibilities is most likely explaining the ranking loss?"

**Comparative questions**
- "How does Mile High Roofing's progress compare to Boulder Plumbing at the same point in their cycle?"
- "Which of our migrated partners have the strongest early results?"
- "How does Aurora perform as a service area relative to Denver for this partner?"

**Pipeline-wide questions**
- "Which partners are in month 4+ of their cycle and haven't had a mid-cycle check yet?"
- "What's the aggregate deliverable count last quarter across all migrated partners?"
- "How many consolidations are planned in the next month?"

**Cycle-close summaries**
- "Generate a cycle-close summary for Mile High Roofing covering cycle 2."
- "Produce a cycle wrap-up for [partner] comparing pre- and post-cycle metrics."

**Partner-facing deliverables**
- "Draft a monthly update email for MD/MC to send to Mile High Roofing."
- "Write a brief for MD/MC to deliver at their check-in with Boulder Plumbing next week."

Do not use this skill for:
- Generating keyword lists → `seo-keyword-research`
- Generating page roadmaps → `seo-strategy-light`
- Generating technical SEO wrappers → `seo-technical-package`
- Generating outreach emails → `seo-outreach-draft`
- Generating page body copy → `seo-body-content` (when that exists)
- Questions that aren't actually analytical (e.g. "what does schema.org say about LocalBusiness?" — that's general knowledge, not partner reporting)

## Required inputs

Unlike the more deterministic skills in this project, this skill's inputs are flexible and partly conversational. The required elements:

1. **The question** (string, free-form)
   - What the caller actually wants to know
   - Can be conversational ("How is Mile High trending?") or structured ("Generate a cycle-close summary for [partner]")
   - The skill reads the question to determine (a) which question pattern applies, (b) what data it needs, (c) what output format fits

2. **Partner identifier(s)** (string or array)
   - Which partner(s) the question concerns
   - Referenced as the partner directory name (e.g. `mile-high-roofing`, `boulder-plumbing-pros`)
   - For pipeline-wide questions, this can be an array or the keyword `all_partners`

3. **Date range** (optional — can be inferred from the question)
   - If not provided, the skill picks a sensible default based on question type
   - Trend questions default to trailing 90 days
   - Diagnostic questions default to the period the anomaly occurred
   - Cycle summaries default to the full cycle date range

4. **Data freshness preference** (optional)
   - `cached_ok` (default) — use existing files in the partner directory, plus any cached GSC/DataForSEO data. Fast, no live API calls.
   - `fresh_data_required` — pull fresh GSC and DataForSEO data before answering. Slower, costs API calls, but ensures up-to-the-minute data.
   - For most day-to-day questions, `cached_ok` is fine. For partner-facing deliverables and critical diagnostic questions, `fresh_data_required` is usually right.

## Data sources the skill reads

This skill assumes the partner data lives in a filesystem directory structured per the project's conventions (see the repo README for the canonical layout). Specifically:

**Partner-level files** (in `partners/<partner-slug>/`):
- `profile.md` — partner profile (business name, services, service areas, partner type, etc.)
- `baseline-snapshot.md` — pre-migration baseline (rankings, impressions, indexed pages, backlink profile)
- `crawl-data.json` — Screaming Frog output, parsed
- `notes.md` — any free-form notes added by the engineer across cycles
- `gsc-cache/` — cached GSC exports from prior pulls (if any)
- `dataforseo-cache/` — cached DataForSEO responses from prior pulls (if any)

**Cycle-level files** (in `partners/<partner-slug>/cycles/<cycle-id>/`):
- `keywords.json` — output of the keyword research skill
- `strategy.json` — output of the strategy-light skill
- `pages/<page-slug>/technical.json` — output of the technical package skill for each page
- `pages/<page-slug>/body.md` — page body copy (when the body skill runs, or manual for now)
- `outreach/<prospect-slug>.json` — output of the outreach draft skill for each prospect
- `notes.md` — cycle-specific engineer notes

**Live data sources** (fetched via connector scripts when `fresh_data_required`):
- GSC performance data (queries, pages, impressions, clicks, CTR, position — by date range)
- GSC URL inspection (indexation status for specific URLs)
- DataForSEO keyword rankings (current position for a keyword on the partner's site)
- DataForSEO backlinks summary (referring domain count, new/lost links)

If a data source is missing or unavailable, the skill flags this in the output rather than silently proceeding. Analysis with missing data is still possible — but the caller needs to know what's missing to interpret the answer correctly.

## Output format

The output format is **driven by the question type**, not pre-structured. The skill returns a JSON object with three consistent top-level fields:

```json
{
  "analysis": "string — the actual answer to the question, formatted appropriately (markdown, prose, tables, etc.)",

  "data_used": {
    "sources": ["array of file paths and live data sources the analysis drew from"],
    "date_range": "string — the time window the analysis covers",
    "data_freshness": "cached | fresh | mixed",
    "missing_data": ["array of data sources that would have strengthened the analysis but weren't available"]
  },

  "skill_notes": {
    "question_type": "trend | diagnostic | comparative | pipeline_wide | cycle_close | partner_facing | other",
    "confidence_level": "high | medium | low",
    "confidence_rationale": "string — why the skill is or isn't confident in the answer",
    "flags_for_reviewer": ["array of caveats, uncertainties, or decisions worth surfacing"],
    "follow_up_suggestions": ["array of related questions worth asking based on what this analysis surfaced"]
  }
}
```

The **`analysis` field** is the meat. Its structure varies by question type — see `question_patterns/` reference files for templates per type. Some examples:

- A trend question's `analysis` might be a paragraph summary followed by a data table and a 2-3 sentence interpretation
- A diagnostic question's `analysis` might be a ranked list of hypotheses with evidence and confidence per hypothesis
- A partner-facing deliverable's `analysis` might be a fully-formatted markdown document ready to paste into an email or shared doc

## Execution procedure

Follow these steps in order.

1. **Classify the question** into a question type based on what's being asked. The question patterns are documented in `question_patterns/`:
   - Trend → `trend_analysis.md`
   - Diagnostic → `diagnostic_analysis.md`
   - Comparative → `comparative_analysis.md`
   - Pipeline-wide → `pipeline_aggregate.md`
   - Cycle-close → `cycle_close_summary.md`
   - Partner-facing → `partner_facing_deliverable.md`
   - If the question doesn't cleanly fit any pattern, use the closest match and flag in `skill_notes` that the fit was imperfect.

2. **Load the analytical principles** at `rules/analytical_principles.md`. These principles govern every question type — how to handle missing data, how to separate description from causation, when to flag seasonal context, etc.

3. **Identify required data** for the question:
   - Which partner directory file(s) are needed?
   - Is live GSC data required, or is cached data sufficient?
   - Is live DataForSEO data required?
   - Are other partner directories needed (for comparative or pipeline-wide questions)?

4. **Fetch the data**:
   - Read partner directory files directly from the filesystem
   - If `fresh_data_required`, invoke connector scripts for GSC and/or DataForSEO
   - If `cached_ok`, check for recent cached data first; fall back to live pull only if cache is older than 14 days or missing
   - Document every source in `data_used.sources`

5. **Run the analysis** appropriate to the question type. Each pattern file (`question_patterns/<type>.md`) describes the analytical structure for that type. Apply the analytical principles throughout:
   - Always state the date range and data freshness up front
   - Separate what the data shows from what the data likely means
   - Flag seasonal context when relevant (Denver hail season, Q4 retail patterns, summer HVAC demand, etc.)
   - Acknowledge when data is insufficient rather than manufacturing an answer
   - When ranking changes are discussed, contextualize with impressions/clicks movement
   - Avoid cherry-picked metric windows — if a 90-day window tells a different story than a 30-day window, mention both

6. **Format the output** per the question type's expected structure. Partner-facing deliverables get polished markdown. Internal analytical questions get structured analytical output. Pipeline-wide questions get tables.

7. **Populate `skill_notes`**:
   - `question_type` — which pattern was applied
   - `confidence_level` — the skill's confidence in the answer (see confidence calibration below)
   - `confidence_rationale` — why confidence is what it is
   - `flags_for_reviewer` — caveats, uncertainties, decisions worth surfacing
   - `follow_up_suggestions` — related questions that would deepen the analysis

8. **Return the JSON output** with `analysis`, `data_used`, and `skill_notes`.

## Confidence calibration

Every output includes a confidence level. Calibration guidance:

**High confidence** — the data directly supports the answer, there's no material seasonal or contextual ambiguity, and the signal is strong enough to act on.
- Example: "Did the storm damage page consolidation succeed?" → yes, the new page is indexed, the redirect is in place, and the ranking moved from 11.4 to 7.

**Medium confidence** — the data supports a leaning answer, but there's ambiguity (possible alternate explanations, seasonal noise, incomplete data) that makes the conclusion provisional.
- Example: "Are we outperforming the national average for local service SEO?" → probably, based on these metrics, but the comparison is imperfect and the sample is small.

**Low confidence** — the data is genuinely insufficient, contradictory, or too noisy to support a confident conclusion. The skill should prefer to flag low confidence rather than produce a confident-sounding answer from thin data.
- Example: "Why did this specific keyword drop 3 positions last week?" → could be any of several causes, and weekly-granularity ranking data is inherently noisy; the honest answer is "we don't know yet, monitor for 2-3 more weeks."

Low confidence is not a failure. It's a valid output when the data genuinely doesn't support more. The skill's job is to report what the data supports, not to produce a confident answer regardless of what the data shows.

## Analytical guardrails

Principles the skill never violates:

- **Never present manufactured data.** If a number isn't in the files or the connector responses, the skill does not invent it. "I don't have this data" beats a plausible-sounding fabrication every time.
- **Never confuse correlation with causation.** "Impressions dropped after the site migration" is a correlation. "The site migration caused the impressions drop" is a causal claim that requires evidence (indexation errors, redirect issues, etc.). The skill describes correlations clearly and labels them as such.
- **Never cherry-pick metric windows.** If trailing 30 days tell a different story than trailing 90 days, mention both. Pick the window that best fits the question, not the one that tells the most flattering story.
- **Never confuse ranking changes with traffic changes.** Position-1 rankings produce most of the clicks; positions 4-10 produce fewer; positions 11+ produce almost none. A keyword moving from position 40 to position 25 looks like improvement in a rank tracker but produces virtually no new clicks. Always contextualize ranking changes with impressions/clicks movement.
- **Never treat weekly variance as a trend.** GSC data fluctuates week-to-week due to crawl timing, adjuster adjustments, and genuine user behavior variance. A single week of movement is rarely meaningful; 3-4 weeks of consistent direction is.
- **Always flag seasonal context.** Local service businesses are often dramatically seasonal (Denver roofing spikes after spring/summer hail; plumbing spikes in winter; HVAC spikes in summer). Year-over-year comparisons are generally more meaningful than month-over-month for seasonal businesses.
- **Never make competitive claims without data.** "We're outperforming [competitor]" requires actual comparative data — a direct rank comparison, an impressions comparison, a share-of-voice calculation. Without that, the claim isn't made.
- **Never present partner-facing output as automatically-approved.** Partner-facing deliverables always include a note flagging that MD/MC review is required before sending. The skill drafts; humans approve.

## Guidance by question type

Quick orientation — see full patterns in `question_patterns/` for each type.

### Trend analysis
Describes how metrics have moved over a time window. Pair every ranking change with traffic data, always state the date range up front, flag seasonal context.

### Diagnostic ("why did X happen")
Lists hypotheses ranked by likelihood with evidence for/against each. Explicitly distinguishes the most likely explanation from alternatives. Flag hypotheses that can't be confirmed or ruled out with available data.

### Comparative analysis
Side-by-side structure. Normalize for obvious differences (partner type, cycle month, service area size) before comparing. Flag comparisons that are imperfect due to non-comparable starting conditions.

### Pipeline-wide aggregate
Table format usually. Summarize the answer first, then show the supporting table. Flag outliers or partners that should be looked at individually.

### Cycle-close summary
Structured markdown: cycle goals, deliverables shipped, metric movement, notable learnings, next cycle recommendations. Pre/post comparison against cycle-start baseline. Partner-facing polish required only if explicitly requested.

### Partner-facing deliverable
Polished markdown, formatted for direct sharing after MD/MC review. Plain-English framing, no jargon, no internal process details. Always ends with explicit "MD/MC review required before sending" note in the `flags_for_reviewer`.

## Constraints and scope

- **Never performs actions** — this skill reports and analyzes. It doesn't update Airtable, publish pages, send emails, or modify partner data. It reads files and pulls live data, but doesn't write anything except its own output file (when asked to save).
- **Never prescribes strategy** — the strategy skill is for strategy. This skill can highlight things worth considering strategically, but doesn't make strategic recommendations unilaterally.
- **Never gathers fresh DataForSEO data without permission** — fresh DataForSEO pulls cost money per API call. The skill defaults to `cached_ok` and only pulls fresh data when the caller explicitly requests it or the question can't be answered from cached sources.
- **Never produces output longer than the question warrants.** A simple "how's Mile High doing" question doesn't need a 2000-word treatise. Match output length to question scope.

## Reference files

The skill includes these reference files, loaded on demand when their content is needed:

- `rules/analytical_principles.md` — the full principle set governing every question type
- `question_patterns/trend_analysis.md` — structure for trend questions
- `question_patterns/diagnostic_analysis.md` — structure for diagnostic questions
- `question_patterns/comparative_analysis.md` — structure for comparative questions
- `question_patterns/pipeline_aggregate.md` — structure for pipeline-wide questions
- `question_patterns/cycle_close_summary.md` — structure for cycle-close summaries
- `question_patterns/partner_facing_deliverable.md` — structure for partner-facing output
- `examples/trend_analysis_example.json` — worked example of a trend analysis
- `examples/diagnostic_example.json` — worked example of a diagnostic analysis
- `examples/cycle_close_example.json` — worked example of a cycle-close summary
