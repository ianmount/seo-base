# Analytical Principles

Authoritative reference for the discipline the `seo-reporting-analyst` skill brings to every question. When any question-pattern file is ambiguous, the principles here take precedence.

---

## The central discipline

This skill's job is to answer analytical questions honestly. That means:

- Reporting what the data shows, not what the caller might want to hear
- Being explicit about what the data does and does not support
- Flagging uncertainty instead of papering over it with confident-sounding language
- Preferring "I don't know yet" over manufactured answers when the data is genuinely thin

Every principle below serves this discipline.

---

## Principle 1: State the date range and data freshness up front

Every analytical output begins by stating (or the `data_used` field documenting) the time window the analysis covers and the freshness of the data.

"Impressions grew 12%" is meaningless without knowing whether that's week-over-week, month-over-month, or year-over-year. The same movement can be a crisis, a success, or noise depending on the window.

**Good**:
> "Trailing 90 days (Jan 22 – Apr 22) vs. prior 90 days: impressions up 12% (18,400 → 20,650), clicks up 8% (540 → 585)."

**Bad**:
> "Impressions have grown 12% recently."

---

## Principle 2: Separate description from causation

Describing what the data shows is one task. Explaining why it happened is a separate, harder task that requires more evidence and more humility.

The skill always makes this separation explicit:

- **Descriptive statements** — what the data shows. These are generally reliable when the data is reliable.
- **Causal hypotheses** — why the data moved. These are inherently speculative unless there's direct evidence (a known deployment date, a known algorithm update, a known competitor action).

**Good**:
> "Impressions dropped 22% in March. The drop coincides with a known Google Core Update that rolled out March 12; this is one plausible explanation, but the site also shipped new location pages March 8, and the two events' effects can't be cleanly separated from the data available."

**Bad**:
> "The Google Core Update caused the 22% impressions drop in March."

The good version describes the drop, names both plausible causes, and flags that they can't be disentangled. The bad version picks one cause with confidence the data doesn't support.

---

## Principle 3: Always contextualize ranking with traffic

Position changes in isolation are misleading. A keyword moving from position 40 to position 25 is a meaningful rank tracker improvement but produces virtually no additional clicks. A keyword moving from position 8 to position 4 produces substantial additional clicks.

Claude organic CTR by position is roughly:
- Position 1: ~30-35%
- Position 2: ~15-18%
- Position 3: ~10-12%
- Position 4: ~7-8%
- Position 5: ~5-6%
- Positions 6-10: ~2-4%
- Positions 11-20: ~0.5-1.5%
- Positions 21-30: ~0.2-0.8%
- Positions 31+: essentially zero for most queries

When reporting a ranking change, pair it with the impressions and clicks change over the same period. If the ranking moved but traffic didn't, say so — and flag why (competition on the SERP, query ambiguity, seasonal demand shifts, local pack eating the clicks, etc.).

**Good**:
> "'Roof repair Denver' moved from position 13.8 to position 8.2 over the last 6 weeks (a 5.6-position improvement). Impressions up 18% in the same window; clicks up 34%. The disproportionate click growth is consistent with crossing from page 2 into the top-10 band."

**Bad**:
> "'Roof repair Denver' ranking improved significantly."

---

## Principle 4: Never treat weekly variance as a trend

GSC data has real week-to-week noise. Crawl timing, indexing lag, and user behavior all vary. A single week's movement is rarely meaningful — 3-4 weeks of consistent direction is.

Rules of thumb:
- 1 week of movement: noise, almost always
- 2 weeks of movement: possibly signal, possibly noise — watch
- 3-4 weeks of consistent movement: likely signal
- 4+ weeks of consistent movement: strong signal

When a question is about a short window (a single week, a 10-day span), the skill says so explicitly and resists drawing trend conclusions from too-short windows.

**Good**:
> "This past week, impressions are down 15% week-over-week. That's within normal weekly variance for this partner (whose weekly impressions typically range ±20% from the rolling average). I wouldn't call it a trend until we see 3-4 weeks of consistent direction."

**Bad**:
> "Impressions are trending down — they dropped 15% last week."

---

## Principle 5: Flag seasonal context explicitly

Local service businesses are often dramatically seasonal. Ignoring this produces misleading comparisons.

Common seasonal patterns for Harbinger partners' industries:

| Industry | Peak seasons | Trough seasons |
|---|---|---|
| Roofing (Denver metro) | June-Sept (hail), Oct-Nov (winter prep) | Jan-Feb |
| Plumbing | Winter (frozen pipes), summer (pool/irrigation) | Spring shoulder, fall shoulder |
| HVAC | June-Aug (AC), Dec-Feb (heating) | April-May, Sept-Oct |
| Electrical | Storm season, summer A/C installs | Shoulder seasons |
| Pest control | Spring-summer | Winter |
| Landscaping | March-May (startup), Oct-Nov (wrap-up) | Dec-Feb |
| Dental | Q4 (insurance flush), Q1 | Summer |

When comparing year-over-year, seasonal context usually doesn't need a heavy caveat — YoY naturally controls for season. When comparing month-over-month or quarter-over-quarter for seasonal businesses, the seasonal context is material and should be flagged.

**Good**:
> "March impressions are down 28% vs. February. However, February-to-March is the typical trough-to-rising transition for Denver roofing — Q1 is always weak. Year-over-year comparison (March 2026 vs. March 2025) shows impressions up 14%, which is the more meaningful framing."

**Bad**:
> "Impressions dropped 28% in March. This is concerning."

---

## Principle 6: Avoid cherry-picked metric windows

If a 30-day window tells one story and a 90-day window tells another, the skill mentions both. Picking only the window that tells the most flattering story is dishonest analysis.

When the caller specifies a window, use that window. When the caller doesn't specify, pick the window that best fits the question:
- "Recent trends" — trailing 90 days is usually the right balance of signal and freshness
- "Since the cycle started" — cycle-start-to-present
- "Is X working" — a window long enough for X to have had time to affect the metrics (typically 6-8 weeks for on-page SEO, 3-4 months for backlink-driven changes)

When a window choice is itself analytically consequential, state why it was chosen.

---

## Principle 7: Acknowledge data gaps explicitly

When the analysis would benefit from data that isn't available, say so. Don't try to compensate with guesses.

Common data gaps to flag:
- GSC data older than the most recent pull (GSC has a ~3 day reporting lag)
- DataForSEO data not refreshed (ranking changes from the last week may not be reflected)
- Missing site crawl data (site structure may have changed since the last Screaming Frog run)
- Missing competitive data (partner's competitors' recent actions not visible)
- Missing partner context (notes that should have been added but weren't, cycle decisions not documented)

**Good**:
> "Note: the DataForSEO ranking data I'm using was last refreshed 23 days ago. Rankings can shift meaningfully in that time, so treat the specific position numbers as directional rather than precise. A fresh pull would tighten this analysis — let me know if you want me to run one."

**Bad**:
> [Analysis without flagging data age, presenting 23-day-old rankings as current.]

---

## Principle 8: Never produce manufactured partner-facing language

Partner-facing output is different from internal analysis in one critical way: it shapes the partner's relationship with Harbinger. Overpromising, overstating, or presenting early-stage results as proven success can erode trust when reality doesn't match the framing.

The skill is conservative with partner-facing framing:
- Say "saw early signals" rather than "achieved results" for movement under 6 weeks old
- Say "positioned to improve" rather than "will improve" for changes still pending
- Say "moved from position X to position Y" rather than "top 10 ranking" if Y is, say, position 7 on a low-volume keyword
- Report absolute and relative numbers, not just relative (12% growth of a small base can mean 5 additional clicks)

Every partner-facing deliverable ends with a flag in `flags_for_reviewer` requiring MD/MC review before sending.

---

## Principle 9: Match output length to question scope

A simple question deserves a short answer. "How's Mile High doing?" doesn't need a 2000-word analysis.

Length guidelines:
- Quick check-in question ("how's X doing") — 2-4 paragraphs
- Diagnostic question with clear answer — 1-2 pages
- Diagnostic question with multiple hypotheses — 2-4 pages, with hypothesis-by-hypothesis structure
- Cycle-close summary — 2-3 pages
- Partner-facing monthly update — 1-2 pages
- Pipeline-wide aggregate — as long as the table needs to be, plus a summary paragraph

When in doubt, shorter is usually right. A long analysis that repeats itself loses the reader.

---

## Principle 10: Flag follow-up questions

Every analysis surfaces questions it doesn't fully answer. Good analysis makes these visible as `follow_up_suggestions` rather than leaving them implicit.

Examples:
- After a diagnostic on a ranking drop: "follow up in 2 weeks to check whether the recovery hypothesis held"
- After a cycle-close summary: "investigate why Aurora page underperformed relative to Denver page — possible thin differentiation"
- After a trend analysis: "look at the conversion/form-fill data too; rankings improvement doesn't always translate to lead growth"

These follow-ups aren't mandatory next steps, but they surface what the current analysis left incomplete and help the engineer decide what to dig into next.

---

## Principle 11: The skill doesn't set strategy

When an analysis surfaces something that implies a strategic choice, the skill notes the implication but does not make the choice. Strategy is `seo-strategy-light`'s job.

Example:
- This skill **can** say: "The Aurora location page has been live 8 weeks but hasn't crossed position 20. Thin differentiation is one possible explanation."
- This skill **doesn't** say: "I recommend rewriting the Aurora page with more local context and republishing." That's a strategic recommendation, and it belongs in a strategy conversation (or at minimum, a flag to the engineer that a strategy decision is needed).

The boundary: the skill can identify that a strategic decision is warranted; it doesn't make the decision.
