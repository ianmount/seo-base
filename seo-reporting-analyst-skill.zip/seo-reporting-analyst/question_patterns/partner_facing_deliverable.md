# Partner-Facing Deliverable Pattern

Structure for analysis produced for eventual delivery to the partner (via MD/MC). Typical forms: "draft a monthly update for [partner]," "write a brief for MD/MC to deliver next week," "produce the partner-facing version of the cycle close summary."

---

## The fundamental difference from internal analysis

Partner-facing output is shaped by partner context and relationship, not just by the data. The same metric movement gets framed differently depending on:

- The partner's stage of relationship (new partner vs. long-term)
- What was promised at cycle start
- The partner's sophistication level with SEO
- The MD/MC's preferred voice and positioning

The skill's job is to produce a good starting draft that the MD/MC can adjust to their specific partner. **Never send partner-facing output without MD/MC review.** This is flagged in every `skill_notes.flags_for_reviewer` for partner-facing deliverables.

---

## The core arc

1. **Warm opener** — a 1-2 sentence orientation that's warm but not sycophantic
2. **Headline** — what's worth knowing from this period, in plain language
3. **Key outcomes** — 2-4 specific things that happened, framed in outcome terms (not process terms)
4. **What's in motion** — what's being worked on that isn't yet producing results
5. **What's next** — forward-looking framing tied to the partner's goals
6. **Invitation to respond** — a natural close that makes it easy for the partner to reply

---

## Tone guidelines for partner-facing output

**Plain language over SEO jargon**. Partners generally don't care about "striking distance" or "canonical URLs." Translate to outcomes: "moved to the top of page two, which typically produces a meaningful increase in clicks" instead of "moved into striking distance."

**Conservative framing for early-stage results**. Six weeks is not "established ranking." Use "showing early momentum" or "positioned to improve" rather than "now ranking well."

**Absolute numbers alongside percentages**. "Clicks grew 50%" means more when you know it's from 20 to 30 vs. from 200 to 300. For smaller partners, absolute numbers often tell a more honest story.

**Acknowledge what hasn't worked or is still unclear**. Partners generally know when things aren't going perfectly. Pretending they are damages credibility. A measured "the Aurora page is still early in its ranking cycle, so we don't have a clear read yet" is better than glossing.

**Avoid overclaiming causation**. "After we published the new service page, rankings improved" is different from "The new service page caused the ranking improvement." The former is honest; the latter requires evidence.

---

## What NOT to include in partner-facing output

- Internal process details ("we used our seo-technical-package skill to generate the schema")
- Competitive claims without explicit evidence ("we're outperforming your competitors")
- Hedged promises about future performance ("we expect rankings to continue improving" — the skill doesn't know this)
- Long deliverable lists that read as "look how busy we've been" — partners care about outcomes, not activity counts
- SEO vendor-speak that sounds like marketing automation

---

## Length and format

- Monthly update: 300-600 words, email-friendly formatting
- Quarterly or cycle close: 500-1000 words, document-friendly formatting
- Always close with an open question or invitation to respond

---

## The MD/MC review flag

Every partner-facing deliverable's `skill_notes.flags_for_reviewer` must include:

> "Partner-facing output — MD/MC review required before sending. Pay particular attention to: [specific things the MD/MC should verify given the partner's context — claims about rankings, framing of unclear results, tone calibration to the relationship]."

The skill does not produce partner-facing output that's intended to be sent without human review. Always.
