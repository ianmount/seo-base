# Cycle Close Summary Pattern

Structure for the 6-month cycle wrap-up. Typical forms: "generate a cycle-close summary for [partner]," "produce the cycle wrap-up comparing pre- and post-cycle metrics."

Cycle close summaries serve two audiences: the engineer (for internal review and next-cycle planning) and, after MD/MC review, potentially the partner (as a partner-facing wrap-up). The skill produces the internal-facing version by default; partner-facing polish is a separate request.

---

## The core arc

Every cycle-close summary follows this structure:

1. **Cycle overview** — partner, cycle number/range, cycle goals at start
2. **Deliverables shipped** — what actually got produced this cycle
3. **Metric movement** — cycle-start baseline vs. current, for relevant metrics
4. **What worked** — interventions that produced clear positive movement
5. **What didn't work or is still unclear** — interventions that haven't produced results yet, or underperformed
6. **Notable learnings** — insights about the partner, their market, or the pipeline that inform next cycle
7. **Next cycle recommendations** — framing for strategy decisions (not decisions themselves — those belong in strategy conversations)

---

## Cycle overview

Short section stating:
- Partner name and business type
- Cycle identifier (e.g. "Cycle 2 — 2026 Q4")
- Cycle date range (start date to close date)
- The cycle's stated goals at start (from the strategy.json or cycle-open notes)

**Example**:
> **Partner**: Mile High Roofing Co. (Denver-metro roofing contractor)
> **Cycle**: Cycle 2 — October 2026 – March 2027
> **Cycle goals at start**: (1) Move "storm damage roof Denver" from striking distance to page 1 via consolidation. (2) Launch Aurora location page to capture the striking-distance Aurora keyword. (3) Address roof replacement cluster with a dedicated service page. (4) Optimize homepage for "roofer Denver" striking distance.

---

## Deliverables shipped

Concrete list of what the pipeline produced this cycle. Pull from the partner's cycle directory:

- `strategy.json` for the roadmap
- `pages/*/technical.json` for pages that shipped
- `outreach/*.json` for backlink outreach sent
- `notes.md` for any cycle decisions not captured elsewhere

Format as a simple list or table. For each item, note status (shipped, in progress, not started).

**Example**:
> **Pages shipped**: 3 of 4 planned
> - `/services/storm-damage-repair/` — consolidation from `/storm-damage/`, published Nov 2 (Month 2)
> - `/service-areas/aurora/roof-repair/` — new location page, published Dec 8 (Month 3)
> - `/services/roof-replacement/` — new service page, published Jan 14 (Month 4)
> - `/services/gutter-installation/` — planned Month 5, deferred to next cycle due to partner request
>
> **Optimizations completed**: 3 of 3 planned
> - `/services/roof-repair/` — title refresh, content expansion, internal link updates (Month 3)
> - Homepage — LocalBusiness schema upgrade to RoofingContractor, content expansion (Month 4)
> - `/blog/how-to-spot-roof-damage/` — content expansion, new internal links (Month 5)
>
> **Outreach sent**: 18 prospects contacted, 4 confirmed placements, 2 still in conversation

---

## Metric movement

The numbers section. Always show cycle-start baseline vs. current (not just "recent trend"), because the cycle is the meaningful window.

Include:
- Impressions (cycle-start 30-day average vs. current 30-day average)
- Clicks (same)
- Average position (same, with direction noted)
- Indexed pages
- Specific keyword positions for the cycle's priority keywords
- Backlink metrics (referring domains acquired, net new links)

**Example format**:

| Metric | Cycle start (Oct 2026, 30-day avg) | Cycle close (Mar 2027, 30-day avg) | Absolute change | Relative change |
|---|---|---|---|---|
| Impressions | 14,200 | 19,850 | +5,650 | +39.8% |
| Clicks | 420 | 640 | +220 | +52.4% |
| Average position | 16.8 | 12.4 | -4.4 (better) | — |
| Indexed pages | 44 | 49 | +5 | +11.4% |
| Referring domains | 87 | 98 | +11 | +12.6% |

Then a priority-keyword table for the cycle's focus keywords:

| Keyword | Cycle-start position | Cycle-close position | Change |
|---|---|---|---|
| storm damage roof Denver | 11.4 | 6.8 | -4.6 (better) |
| roof repair Denver | 13.8 | 9.2 | -4.6 (better) |
| roof repair Aurora CO | 17.6 | 14.1 | -3.5 (better) |
| roofer Denver | 15.2 | 13.8 | -1.4 (better) |
| roof replacement Denver | not ranking | 22.0 | new ranking |

---

## What worked

Interventions where the metric movement closes the loop cleanly. Not every improvement counts — only the ones where you can point to the intervention and the movement.

**Example**:
> **Storm damage consolidation** — the most successful cycle intervention. Moved "storm damage roof Denver" from position 11.4 to 6.8 (into top 10). Impressions on the consolidated page grew 2.3x; clicks grew 3.1x. The 8-step consolidation protocol held — the 301 transferred ranking signal cleanly, no loss during the transition. This validates the consolidation approach for future cycles.
>
> **Homepage LocalBusiness schema upgrade** — "roofer Denver" moved from position 15.2 to 13.8 (smaller movement than hoped, but directionally right). The schema subtype upgrade from generic LocalBusiness to RoofingContractor is a one-time fix; the remaining work on this keyword is content and backlinks, not schema.

---

## What didn't work or is still unclear

Honest accounting of interventions that haven't produced clear results. Separate "didn't work" (intervention complete, no movement) from "unclear" (intervention complete but too early to tell).

**Example**:
> **Aurora location page — unclear**. Page published 4 months ago; current position for "roof repair Aurora CO" is 14.1, down from 17.6 (positive movement). But the main roof repair page also dropped 3 positions on the Aurora keyword in the same period (cannibalization risk we flagged at creation). The two pages' combined ranking signal may not be additive; monitoring for 2-3 more months is the right call before declaring this worked.
>
> **Roof replacement page — unclear**. Page published 6 weeks ago; "roof replacement Denver" entered rankings at position 22. Too early to judge — typical on-page rankings for new pages take 3-4 months to mature. Next cycle's strategy should include a mid-cycle check on this page specifically.
>
> **Gutter installation page — didn't ship**. Deferred at partner request (they're evaluating service offering). No outcome to report.

---

## Notable learnings

Insights worth capturing for future cycles. Things the analysis surfaced that weren't obvious going in.

**Example**:
> **Cannibalization risk on location pages is real**. The Aurora page's performance is mixed in a way that suggests location pages for already-ranking keywords need more careful sequencing. Next cycle, when planning Lakewood and Arvada location pages, give more weight to whether the main roof repair page is already serving that keyword's traffic, and explicitly plan the content differentiation.
>
> **Consolidation protocol works — worth replicating**. The storm damage consolidation is the cycle's strongest single result. Consider this the template for future thin-ranking-page consolidations.
>
> **Partner-side content requirements were consistently the bottleneck**. Three of the four new pages needed partner-provided project examples or testimonials that took longer to source than planned. Next cycle, ask for these at strategy-approval time, not at content-production time.

---

## Next cycle recommendations

Frame for strategy decisions — not decisions themselves. The strategy skill makes the actual decisions; this skill surfaces the decision points.

**Example**:
> **Location page rollout decision** — Lakewood and Arvada are the next geographic expansion candidates (both in striking distance via the main roof repair page). The Aurora experience suggests staging these more carefully: possibly one at a time with 8-week monitoring gaps rather than both at once. Worth discussing in next cycle's strategy.
>
> **Replacement page follow-through** — the new roof replacement page needs sustained content development and backlink support to graduate from position 22 to page 1. Next cycle's keyword research and strategy should explicitly prioritize this page.
>
> **Backlink outreach angle expansion** — this cycle's outreach relied heavily on resource page and broken link angles. Guest post or expert source angles may open new outreach lanes for next cycle, particularly with the partner's storm damage authority now established.

---

## Tone and length

- Internal-facing (default): analytical, direct, assumes SEO literacy
- Partner-facing (on request): removes internal jargon, softens framing, focuses on partner-relevant outcomes and plans
- Length: 2-3 pages for internal; 1-2 pages for partner-facing

---

## Common mistakes to avoid

**Taking credit for movement that wasn't caused by the cycle's interventions**. If impressions grew during the cycle but the growth was driven by seasonal demand rather than anything the pipeline did, say so honestly.

**Hiding failures or unclear outcomes**. The "what didn't work" section is as important as "what worked." Burying disappointing results destroys future analytical credibility.

**Over-claiming early-stage results as proven success**. A 6-week-old page at position 22 isn't "ranking" in the useful sense. Use conservative framing until the data supports more.

**Treating the cycle as a closed loop when it isn't**. Many of the cycle's interventions will produce effects for months after close. The summary should acknowledge this, not pretend everything is measurable at the 6-month mark.

**Making strategic recommendations instead of surfacing decision points**. Strategy decisions belong to the strategy skill. This summary should tee up the questions, not answer them.
