# Comparative Analysis Pattern

Structure for questions comparing partners, pages, keywords, or time periods side by side. Typical forms: "how does X compare to Y," "which of these partners is doing best," "is Aurora outperforming Lakewood as a service area."

---

## Note on this pattern

This pattern file is a starting scaffold. Comparative analysis has many subtypes (partner vs. partner, page vs. page, geography vs. geography, current cycle vs. previous cycle) that benefit from being iterated against real questions. Expand this file as real comparative questions surface in the pipeline.

---

## The core arc

1. **State what's being compared and why** — which entities, which metrics, what the question implicitly assumes about comparability
2. **Normalize for known differences** — before comparing, identify the differences that would make raw comparison misleading (partner type, cycle stage, service area size, market competition level)
3. **Side-by-side table** — the core comparative output
4. **Interpretation** — what the comparison reveals, with explicit acknowledgment of what the comparison cannot tell you
5. **Caveats** — where the comparison is imperfect

---

## The fundamental challenge: making comparisons meaningful

Most apples-to-apples comparisons between partners are imperfect because partners differ on many dimensions:

- Partner type (hyper-local vs. multi-city vs. regional)
- Cycle stage (new partner in month 2 vs. established partner in cycle 3)
- Service mix (single-service vs. broad-service)
- Market competition (Denver metro vs. rural Colorado)
- Pre-migration baseline quality (partners starting from position 80 vs. partners starting from position 15)

The skill's job is to surface these differences, not pretend they don't exist. A comparison that says "Partner A is outperforming Partner B" without acknowledging that A is in month 5 and B is in month 2 is misleading.

---

## Typical comparative questions and their patterns

**"Which partners are doing best?"** — pipeline-wide comparison, usually better served by the `pipeline_aggregate` pattern. Use comparative only if the question specifies a small, directly-comparable set.

**"How does Aurora compare to Denver as a service area?"** — intra-partner geographic comparison. Usually meaningful if both service areas have similar business investment level.

**"Is the consolidation approach working better than the optimize-in-place approach?"** — cross-intervention comparison. Requires enough instances of each to be meaningful (at least 3-5 of each).

**"How did cycle 2 compare to cycle 1 for this partner?"** — intra-partner temporal comparison. Typically the most defensible comparison because most variables are held constant.

---

## Caveats to always consider

- **Comparability**: state explicitly what makes the compared entities comparable (or not)
- **Sample size**: small samples produce noisy comparisons; flag when n is small
- **Time alignment**: compare the same windows (month 3 of cycle 1 vs. month 3 of cycle 2), not calendar-aligned windows, for intra-partner temporal comparisons
- **Starting conditions**: a partner starting from position 40 has more headroom than a partner starting from position 8; growth rates alone don't capture this

---

## When to decline the comparison

If the entities being compared are not meaningfully comparable (different partner types, different cycle stages, incompatible markets), the skill should say so rather than produce a misleading side-by-side. "These two partners aren't comparable on this metric because [reasons]" is a valid output.
