# Diagnostic Analysis Pattern

Structure for questions about why something happened. Typical forms: "why did X drop," "what's causing Y," "is Z normal or concerning," "what explains the movement in A."

Diagnostic analysis is where analytical discipline matters most, because the temptation to pick a single confident-sounding cause is strong. The skill resists this temptation.

---

## The core arc

Every diagnostic analysis follows this structure:

1. **Restate the observation** — describe what happened in precise terms (metric, magnitude, time window). This separates description from explanation and grounds the hypotheses in data.
2. **Range of plausible explanations** — enumerate the hypotheses that could explain what happened. Be comprehensive; don't jump to the most interesting one.
3. **Evidence for/against each hypothesis** — for each hypothesis, what in the available data supports or rules it out.
4. **Most likely explanation** — based on the evidence, which hypothesis is most supported. Stated with appropriate confidence.
5. **What would strengthen the analysis** — what additional data or time would help confirm or rule out the leading hypothesis.

---

## Common diagnostic hypotheses for SEO

When a partner's metrics move unexpectedly, the usual suspects (in rough order of frequency):

**Traffic drops**:
1. Google algorithm update (Core Updates, spam updates, helpful content updates)
2. Indexation change (pages dropped from index, new noindex accidentally applied, sitemap issue)
3. Site migration or URL change (redirects broken, old URLs 404ing)
4. CMS or theme update that changed page structure
5. Competitor action (competitor launched new pages, won featured snippets, improved GBP)
6. Seasonal variance (especially for seasonal businesses in shoulder seasons)
7. Query mix shift (search demand moved toward queries the partner doesn't rank for)
8. Technical issue (site slowdown, CWV deterioration, mobile rendering issue)
9. Manual action / penalty (rare but possible)
10. GSC reporting glitch (occasional; usually resolves on its own within a week)

**Ranking drops on specific keywords**:
1. SERP feature change (Local Pack appeared, Featured Snippet added, AI Overviews eating SERP real estate)
2. Competitor ranked above the partner
3. Page content changed in a way that reduced relevance
4. Lost backlinks
5. Cannibalization — a new partner page targeting the same keyword split ranking signal
6. Seasonal query intent shift
7. Algorithm update affecting the specific vertical

**Traffic increases** (diagnosing why something worked):
1. Ranking improvement from completed optimization work
2. Seasonal surge (peak season for the partner's services)
3. Algorithm update favorable to the partner's content type
4. New indexed pages capturing new queries
5. Improved CTR from meta description changes or SERP feature capture
6. Referral / direct traffic surge showing up as impressions via branded search
7. External attention (news coverage, social virality)

For each question, think through which hypotheses are plausible given the partner's context, then gather the evidence for/against each.

---

## The evidence-gathering step

For each hypothesis, ask: **what would I see in the data if this hypothesis were true?**

If the data shows that pattern, evidence for the hypothesis. If the data shows the opposite pattern, evidence against. If the data is silent, note that too.

Examples:

**Hypothesis: Google algorithm update caused the impressions drop**
- Evidence for: the drop date coincides with a known algorithm rollout; the drop affects multiple keyword types equally; similar drops visible across the partner's vertical in public trackers
- Evidence against: the drop preceded the update rollout; only specific keyword clusters dropped (not across the board); similar sites didn't see drops

**Hypothesis: new page cannibalized existing page**
- Evidence for: the cannibalized page's impressions dropped the same week the new page launched; the new page is ranking above/below the original for the same queries; both pages appear in SERPs for the same keyword
- Evidence against: the new page isn't indexed yet; the drop began before the new page published; GSC shows different queries triggering each page

**Hypothesis: seasonal variance**
- Evidence for: year-over-year comparison shows similar drop at the same time last year; the partner's industry is known to be seasonal in the affected direction; the metric is recovering as the season progresses
- Evidence against: year-over-year shows growth, not a drop; the pattern is sharper/steeper than typical seasonal variance; other seasonal partners aren't showing the same pattern

---

## Ranking the hypotheses

After gathering evidence, sort hypotheses by how well the evidence supports them:

- **Most likely** — hypothesis with strong positive evidence and no disqualifying evidence against it
- **Possible** — hypothesis with some positive evidence but also some evidence against, or hypothesis with thin positive evidence that can't be ruled out
- **Unlikely** — hypothesis with disqualifying evidence against it
- **Unknown** — hypothesis that can't be confirmed or ruled out with available data

The "Unknown" category is real and underused. When you genuinely can't determine whether something is the cause, say so.

---

## Confidence calibration for diagnostic output

**High confidence** — one hypothesis has strong positive evidence and all alternatives have disqualifying evidence against them.
- "The impressions drop is almost certainly caused by the sitemap regression on March 12; GSC shows 200+ URLs dropped from the index starting that day, and the affected URLs are exactly the ones missing from the current sitemap."

**Medium confidence** — one hypothesis has the best evidence, but one or two alternatives can't be fully ruled out.
- "The most likely cause is the Core Update rolled out March 12, based on timing and the partner's vertical being affected in public trackers. However, new location pages also launched March 8 — the two can't be cleanly separated with the data available."

**Low confidence** — multiple hypotheses remain plausible; the evidence doesn't distinguish them.
- "Three explanations remain plausible: Core Update effects, query mix shift, and normal weekly variance in a small-volume niche. At this data granularity, we can't distinguish them. Recommend watching another 3-4 weeks before acting."

Low confidence is a valid conclusion when the data genuinely doesn't support more. Manufacturing a confident-sounding answer from thin data is worse than acknowledging uncertainty.

---

## When to recommend waiting

For many diagnostic questions about recent, small changes, the honest answer is "it's too early to tell." The skill should comfortably recommend waiting for more data when:

- The observation is 1-2 weeks old (single week = noise)
- The partner's industry has high weekly variance
- The magnitude of the change is within the partner's normal week-to-week range
- There are no urgent business reasons to act immediately

Recommending waiting is not a non-answer. It's the honest answer when the data isn't ready.

---

## What would strengthen the analysis

Every diagnostic analysis closes with what could be gathered or observed to firm up the conclusion. Examples:

- "Fresh GSC data pull would show whether the drop continued past the current data window"
- "Screaming Frog crawl would confirm whether the sitemap regression also affected indexable status"
- "4 more weeks of data would distinguish seasonal variance from genuine trend"
- "Competitor rank check for the affected keywords would show whether a competitor captured the lost positions"

The list should be practical — things the engineer can actually do or wait for — not theoretical.

---

## Common mistakes to avoid

**Jumping to the most interesting hypothesis**. Algorithm updates are interesting. They're also over-attributed. Usually the cause is more mundane (indexation, seasonality, variance).

**Ignoring available data that complicates the story**. If the timing doesn't match the hypothesis, say so. Don't gloss.

**Confusing correlation with causation**. "X happened, then Y happened" is correlation. "X caused Y" requires evidence that the mechanism exists and rules out other explanations.

**Presenting low-confidence analysis as high-confidence**. Uncertainty in the conclusion should be visible in the output language.

**Recommending action on thin evidence**. When the diagnostic is uncertain, the action should usually be "gather more data" or "wait and observe," not "change strategy based on this early signal."
