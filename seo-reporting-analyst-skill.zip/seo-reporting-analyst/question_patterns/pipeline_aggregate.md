# Pipeline-Wide Aggregate Pattern

Structure for questions about the full partner portfolio. Typical forms: "which partners are overdue for cycle close," "what's shipped this quarter across all partners," "where is each partner in their cycle."

---

## Note on this pattern

This pattern file is a starting scaffold. Pipeline-wide questions get more sophisticated as the partner base grows. The patterns here assume an MVP context (10-30 migrated partners); expand this file as portfolio analytics become more important in Phase 2/3.

---

## The core arc

1. **State the question scope** — which partners are included, which are excluded, why
2. **Summary finding** — the headline answer in 1-2 sentences
3. **Aggregate table** — one row per partner with the relevant metrics
4. **Outliers and patterns** — partners that stand out (positively or negatively), patterns that span partners
5. **Individual investigation suggestions** — partners worth looking at in depth

---

## Table structure by question type

**"Where is each partner in their cycle?"** (pipeline health snapshot)

| Partner | Cycle # | Cycle start | Cycle month | Deliverables shipped / planned | Status |
|---|---|---|---|---|---|
| Mile High Roofing | 2 | Oct 2026 | 4 of 6 | 3 / 4 pages, 2 / 3 optimizations | On track |
| Boulder Plumbing | 1 | Jan 2027 | 2 of 6 | 0 / 3 pages, 1 / 2 optimizations | Early — expected |
| [etc.] | | | | | |

**"What shipped this quarter across all partners?"** (aggregate delivery summary)

| Metric | Q1 2027 total | vs. Q4 2026 |
|---|---|---|
| Pages shipped | 14 | +40% |
| Optimizations completed | 9 | +29% |
| Backlinks acquired | 37 | +18% |
| Consolidations executed | 3 | +50% |

**"Which partners need attention?"** (exceptions report)

| Partner | Exception type | Details | Recommended action |
|---|---|---|---|
| Partner A | Cycle overdue | Cycle was supposed to close 3 weeks ago | Prioritize cycle close this week |
| Partner B | Transition window ending | Day 85 of 90-day transition | Final monitoring check due |
| Partner C | Underperforming vs. cycle goals | 2 of 4 priority keywords still beyond striking distance | Mid-cycle strategy review |

---

## Outliers and patterns

After the table, surface what's worth noticing:

- **Performance outliers**: partners doing much better or worse than the portfolio average
- **Timing patterns**: partners whose cycles are bunching up (too many cycle-closes in the same month, for example)
- **Common issues**: exceptions that affect multiple partners (if several partners have overdue cycle closes, that's a workflow issue, not a partner issue)
- **Throughput trends**: aggregate delivery rate changing in notable ways

---

## Caveats to always consider

- **Comparability**: partners at different cycle stages aren't directly comparable on outcomes; be explicit about what's being measured against what
- **Sample size**: with <10 migrated partners, aggregate averages are highly variable
- **Migration timing skew**: if most migrations happened in a narrow window, "trends" in aggregate metrics are really just "all partners hitting the same cycle stage at the same time"

---

## When to suggest individual investigation

Pipeline-wide aggregate views are useful for orientation but often don't tell you what to do next. Every aggregate should end with "here are 1-3 partners worth looking at individually" — the ones whose situation the aggregate flagged as exceptional.
