# Trend Analysis Pattern

Structure for questions about how metrics have moved over a time window. Typical forms: "how is [partner] trending," "what's happening with [keyword/page]," "is [specific initiative] working."

---

## The core arc

Every trend analysis follows this structure:

1. **Headline finding** (1-2 sentences) — the one thing the reader should know if they read nothing else
2. **Date range and data freshness** — state the window and when the data was pulled
3. **Key metrics** — a compact table of the most relevant metrics showing current, prior period, absolute change, relative change
4. **Interpretation** — 2-4 paragraphs explaining what the numbers mean in context (seasonal, cycle stage, recent actions)
5. **Caveats** — any data gaps, uncertainty, or context that qualifies the interpretation

---

## Choosing the right time window

Default to trailing 90 days unless the question specifies otherwise. Other useful windows:

- **Trailing 30 days** — for recent-change questions where a 90-day window would dilute the signal
- **Trailing 90 days** — default for trend questions, balances signal and freshness
- **Since cycle start** — useful for "is the cycle working" questions
- **Year-over-year** — essential for seasonal businesses
- **Pre/post a specific event** — useful after a known change (consolidation, redirect, new page launch)

If two windows tell different stories, show both. Don't pick the window that flatters the answer.

---

## The key metrics table

Always include these metrics when available:
- Impressions
- Clicks
- Average position
- CTR (clicks / impressions)
- Indexed pages (when relevant to the question)

Additional metrics when relevant:
- Specific keyword positions (for keyword-focused trend questions)
- Conversions / form fills (only if the partner has conversion tracking configured)
- New backlinks acquired in the window

Table format:

| Metric | Prior period (dates) | Current period (dates) | Absolute change | Relative change |
|---|---|---|---|---|
| Impressions | 18,400 | 20,650 | +2,250 | +12.2% |
| Clicks | 540 | 585 | +45 | +8.3% |
| Average position | 18.4 | 15.2 | -3.2 (better) | — |
| CTR | 2.9% | 2.8% | -0.1pp | — |

Notes:
- For position, "better" = lower number; always explain direction
- Relative change isn't meaningful for average position or CTR (use absolute)
- Percentage points (pp) for CTR changes to avoid confusion with relative % change

---

## Interpretation paragraphs

This is where the analytical discipline matters most. The interpretation covers:

**What moved meaningfully** — metrics that shifted beyond normal variance. Don't treat every small movement as meaningful.

**What didn't move that you'd expect to** — if rankings improved but clicks didn't grow, flag it. If a new page was published but impressions didn't shift, flag it. These gaps often point to the most interesting analysis.

**Seasonal context** — was the window being compared seasonally equivalent? If not, year-over-year is probably a better frame.

**Cycle stage context** — where is the partner in their cycle? Month 1-2 effects are mostly baseline; month 3-4 is when on-page changes start showing; month 5-6 is when backlink effects mature.

**Recent actions correlation** — did anything the pipeline did recently line up with the observed changes? Be careful about causation claims; correlation is what the data shows, causation requires evidence.

---

## Caveats to always consider

- **Data freshness**: GSC has a ~3 day lag. DataForSEO cache may be older than the analysis window.
- **Weekly variance**: single-week movements are usually noise.
- **SERP feature shifts**: Local Pack changes, Featured Snippet appearances, People Also Ask expansion can shift CTR dramatically without any ranking change on the partner's side.
- **Query mix**: impressions can grow from more queries matching, not better rankings. Clicks can grow from better CTR on existing rankings, not from rank improvement. Distinguish these where possible.
- **Indexation changes**: a drop in impressions could mean a drop in indexed pages. Check.

---

## Common mistakes to avoid

**Reporting position improvements without traffic context**. Rankings matter only insofar as they produce traffic. Always pair.

**Treating short windows as trends**. A week of movement is rarely meaningful. State the window.

**Presenting correlation as causation**. "Impressions dropped after X launched" is correlation. "X caused the drop" requires evidence.

**Cherry-picking favorable windows**. If 30-day is up but 90-day is flat, mention both.

**Ignoring seasonal context**. February-to-March comparisons for seasonal businesses are usually misleading.
