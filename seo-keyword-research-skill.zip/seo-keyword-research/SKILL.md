---
name: seo-keyword-research
description: Use this skill whenever a partner needs a keyword target list generated or refreshed — at cycle start (every 6 months), during onboarding, or when a partner adds a new service or service area mid-cycle. Takes a partner profile, GSC historical query data, competitor domains, and (optionally) DataForSEO-pulled volume and difficulty data, and produces a scored, clustered, prioritized keyword target list of 40–80 keywords. Designed for local service business partners. Do NOT use this skill to generate page roadmaps or content briefs — that belongs to the seo-strategy-light skill, which runs after this one.
---

# SEO Keyword Research

This skill produces a prioritized keyword target list for a partner's upcoming 6-month cycle. It takes three kinds of input — partner context, historical performance data from GSC, and (optionally) external keyword data from DataForSEO — and produces a scored, clustered list of 40–80 target keywords.

The skill is deterministic on scoring (fixed weights, reproducible ranking) but interpretive on clustering and intent classification (Claude applies judgment within defined rules).

## When to use this skill

Activate when the engineer (or tool) needs a keyword target list generated for a partner. Specifically:

- At the start of each 6-month cycle per partner
- During partner onboarding, as part of the strategy phase
- Mid-cycle if the partner adds a new service or service area
- When the caller explicitly says "generate keyword research for [partner]"

Do not use for:
- Generating page roadmaps or strategy docs → use `seo-strategy-light`
- Generating title tags or meta descriptions → use `seo-technical-package`
- Generating content → use `seo-body-content` (when that exists)
- Backlink prospecting → different workflow, different skill

## Required inputs

The caller must provide, in structured form:

1. **Partner profile** (object)
   - `business_name` (string)
   - `business_type` (string — e.g. "Plumber", "RoofingContractor", "Dentist")
   - `services` (array of service names — e.g. ["Roof Repair", "Roof Replacement", "Gutter Installation"])
   - `service_areas` (array of cities, towns, or regions served — e.g. ["Denver", "Aurora", "Lakewood"])
   - `primary_location` (object: `locality`, `region` — the partner's physical base, not necessarily the same as service_areas)
   - `partner_type` (enum: `hyper_local` | `multi_city_local` | `regional` — see "Partner type classification" below)
   - `priority_services` (optional array — services the MD/MC wants emphasized this cycle)
   - `priority_locations` (optional array — service areas to emphasize this cycle)

2. **GSC historical query data** (array of objects)
   - Each object: `query` (string), `impressions` (number), `clicks` (number), `ctr` (number, 0–1), `average_position` (number, 1–100+)
   - Should cover trailing 12 months where available
   - If not available, caller should indicate `gsc_data_available: false` and skip this input

3. **Competitor domains** (array of strings)
   - 3–5 direct competitor domains, confirmed with MD/MC
   - Optional but strongly recommended — significantly improves keyword discovery

4. **DataForSEO keyword data** (optional, but expected when tool-invoked)
   - Array of objects, one per keyword
   - Each object: `keyword` (string), `search_volume` (number), `keyword_difficulty` (number, 0–100), `cpc` (number), `competition_level` (enum: `LOW` | `MEDIUM` | `HIGH`)
   - If not provided, the skill falls back to Claude-estimated relative rankings (less reliable but usable for initial scoping)

5. **Scoring weight overrides** (optional object)
   - Allows the caller to override the default scoring weights (see Scoring below)
   - Each override is a decimal weight that sums to 1.0 across all four factors
   - If not provided, defaults based on partner type are used

6. **Prior cycle target keywords** (optional array of strings)
   - Keywords targeted in the previous cycle
   - Used to identify continuity candidates and avoid unnecessary churn

## Output format

Return a single JSON object with this structure:

```json
{
  "target_keyword_count": "integer (40–80)",
  "clusters": [
    {
      "cluster_name": "string (descriptive, e.g. 'Roof Repair Services')",
      "cluster_theme": "string (brief description of the intent/topic)",
      "primary_service": "string (maps to a service from partner profile, or 'cross-service')",
      "primary_geography": "string (maps to a service area, or 'partner-wide')",
      "keywords": [
        {
          "keyword": "string",
          "search_volume": "number or null",
          "keyword_difficulty": "number or null",
          "intent": "informational|commercial|transactional|navigational",
          "geographic_relevance": "high|medium|low",
          "current_ranking_position": "number or null (from GSC; null if not currently ranking)",
          "opportunity_score": "number 0-100 (from scoring formula)",
          "is_striking_distance": "boolean (true if current position 11-30)",
          "is_prior_cycle_target": "boolean",
          "rationale": "string (1-2 sentences explaining why this keyword made the list)"
        }
      ]
    }
  ],
  "excluded_keywords": [
    {
      "keyword": "string",
      "exclusion_reason": "string (e.g. 'Volume too low', 'Difficulty too high for partner authority', 'Irrelevant to services', 'Duplicate of approved variant')"
    }
  ],
  "skill_notes": {
    "partner_type_detected": "hyper_local|multi_city_local|regional",
    "scoring_weights_used": {"volume": 0.3, "difficulty": 0.3, "intent": 0.2, "geographic_relevance": 0.2},
    "gsc_data_available": "boolean",
    "dataforseo_data_available": "boolean",
    "total_seeds_considered": "integer",
    "striking_distance_count": "integer",
    "flags_for_engineer_review": ["array of strings — any issues or decisions worth surfacing"]
  }
}
```

## Execution procedure

Follow these steps in order.

1. **Load the scoring rubric** at `rules/scoring_rubric.md` for the authoritative formula and weight defaults.

2. **Detect partner type** if not explicitly provided:
   - `hyper_local`: single city service area, or primary location = single service area
   - `multi_city_local`: 2–10 service areas, generally contiguous
   - `regional`: 10+ service areas or cross-metro/cross-state coverage
   - Partner type affects default scoring weights — hyper-local partners weight geographic relevance more heavily, regional partners less so.

3. **Generate seed keyword candidates** (aim for 80–150 seeds before scoring and filtering):
   - From services × service areas: `[service] + [city]`, `[service] in [city]`, `[city] [service]`, `best [service] in [city]`
   - From services alone: `[service]`, `[service] near me`, `[service] cost`, `[service] services`
   - From GSC: all queries in the provided data (these are proven relevance signals)
   - From competitor domains: if DataForSEO data includes competitor-ranked keywords, include those
   - From common intent modifiers per service: `how much does [service] cost`, `when to [service]`, `[service] warranty`, etc.
   - Include 3–5 modifier variants per seed where natural

4. **Deduplicate**: collapse near-duplicate keywords (e.g. "roof repair Denver" and "Denver roof repair" generally target the same SERP and should be represented once, using the variant with higher search volume if data is available).

5. **Classify intent** for each seed keyword:
   - `informational`: seeking information without intent to transact (e.g. "how often should I replace my roof")
   - `commercial`: researching with future intent to transact (e.g. "best roofers in Denver", "roof replacement cost")
   - `transactional`: ready to act or buy now (e.g. "emergency roof repair Denver", "roofer open now")
   - `navigational`: looking for a specific business (e.g. "Mile High Roofing phone number")
   - For local service businesses, commercial and transactional keywords are the highest priority by default.

6. **Assess geographic relevance** for each seed:
   - `high`: includes a service area explicitly, or is a hyper-local variant ("near me", "in [city]")
   - `medium`: service-focused without geography, but partner serves the region where this query would be relevant
   - `low`: generic or national-scope keyword with weak geographic fit (e.g. "roofing industry statistics")

7. **Apply the scoring formula** (see `rules/scoring_rubric.md` for the full formula):
   - `opportunity_score = (volume_score × w_volume) + (difficulty_score × w_difficulty) + (intent_score × w_intent) + (geographic_relevance_score × w_geo)`
   - All component scores normalized 0–100
   - Weights default by partner type (see rubric); overridable via `scoring_weight_overrides` input

8. **Apply the striking distance bonus**: keywords where GSC shows current position 11–30 get a +10 point bonus to their opportunity score (these are already ranking and can often be moved to page 1 with targeted optimization — highest ROI for engineer time).

9. **Filter and rank**: sort all scored keywords descending by opportunity score. Select the top 40–80 for the target list. Apply these filters to the top-ranked set:
   - Remove keywords with `opportunity_score < 30` (not worth targeting)
   - Remove keywords with keyword_difficulty > 70 unless partner has established authority in that topic cluster
   - Remove keywords where the top 10 SERP results are all national brands with no local option (signals Google doesn't treat this as a local query)
   - If more than 80 keywords survive filtering, cut to the top 80 by opportunity score
   - If fewer than 40 survive, relax filters in this order: opportunity_score threshold → difficulty ceiling → national-brand SERP filter (document relaxation in `skill_notes.flags_for_engineer_review`)

10. **Cluster the final list** into 3–8 clusters (fewer for hyper-local, more for regional):
    - Each cluster groups keywords by primary service + intent alignment
    - Geographic variants of the same service typically stay in the same cluster (unless the partner's service offering is genuinely different per city)
    - Cluster names should be descriptive and MD/MC-readable ("Roof Repair Services", "Emergency Roofing", "Roof Replacement Research")
    - Every keyword belongs to exactly one cluster

11. **Generate the output JSON** per the format above. Populate `skill_notes.flags_for_engineer_review` with:
    - Any case where the skill had to relax filters to reach 40 keywords
    - Any case where a prior cycle target was deliberately dropped (and why)
    - Any case where DataForSEO data was missing and Claude-estimated rankings were used
    - Any keyword where intent or geographic relevance is genuinely ambiguous

## Scoring defaults by partner type

**Fixed defaults** applied when `scoring_weight_overrides` is not provided in the input:

| Partner type | Volume weight | Difficulty weight | Intent weight | Geographic relevance weight |
|---|---|---|---|---|
| `hyper_local` | 0.25 | 0.25 | 0.20 | 0.30 |
| `multi_city_local` | 0.30 | 0.30 | 0.20 | 0.20 |
| `regional` | 0.35 | 0.30 | 0.20 | 0.15 |

Weights always sum to 1.0.

**Override behavior**: if the caller provides `scoring_weight_overrides`, the provided weights replace the defaults. The skill validates that the override weights sum to 1.0 (within 0.01 tolerance); if not, the override is rejected and defaults are used with a flag in `skill_notes.flags_for_engineer_review`.

## Constraints and guardrails

- **Never fabricate search volume or difficulty data.** If DataForSEO data isn't provided for a keyword, mark `search_volume: null` and `keyword_difficulty: null` in the output. Use Claude judgment for relative ranking only, and flag this explicitly in `skill_notes.dataforseo_data_available`.
- **Never invent competitor data.** If the caller doesn't provide competitor domains, skip competitor-derived seed generation. Do not guess at competitors based on partner type.
- **Never recommend keywords outside the partner's actual services.** If the partner profile says they do roof repair and roof replacement, don't add "gutter cleaning" to the target list even if it's a high-opportunity keyword — flag it in the output as an "adjacent service to consider adding" only if it's a strong match.
- **Never pad the list.** If only 35 keywords meet the quality threshold, return 35 (with documented filter relaxation attempts in `skill_notes`). Don't force the count to 40 by including weak keywords.
- **Respect prior cycle continuity.** Keywords that were targeted in the prior cycle and are still relevant should generally carry forward — don't churn the keyword list without reason. Document any dropped prior-cycle targets in `skill_notes.flags_for_engineer_review`.

## Reference files

The skill includes these reference files, loaded on demand when their content is needed:

- `rules/scoring_rubric.md` — full scoring formula, component score calculations, partner-type weight defaults
- `rules/intent_classification.md` — detailed rules for classifying keyword intent
- `examples/hyper_local_example.json` — worked example for a hyper-local partner (single-city plumber)
- `examples/multi_city_example.json` — worked example for a multi-city local partner (Denver metro roofer)
