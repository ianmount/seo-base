# Keyword Scoring Rubric

Authoritative reference for the `seo-keyword-research` skill's scoring formula and component calculations. When the main SKILL.md summary is ambiguous, this file is the source of truth.

---

## Scoring formula

For each candidate keyword, compute an opportunity score from 0 to 100:

```
opportunity_score =
    (volume_score × weight_volume) +
    (difficulty_score × weight_difficulty) +
    (intent_score × weight_intent) +
    (geographic_relevance_score × weight_geographic_relevance)
```

Each component score is normalized 0–100. Weights sum to 1.0.

Apply a +10 bonus to the final score if the keyword is currently ranking in GSC positions 11–30 ("striking distance"). Cap the bonused score at 100.

---

## Component: Volume score (0–100)

Converts raw monthly search volume into a normalized 0–100 score.

| Monthly search volume | Volume score |
|---|---|
| 0–10 | 0 |
| 11–50 | 20 |
| 51–150 | 40 |
| 151–500 | 60 |
| 501–1,500 | 75 |
| 1,501–5,000 | 85 |
| 5,001–15,000 | 92 |
| 15,001+ | 100 |

If search volume is unknown (DataForSEO data not available), use Claude judgment to estimate relative volume category based on:
- How specific the keyword is (longer-tail keywords generally have lower volume)
- Whether the keyword includes a geographic modifier (local keywords typically have lower volume than national equivalents)
- Whether the service itself is common (roof repair vs. helical pier installation)

Flag the use of estimated volumes in `skill_notes.flags_for_engineer_review`.

---

## Component: Difficulty score (0–100)

Inverts keyword difficulty so higher values mean better opportunity. A low-difficulty keyword earns a high difficulty_score.

| Keyword difficulty (DataForSEO) | Difficulty score |
|---|---|
| 0–10 | 100 |
| 11–20 | 90 |
| 21–30 | 80 |
| 31–40 | 65 |
| 41–50 | 50 |
| 51–60 | 35 |
| 61–70 | 20 |
| 71–80 | 10 |
| 81–100 | 0 |

If keyword difficulty is unknown, use Claude judgment based on:
- SERP composition (if the top 10 are all high-authority domains like Wikipedia, government sites, or major brands, difficulty is high)
- Commercial intent (commercial/transactional keywords tend to have higher difficulty than informational)
- Geographic modifier presence (local keywords are often lower difficulty than national equivalents)

---

## Component: Intent score (0–100)

Maps keyword intent to opportunity for local service businesses specifically.

| Intent | Intent score | Reasoning |
|---|---|---|
| `transactional` | 100 | User is ready to act. Highest conversion likelihood. |
| `commercial` | 85 | User is researching with near-term intent. High value. |
| `informational` | 50 | User is learning. Valuable for top-of-funnel content but lower direct conversion. |
| `navigational` | 20 | User is looking for a specific business. Unless the business is the partner, low value. |

See `intent_classification.md` for detailed rules on how to classify intent.

---

## Component: Geographic relevance score (0–100)

Measures how well the keyword matches the partner's service area coverage.

| Geographic relevance | Score | Criteria |
|---|---|---|
| `high` | 100 | Keyword explicitly includes one of the partner's service areas, OR includes "near me" / "in [my area]" modifiers |
| `medium` | 60 | Service-focused keyword without explicit geography, but falls within a natural geographic scope the partner serves |
| `low` | 20 | Generic or national-scope keyword with weak geographic fit |

**Edge cases:**
- Keywords that include a service area the partner does NOT serve should be excluded entirely (geographic_relevance = low AND typically filtered out at the quality threshold stage)
- Keywords that include a city adjacent to the partner's service area but not explicitly served: `medium` if the partner could plausibly extend service there, `low` if they can't

---

## Partner type weight defaults

Applied when `scoring_weight_overrides` is not provided in the skill input.

### Hyper-local partner (single city service area)

| Weight | Value |
|---|---|
| Volume | 0.25 |
| Difficulty | 0.25 |
| Intent | 0.20 |
| Geographic relevance | 0.30 |

**Rationale**: For a partner serving only one city, geographic relevance is disproportionately important. A high-volume keyword with low geographic relevance won't convert for this partner. Volume weight is reduced because hyper-local searches have inherently lower volumes.

### Multi-city local partner (2–10 service areas, contiguous)

| Weight | Value |
|---|---|
| Volume | 0.30 |
| Difficulty | 0.30 |
| Intent | 0.20 |
| Geographic relevance | 0.20 |

**Rationale**: This is the default balance. Geographic relevance still matters but is more forgiving because the partner covers multiple cities. Volume and difficulty are weighted equally.

### Regional partner (10+ service areas or cross-metro/cross-state)

| Weight | Value |
|---|---|
| Volume | 0.35 |
| Difficulty | 0.30 |
| Intent | 0.20 |
| Geographic relevance | 0.15 |

**Rationale**: Regional partners can serve a broad geographic footprint, so geographic specificity matters less per keyword. Volume gets more weight because the addressable market is larger.

---

## Striking distance bonus

Any keyword currently ranking in GSC positions 11–30 receives a +10 point bonus to its final opportunity score, capped at 100.

**Rationale**: Keywords already ranking in positions 11–30 are the highest-ROI optimization targets. Moving a keyword from position 15 to position 5 is typically achievable with targeted on-page optimization (title rewrites, internal links, content expansion) and produces meaningful traffic gains — often more valuable than creating a new page for a higher-volume keyword that's starting from zero.

The +10 bonus ensures these keywords surface in the final target list even if their raw opportunity score is moderate.

**Example**:
- Keyword: "roof repair Denver cost"
- Current GSC position: 17
- Raw opportunity score: 62
- Final score with striking distance bonus: 72

---

## Worked scoring example

**Keyword**: "emergency roof repair Denver"
**Partner**: Multi-city local Denver-metro roofer
**Data available**:
- DataForSEO search volume: 390/month
- DataForSEO keyword difficulty: 38
- GSC current position: none (keyword not currently ranking)
- Intent assessment: transactional (includes "emergency", user is ready to act now)
- Geographic relevance: high (includes "Denver", one of partner's service areas)

**Component scores**:
- Volume score: 60 (volume falls in 151–500 bucket)
- Difficulty score: 65 (difficulty falls in 31–40 bucket)
- Intent score: 100 (transactional)
- Geographic relevance score: 100 (high)

**Weights** (multi-city local defaults):
- Volume: 0.30
- Difficulty: 0.30
- Intent: 0.20
- Geographic relevance: 0.20

**Calculation**:
```
opportunity_score = (60 × 0.30) + (65 × 0.30) + (100 × 0.20) + (100 × 0.20)
                  = 18 + 19.5 + 20 + 20
                  = 77.5
```

**Striking distance bonus**: None (keyword not currently ranking).

**Final opportunity score**: 77.5 → rounded to 78.

This is a high-quality target keyword for this partner. It would likely land in the top 10 of the target list.

---

## Override weight validation

When the caller provides `scoring_weight_overrides`, validate:

1. Object contains exactly these four keys: `volume`, `difficulty`, `intent`, `geographic_relevance`
2. All four values are numbers between 0 and 1 (inclusive)
3. Sum of all four values is 1.0 (within 0.01 tolerance)

If any validation fails, reject the override, fall back to partner-type defaults, and flag:

```
"flags_for_engineer_review": [
  "Scoring weight override was provided but did not pass validation (reason: [specific reason]). Defaults for partner type '[partner_type]' were used instead."
]
```
