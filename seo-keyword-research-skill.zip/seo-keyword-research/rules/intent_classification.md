# Intent Classification Rules

Detailed rules for classifying keyword intent as `informational`, `commercial`, `transactional`, or `navigational`. When the skill is classifying a keyword and the rules here conflict with general judgment, these rules take precedence.

---

## The four intent categories

### Transactional

The user is ready to act now. They want to hire, book, purchase, or engage immediately.

**Signals**:
- Includes urgency modifiers: "emergency", "24/7", "same day", "today", "now", "open now"
- Includes hiring or booking language: "hire", "book", "schedule", "call"
- Includes action-oriented intent: "fix", "repair", "install" paired with immediate context
- Includes pricing with intent to buy: "free estimate", "quote", "free consultation"

**Examples**:
- "emergency roof repair Denver"
- "book dental appointment near me"
- "hire plumber 24/7 Austin"
- "roof repair free estimate"
- "same day AC repair"

### Commercial

The user is actively researching with near-term intent to transact, but not ready to act this minute.

**Signals**:
- Comparison language: "best", "top", "vs", "compare", "reviews"
- Price research without urgency: "cost", "price", "rates", "how much"
- Service research: "near me" without urgency modifiers, "in [city]" service searches
- Selection criteria: "how to choose", "what to look for"

**Examples**:
- "best roofers in Denver"
- "roof repair cost"
- "top rated dentists Austin"
- "how much does a new roof cost"
- "dentist near me"
- "how to choose a plumber"

### Informational

The user is learning or researching without immediate intent to transact.

**Signals**:
- Question words at the start: "how", "what", "when", "why", "can"
- Learning language: "guide", "tips", "explained", "meaning", "definition"
- Preventative or educational topics
- No pricing, hiring, or scheduling context

**Examples**:
- "how often should I replace my roof"
- "what causes roof leaks"
- "signs of a failing water heater"
- "when to see a dentist"
- "why is my AC making noise"

### Navigational

The user is looking for a specific business, website, or brand.

**Signals**:
- Includes a specific business name
- Includes brand-specific queries: "[brand] phone number", "[brand] hours", "[brand] login"
- Includes a specific product model name

**Examples**:
- "Mile High Roofing phone number"
- "Dr. Smith DDS hours"
- "Austin Plumbing Co reviews"

Unless the navigational query is for the partner's own business (where it represents brand traffic, not competitive opportunity), navigational keywords have low opportunity value for local service SEO.

---

## Ambiguous cases — how to decide

Many keywords have mixed intent signals. Use these tiebreaker rules in order:

### Tiebreaker 1: Urgency or action wins

If the keyword contains any transactional signal (urgency, hiring, booking), classify as transactional even if it also contains commercial or informational signals.

Example: "emergency roof repair cost Denver" — contains "cost" (commercial) but "emergency" (transactional). Classify as transactional.

### Tiebreaker 2: Comparison or selection language indicates commercial

If the keyword contains "best", "top", "vs", "compare", or similar comparison/selection language, classify as commercial — the user is evaluating options, which is near-term buying intent for local services.

Example: "best roofers in Denver" — comparison language present. Classify as commercial.

### Tiebreaker 3: Question words without action indicate informational

If the keyword starts with a question word (how, what, when, why) and lacks urgency or action language, classify as informational.

Example: "how to choose a roofer" — question word, no urgency. Classify as informational.

Exception: "how much does X cost" — even with question word, the cost framing is commercial research. Classify as commercial.

### Tiebreaker 4: "Near me" without urgency is commercial

"Near me" variants without urgency modifiers are commercial — user is actively looking for providers but not necessarily ready to book immediately.

Example: "dentist near me" — commercial.
Example: "emergency dentist near me" — transactional (emergency modifier wins).

### Tiebreaker 5: Bare service + location is commercial by default

Keywords that are just `[service] [location]` with no other modifiers are commercial — the user is doing local service research.

Example: "roof repair Denver" — commercial.

---

## Intent by keyword modifier — quick reference table

| Modifier | Typical intent |
|---|---|
| emergency | transactional |
| 24/7 | transactional |
| same day | transactional |
| now | transactional |
| open now | transactional |
| free estimate | transactional |
| quote | transactional |
| book | transactional |
| schedule | transactional |
| hire | transactional |
| best | commercial |
| top | commercial |
| top rated | commercial |
| reviews | commercial |
| vs | commercial |
| compare | commercial |
| near me | commercial |
| in [city] | commercial |
| cost | commercial |
| price | commercial |
| rates | commercial |
| how much | commercial |
| how to choose | informational |
| what is | informational |
| signs of | informational |
| why does | informational |
| when to | informational |
| guide | informational |
| tips | informational |
| explained | informational |

---

## Why local service SEO prioritizes commercial and transactional

The `opportunity_score` formula weights `transactional` at 100 and `commercial` at 85 because:

- Local service businesses convert best on keywords with near-term intent
- Informational keywords drive top-of-funnel traffic but rarely convert directly in the local service space
- The pages that rank for informational keywords often need different content treatment (educational depth, long-form guides) than service pages

The skill still includes informational keywords in the target list where the opportunity score is high (usually due to low difficulty and high geographic relevance), but they're the minority of the target list for most local service partners.

**Typical distribution in the final target list for a local service partner**:
- Transactional: 15–25% of target keywords
- Commercial: 55–70% of target keywords
- Informational: 10–25% of target keywords
- Navigational: 0–5% (only partner-branded queries)

Flag it in `skill_notes.flags_for_engineer_review` if the generated distribution falls materially outside these ranges, in case the partner has an unusual service mix or content strategy that explains the skew.
