# Expert Source Angle Template

Structural guide for outreach where the goal is to offer the partner's owner/staff as an expert source for the prospect's future articles, interviews, or research.

This is a longer-arc angle — the outreach doesn't produce an immediate link. Instead, it establishes the sender as a go-to expert the prospect can call on later. Links come downstream when the prospect actually cites the source.

---

## When to use this template

Use when:
- The prospect is a journalist, researcher, or editor who regularly cites expert sources
- The partner's owner or a named staff member has genuine, verifiable expertise (not just "years of experience" but specific credentials, certifications, named roles, published work)
- The partner is willing to respond quickly to future press inquiries (within 24 hours usually)
- The sender is offering availability specifically, not asking for anything immediately

Do NOT use when:
- The partner doesn't have a specific named expert to offer (generic "our team is expert" pitches fail)
- The prospect doesn't write about topics where the partner's expertise is relevant
- The partner can't actually commit to being responsive when called on

---

## The structural arc

### Opener (1–2 sentences)

Reference the specific publication or beat the prospect covers, and state the reason for reaching out.

### Offer availability (2–3 sentences)

Describe the expert's specific expertise and make clear the offer is for future reference, not an immediate ask.

### State credentials (2–3 sentences)

This is where `credibility_points` carries the most weight. Specific credentials, specific press mentions, specific roles.

### Light ask (1 sentence)

The ask is typically to be kept on file — no commitment asked of the prospect.

Patterns that work:
- "If a relevant story comes up, happy to be a quick source on [topic]. Feel free to keep my contact on file."
- "If you're ever covering [topic area] and want a practitioner perspective, I'm usually responsive within the day."

### Signoff

Standard signature. Phone number is especially relevant here — reporters often want to talk, not email.

---

## Example opener pattern

> "Hi [name], I've seen Colorado Home Report's coverage of Front Range weather events over the past couple years. I wanted to introduce myself briefly as a potential source for future coverage on the roofing/claims side of storm damage stories."

---

## Follow-up note

This angle typically uses only one follow-up (not two), and the follow-up is graceful-exit by default — the prospect has signaled nothing by not replying, and repeated follow-ups on "just keep me on file" asks feel pushy.
