# Unique Data Share Angle Template

Structural guide for outreach where the partner is offering genuinely unique data — proprietary numbers, original survey results, aggregated customer outcomes — to journalists, researchers, or publications that cover the relevant topic area.

This is the highest-potential angle when executed well, because unique data is genuinely scarce and publications love citing it. It's also the angle with the tightest authenticity requirements, because fabricated data is catastrophically damaging if discovered.

---

## When to use this template

Use when:
- The partner has actually collected, commissioned, or aggregated data that isn't already publicly available
- The data is relevant to the prospect's beat or subject matter
- The data is statistically meaningful (not 3 customer anecdotes treated as a dataset)
- The partner is willing to share the methodology behind the data transparently
- The data tells a story that's genuinely useful to the prospect's audience

Do NOT use when:
- The "data" is actually just observations or anecdotal patterns
- The sample size is too small to be statistically meaningful
- The data can't be backed by a transparent methodology
- The data has already been published or is available elsewhere

---

## The structural arc

### Opener (1–2 sentences)

Reference the prospect's coverage area specifically. Get to the data quickly.

Pattern:
- "I'm reaching out because I've seen [prospect publication] cover [topic area] several times this year. We've aggregated some data that might be relevant to future coverage."

### State the data specifically (3–4 sentences)

The data and its scale should be clearly stated. Include the methodology briefly — where the data came from and how it was collected.

Pattern:
- "Over the past [time period], we [data collection action] from [sample description]. A few things we found: [finding 1 with specific number], [finding 2 with specific number], [finding 3 with specific number]."

### Offer the full dataset (1–2 sentences)

State what's available and how detailed.

Pattern:
- "The full dataset includes [breakdown — e.g. geographic breakdown, time series, categorical splits]. Happy to share the raw data, a cleaned summary, or a pre-built chart — whatever format is most useful."

### Light ask (1 sentence)

Pattern:
- "If the data is relevant to a current or upcoming piece, let me know what format would be most useful."

---

## Example opener

> "Hi [name], I've noticed Colorado Home Report has covered post-hail insurance claim patterns several times this year. We have some proprietary claim outcome data that might be relevant for future coverage."
>
> "Since the 2023 Denver hailstorm, we've tracked claim outcomes across 312 residential roof inspections in the Front Range area. A few findings: initial insurance offers missed documentable damage in 41% of inspections, average gap between initial offer and final settlement was $4,800, and the timeline from claim to settlement averaged 67 days."
>
> "The full dataset includes geographic breakdowns by zip code, damage-type categorization, and insurer-specific outcomes. Happy to share the raw data, a summary one-pager, or a pre-built chart — whatever format works best for your coverage."
>
> "If this is relevant to an upcoming piece, let me know what format would be most useful."

---

## Authenticity requirements — non-negotiable

The skill refuses to produce data-share outreach when:

- The partner's inputs don't specify the actual dataset size and methodology
- The numbers being cited appear to be invented or rounded suspiciously (e.g. "over 1,000 customers" without specificity)
- The claim of "unique data" is actually publicly available information rebranded
- The partner can't describe the methodology in one or two sentences

If the caller wants to produce data-share outreach but doesn't have the underlying rigor, the skill flags this and recommends either (a) producing outreach using a different angle or (b) completing the data work before the outreach goes out.

---

## Why this angle is especially powerful when legitimate

Journalists and editors love unique data because:
- It gives them something new to write about that their competitors don't have
- It's cite-able in a way that opinion or commentary isn't
- It produces stickier coverage (stories with specific statistics get shared more)

This is why publications that cover the relevant space often respond to legitimate data-share outreach within days, and why the angle can produce high-authority backlinks when the data is genuinely valuable.

It's also why fabricated data is catastrophic — if a journalist cites fabricated numbers and then discovers the fabrication, the resulting correction damages both the journalist and the partner for years.
