# Broken Link Replacement Angle Template

Structural guide for outreach where the goal is to replace a broken outbound link on the prospect's site with a working link to the partner's content.

This is one of the higher-response-rate angles in link building because the sender is genuinely doing the prospect a favor (fixing a broken link) in addition to asking for something.

---

## When to use this template

Use when:
- The prospect's site has a specific outbound link that returns a 404, a 410, or redirects to a clearly irrelevant page
- The partner has content that's a genuine substantive replacement for what the broken link originally pointed to
- The replacement content is comparable in scope and quality to what the original link would have pointed to

Do NOT use when:
- The broken link was to something the partner's content doesn't actually replace (e.g. broken link was to a PDF report, partner's content is a blog post on a different angle)
- The partner's content is thinner or lower-quality than what the broken link pointed to — this is a give-and-take, not a downgrade

---

## The structural arc

### Opener (1–2 sentences)

Establish context and name the broken link specifically. Being direct here is appropriate — this is a service to the prospect, and they'll appreciate knowing about the broken link regardless of whether they want the replacement.

Patterns that work:
- "I was reading through your [guide/article name] and noticed one of the outbound links is returning a 404."
- "Quick heads-up — the link to [general description of broken link] in your [article/guide name] appears to be broken."
- "I came across your [article name] while researching [topic] and wanted to flag that one of the linked sources is no longer live."

### State the broken link (1–2 sentences)

Be specific. The prospect needs enough detail to verify the broken link themselves.

Pattern:
- "The link in the [specific section/paragraph] pointing to [domain or brief description] is returning a 404 (full URL: [broken URL])."

### Offer the replacement (2–3 sentences)

This is the value exchange. State:
1. What the sender has as a replacement
2. Why it's a substantively good replacement (not just "we have an article on the same topic")
3. Where the replacement lives

Pattern:
- "We have a [resource type] on the same topic that would work as a replacement: [URL]. It covers [specific angle] and is specifically focused on [geographic area or niche], which matches the context of your original link."

### The ask (1 sentence)

Low-friction. The ask is specifically to consider the replacement — not just to acknowledge the broken link.

Patterns that work:
- "Up to you if you want to use ours as a replacement — just wanted to flag the broken link either way."
- "If it's useful as a replacement, great; if not, at least now you know about the 404."
- "Happy if you want to drop our link in as a replacement, or just update with any working resource you prefer."

### Signoff

Standard signature.

---

## Example of a full initial email using this template

**Subject**: Broken link in your Denver roofing guide

> Hi Marla,
>
> Quick heads-up — I was reading through your "Complete Guide to Denver Home Maintenance" and noticed the link in the "When to Call a Professional" section pointing to denverroofadvice.com is returning a 404. Full broken URL: denverroofadvice.com/when-to-replace.
>
> We have a similar guide on when to replace vs. repair a roof, specifically written for Denver homeowners: milehighroofing.example.com/blog/repair-vs-replace. It covers the Colorado climate factors (hail frequency, UV exposure, freeze-thaw cycles) that the original link seemed to be filling.
>
> Up to you whether it's useful as a replacement — just wanted to flag the broken link either way.
>
> Thanks,
>
> Sarah Hernandez
> Owner, Mile High Roofing Co.
> milehighroofing.example.com

### Why this works

- Opener immediately states the reason for reaching out — no filler
- Specific details about the broken link's location and URL let the prospect verify quickly
- Replacement offer is specific and states the substantive match (Colorado climate factors)
- Ask is framed as "up to you" — low-friction and respects the prospect's decision
- The sender has provided a genuine favor (broken link report) regardless of whether the prospect uses the replacement

---

## Follow-up templates

### First follow-up (4 business days later)

Structure: Briefly reference the broken link. No pressure. Often adds value by offering additional context.

Example:
> Hi Marla,
>
> Following up briefly on the broken link in your maintenance guide. Didn't want it to get lost in the inbox.
>
> If it's helpful, I can pull the exact position in the guide where the dead link appears — just let me know.
>
> Thanks,
> Sarah

### Second follow-up (10 business days later)

Structure: Graceful exit. Often doesn't even repeat the ask — just a polite signoff.

Example:
> Hi Marla,
>
> Totally understand if you haven't had a chance to update the guide or if our resource isn't the right replacement. I'll leave it here — the broken link's still worth fixing whenever you have a moment, even if you go with a different resource.
>
> All the best,
> Sarah

---

## Special considerations for this angle

### When the broken link is old (5+ years)

Acknowledge the age gracefully: "I realize the guide was published a while back, so you may have intentionally left the link as-is or deprioritized updates. Either way, wanted to flag it."

### When the prospect's site is a large publication with many broken links

The broken link flag is less novel — large sites often have many broken links. The substantive value of the replacement matters more. Lead with the replacement's quality more prominently than the broken-link flag.

### When the replacement is from a partner that competes with the original target

Be honest about it: "Obviously we have a vested interest in the replacement — but the content stands on its own, and the broken link is a broken link either way."

This kind of honesty builds trust and often works better than pretending to be a neutral third party.

---

## Subject line options

- "Broken link in [guide name]"
- "Heads-up: broken link on [page name]"
- "Found a 404 in your [article type]"

Avoid:
- Clickbait ("You won't believe what's broken on your site")
- All caps or excessive punctuation
- "Urgent" framing (it's not urgent)
