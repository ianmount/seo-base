# Local Partnership Angle Template

Structural guide for outreach where the goal is to establish a mutual local business partnership — typically a reciprocal link, a shared referral arrangement, or a co-marketing opportunity.

Unlike resource page or broken link outreach, local partnership outreach is explicitly relationship-building. The ask is for an ongoing connection, not a single link placement. This changes the tone and the arc significantly.

---

## When to use this template

Use when:
- The prospect is a non-competing local business in a complementary space (e.g. a roofer reaching out to a general contractor, a plumber reaching out to a kitchen remodeler, a dentist reaching out to an orthodontist)
- There's a genuine shared customer base between the two businesses
- The partner is open to a real reciprocal arrangement, not just hoping for a one-way link
- The partner can describe specifically what they'd offer the prospect's business in return

Do NOT use when:
- The prospect is a direct competitor (wasting both parties' time)
- The partner has nothing substantive to offer in exchange (no referral volume, no audience to share, no complementary content to cross-promote)
- The partner's geographic area doesn't overlap with the prospect's

---

## The structural arc

### Opener (1–2 sentences)

Establish the local connection and the complementary-business relationship. This is the one outreach angle where a bit more warmth in the opener is appropriate — this is relationship outreach, not transactional.

Patterns that work:
- "I'm reaching out as a fellow [location] business owner — I noticed we operate in adjacent spaces and thought there might be a natural fit."
- "I run [partner business] here in [city] — we focus on [partner's service], which often overlaps with what you do at [prospect business]."
- "I've been seeing [prospect business] come up as one of the go-to [prospect service] providers in [area] and realized we likely serve a lot of the same customers."

### The complementary-fit observation (2–3 sentences)

State specifically how the two businesses' customers overlap or how the services complement each other. Be concrete — vague "we should collaborate" messaging reads as template.

Patterns that work:
- "A lot of the roof repair customers we see are also dealing with [complementary issue] — which is exactly the kind of work you handle. We've been referring those customers out individually but don't have a formal referral arrangement with anyone, and you seem like a natural fit."
- "Homeowners doing a full roof replacement often tackle [related project] at the same time. We've done about 40 full replacements in the last 12 months, and most of those customers asked us for recommendations on [prospect's service]."

### The proposed partnership (2–3 sentences)

State specifically what's being proposed. The proposal should be balanced — give and take, not just an ask.

Patterns that work:
- "I'd be open to a reciprocal referral arrangement — we'd send customers asking about [prospect's service] your way, and we'd appreciate the same for [partner's service]. A mutual link between our sites would make the whole thing more findable for our customers too."
- "I'd love to explore a few things: [option A — concrete], [option B — concrete], or just an informal conversation to figure out if there's a fit. No pressure either way."

### The ask (1 sentence)

The ask for local partnerships is often for a conversation, not an immediate commitment — which is appropriate because partnerships take real discussion.

Patterns that work:
- "Worth a 15-minute conversation to figure out if there's a real fit?"
- "Would it make sense to chat briefly about whether this could work for both of us?"
- "Let me know if you'd like to explore this further — happy to grab a coffee or do a quick call."

For this angle specifically, a call CTA is acceptable because the ask is for relationship-building, not a single transactional link.

### Signoff

Standard signature, possibly with additional local context (partner's years in the market, local associations they're part of).

---

## Example of a full initial email using this template

**Subject**: Fellow Denver business owner — quick partnership idea

> Hi Mike,
>
> I'm reaching out as a fellow Denver-metro business owner. I run Mile High Roofing and noticed we likely serve a lot of the same customers — we handle the roof side of home exterior projects, and your team at Front Range Siding handles the siding side.
>
> A lot of our roof replacement customers ask us if we do siding, or ask for a recommendation. We've been referring those out informally, but we don't have a go-to partner for siding referrals. You seem to be one of the better-reputed crews in the area based on the feedback we've heard from customers.
>
> I'd be open to a reciprocal arrangement — we'd send siding referrals your way when they come up (we typically have 5-10 customers asking per month during roofing season), and we'd appreciate the same when your customers need roofing. A mutual link between our sites would help the whole thing be more findable for our customers too.
>
> Worth a quick 15-minute call to see if there's a real fit?
>
> Thanks,
>
> Sarah Hernandez
> Owner, Mile High Roofing Co.
> 22 years in Denver metro roofing
> milehighroofing.example.com
> (303) 555-0100

### Why this works

- Opener is warm and specific to the local connection
- The fit is stated concretely (roof + siding as paired exterior work)
- The proposal is balanced (reciprocal referrals, reciprocal links)
- Volume claim is specific (5-10 customers per month) — gives the prospect a concrete reason to engage
- Ask is low-friction (15-minute call, not a commitment)
- Signature includes the 22-year tenure, which is relevant for local partnerships

---

## Follow-up templates

### First follow-up (4 business days later)

Structure: Brief, warm, can add a specific nudge like offering a first referral as a gesture.

Example:
> Hi Mike,
>
> Following up on my note last week about a possible referral partnership.
>
> Since I'm going to be referring out siding work regardless, I'm happy to send the next customer your way as a no-strings-attached gesture, whether or not we formalize anything — just curious if a more ongoing arrangement would make sense for you.
>
> Let me know.
>
> Thanks,
> Sarah

### Second follow-up (10 business days later)

Structure: Graceful exit that keeps the door open. Local partnerships sometimes happen months later.

Example:
> Hi Mike,
>
> Understand if now isn't the right time for a partnership conversation. I'll leave it here, and if the topic ever becomes relevant, you're welcome to reach out. In the meantime, if a roofing situation ever comes up where you need a referral, I'm happy to take the call.
>
> All the best,
> Sarah

---

## What makes this angle unique

Local partnership outreach is the one angle where:
- A phone call ask is appropriate (most other angles should stick to email-based asks)
- Warmth in the opener is appropriate (the ask is relational, not transactional)
- The sender can reference volume or scale (referral counts, customer overlap) as part of the pitch
- Follow-ups can extend beyond the standard 2 if the response is positive but slow
- An in-person meeting or coffee is a plausible outcome

This doesn't mean the skill should default to high-warmth outputs — most local partnership outreach still keeps the standard "professional, direct" tone. But the space for warmth is larger here than in other angles.

---

## Risk to flag for engineer review

Local partnership outreach sometimes surfaces competitive concerns that the engineer should evaluate:

- The prospect business might actually compete with the partner in a way the partner hasn't realized
- The partner might not actually be able to deliver the referral volume they're claiming
- The "mutual link" component might violate Google's guidelines on excessive reciprocal linking if done at scale

The skill should flag these in `flags_for_engineer_review` when:
- The partner's proposed referral volume seems unusually large (claim of 20+ referrals/month without data to back it up)
- The prospect's services appear to overlap with partner services enough that referral flow might be one-way in practice
- The partner's `credibility_points` don't establish them as someone a prospect would genuinely want to partner with (e.g. new business with no track record)
