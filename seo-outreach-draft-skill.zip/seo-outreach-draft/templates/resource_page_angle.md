# Resource Page Angle Template

Structural guide for drafting outreach where the goal is to get the partner's page added to the prospect's curated resource list.

This is a template in the sense of "a structural arc," not in the sense of "fill in the blanks." The actual language should be generated fresh each time based on the specific prospect and offer.

---

## When to use this template

Use when:
- The prospect has a page that curates external resources, links, or tools (e.g. "Denver Home Maintenance Resources," "Best Colorado Contractor Tools," "Resources for New Homeowners")
- The partner has a specific page that would genuinely fit the existing curation
- The partner's page is comparable in quality and scope to other items already on the resource list

Do NOT use when:
- The prospect's page is a general blog, not a curated resource list
- The partner's offering doesn't genuinely fit — forcing a fit results in rejected asks

---

## The structural arc

### Opener (1–2 sentences)

Establish context for why the sender is reaching out to this specific prospect. Reference the target resource page specifically.

Patterns that work:
- "I was researching [specific thing the sender was looking for] and came across your [resource page name]."
- "While putting together resources for [partner's customers / audience], I came across your [resource page name] and thought it was one of the better-curated ones for [topic]."
- "I'm reaching out about your [resource page name] — specifically about a resource I think fits the spirit of what you've curated there."

Patterns that don't work (see `outreach_principles.md`):
- Flattery about the prospect or their site
- Claims of being a long-time reader
- Generic "I came across your site" openers

### The value exchange (2–3 sentences)

State what the partner has to offer and why it fits the prospect's curation. Be specific about:
1. What the partner resource is
2. Why it fills a gap or complements existing items on the resource page
3. What makes it substantively good (not generic "great content")

Patterns that work:
- "We published a [specific asset type] that covers [specific angle] — and I noticed your guide's existing [section name] links mostly to [general category], without a [specific local/niche angle] option. This might be the kind of gap-filler that fits the way you've structured the rest."
- "The resource is [URL]. It's a [word count]-word guide covering [specific topics] and is specifically geared toward [target audience] in [geographic area]. It's the most detailed local-focused guide we've seen for this topic."

### The ask (1 sentence)

Low-friction. Yes/no answerable.

Patterns that work:
- "Would it be helpful if I sent over the link for you to look at?"
- "Worth a look to see if it's a fit for the guide?"
- "If you have a minute, would you take a quick look to see if it belongs in the guide?"

Avoid:
- "Would you mind linking to us?" (too direct, no give)
- "I'd love to discuss this further" (vague, high-friction)
- "Let me know what you think" (no clear decision asked)

### Signoff

Standard sender signature — name, title, business, website. Optional phone number.

---

## Example of a full initial email using this template

**Subject**: Possible addition to your Denver home resources guide

> Hi Marla,
>
> I was researching which Denver resource pages list licensed roofing contractors, and your home maintenance resources guide on Denver Home Guide came up as one of the first well-curated ones.
>
> We put together a Denver-specific roof repair cost guide a few months ago, and while reviewing similar resources I noticed your "Further Reading" section links mostly to national cost guides. The one we built covers Colorado-specific factors — hail claim documentation, HOA-related material restrictions, and seasonal considerations — that most national guides skip entirely.
>
> Worth a quick look to see if it fits the kind of resources you curate there?
>
> Thanks,
>
> Sarah Hernandez
> Owner, Mile High Roofing Co.
> milehighroofing.example.com
> (303) 555-0100

### Why this works

- Opener is specific and honest about why the sender is reaching out
- References a specific structural element of the target page ("Further Reading" section) without fabricating
- States a specific gap the resource fills (local-focused content where existing links are national)
- Single low-friction ask at the end
- Signature is complete and verifiable

---

## Follow-up templates

### First follow-up (4 business days later)

Structure: Reference the initial email briefly, add one new element, repeat the ask in a slightly lower-friction form.

Example:
> Hi Marla,
>
> Quick follow-up on my note last week about the Denver roof repair cost guide.
>
> I also noticed your guide mentions hail damage assessments — we have a walkthrough specifically for Denver homeowners documenting post-hail claims that might be useful as a companion link.
>
> Happy to send either or both over if worth a look.
>
> Thanks,
> Sarah

### Second follow-up (10 business days later)

Structure: Graceful exit. No pressure, no complaint, no final-chance framing. Offer a lower-friction alternative if appropriate.

Example:
> Hi Marla,
>
> Totally understand if the roof repair resource isn't a fit for your guide or if the timing's off. I'll leave it here and stay in touch if we publish anything else that might fit the curation.
>
> Wishing you well,
> Sarah

---

## What to adjust based on tone preferences

### Casual tone

- Opener: "Hey Marla" instead of "Hi Marla"
- Contractions used freely
- Signoff: "Cheers" or "Thanks!" with exclamation

### Professional tone (default)

- As shown in the example above

### Formal tone

- Opener: "Dear Marla" or "Dear Ms. [Last Name]" if full name available
- Fewer contractions
- Signoff: "Best regards" or "Kind regards"
- Longer signature with formal title

### Direct warmth

- Skip the opener context sentence; go straight to the reason for reaching out
- Shorter overall

### Warm / Friendly warmth

- One extra sentence of context or connection before the value exchange
- Slightly more conversational phrasing
