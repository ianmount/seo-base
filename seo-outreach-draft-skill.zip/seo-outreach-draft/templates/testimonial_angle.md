# Testimonial Offer Angle Template

Structural guide for outreach where the partner has genuinely used a specific tool, product, or service and is offering a testimonial in exchange for potentially being featured on the provider's site (which typically includes a link back to the partner).

This is one of the most honest link-building angles because the value exchange is real and straightforward — the sender has genuinely used the product and is offering a real testimonial.

---

## When to use this template

Use when:
- The partner has actually, genuinely used the prospect's product, tool, or service for a meaningful period
- The partner has specific results or outcomes from using it
- The prospect publishes customer testimonials, case studies, or customer success stories on their site
- The offered testimonial is authentic, not a bought review

Do NOT use when:
- The partner hasn't actually used the product (fabricated testimonials are a hard refusal for this skill)
- The partner's experience with the product is mixed or negative (offer it only when the experience is genuinely positive)
- The prospect doesn't publish customer features — no fit for the angle

---

## The structural arc

### Opener (1–2 sentences)

Establish that the partner has been a real customer, and how long.

Pattern:
- "I've been using [product name] at [partner business] for [duration]. I wanted to reach out because I noticed you publish customer testimonials on your site, and I'd be glad to contribute one if it'd be useful."

### Describe the specific use case (2–3 sentences)

What the partner uses the product for, and what outcomes they've seen. Be specific — generic "great product" testimonials aren't useful to the prospect either.

Pattern:
- "We use [product] specifically for [specific use case]. Since switching to it [duration ago], we've seen [specific outcome — ideally with numbers]."

### The offer (1–2 sentences)

Explicit about what's being offered and what format would work.

Pattern:
- "Happy to put together a short testimonial, case study contribution, or a quote — whatever format works best for how you feature customers."

### Light ask (1 sentence)

Pattern:
- "Let me know if you're interested and what format would be most useful."

---

## What makes this angle work

The value exchange is symmetric. The partner gets a feature (often with a link back). The prospect gets authentic social proof to use on their site. Neither side is pretending or manipulating.

The angle fails when:
- The partner wasn't really a customer
- The "testimonial" is generic marketing-speak that provides no actual social proof
- The partner's results aren't specific enough to matter

---

## Example opener

> "Hi [name], I've been using RoofSmart Scheduling at Mile High Roofing for the past 18 months. I saw you publish customer case studies on your blog and wanted to reach out — we've had specific, measurable results with the product, and I'd be glad to contribute a testimonial or short case study if it'd be useful for your customer stories page."

---

## One note on authenticity

If the partner's `credibility_points` or `asset_description` doesn't make clear that they're an actual user of the prospect's product, the skill flags this. Fabricated testimonials are one of the clearest "do not produce" cases for this skill.
