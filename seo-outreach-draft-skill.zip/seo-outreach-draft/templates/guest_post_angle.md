# Guest Post Pitch Angle Template

Structural guide for outreach where the goal is to pitch a guest post to the prospect's publication.

This is one of the harder link-building angles to execute well because competition is fierce — editors and publishers receive many pitches per week, most of which are poorly targeted. The pitch has to be visibly specific and credible to stand out.

---

## When to use this template

Use when:
- The prospect's publication accepts guest posts (check for a "Write for Us" or "Contribute" page before using this angle)
- The partner has genuine expertise on a specific topic the publication covers
- The proposed topic fits the publication's audience and editorial standards
- The sender can actually write (or pay someone qualified to write) the post — this isn't a bluff

Do NOT use when:
- The publication has explicitly stated they don't accept guest contributions
- The proposed topic is generic ("Why SEO Matters for Small Business") — generic pitches are rejected on arrival
- The sender has no demonstrable authority on the topic
- The angle is really just "we want a link" with a guest post wrapper

---

## The structural arc

### Opener (1–2 sentences)

Establish why this specific publication, for this specific topic. Editors can smell "blast to all publications in the industry" pitches instantly.

Patterns that work:
- "I'm reaching out about a possible guest post for [publication name]. I noticed your recent coverage of [specific topic area] and have a specific angle that might fit."
- "I've been [action that shows familiarity — 'working in Denver roofing for 22 years,' 'tracking Colorado storm damage claims data for my business']. I wanted to pitch a piece on [topic] that I think would be a good fit for [publication]."

Patterns that don't work:
- "I'd love to write a guest post for your site." (generic, no topic, no angle)
- "I'm a huge fan of your publication." (fake flattery)
- "I noticed you accept guest posts." (acknowledges the pitching purpose too directly; lacks specificity)

### State the topic and angle (3–4 sentences)

This is the heart of the pitch. It needs to:
1. State the specific topic and angle
2. Explain why this angle hasn't been well-covered elsewhere (or why the sender's take is distinctive)
3. Indicate the approximate length and structure

Patterns that work:

> "The piece would be specifically about [specific angle]. Most coverage of [broader topic] treats [common treatment], but what I've seen in 22 years of [specific experience] is [distinctive observation]. I'd structure it as ~1,500 words with [specific structural elements]."

### Establish credibility (2–3 sentences)

This is where the `credibility_points` field carries weight. Name specific, verifiable credentials.

Patterns that work:
- "For context on why I'd be a credible voice: [credential 1], [credential 2], and [credential 3]."
- "I've been quoted in [specific publication] on this topic and served [specific role] for [specific organization]."

Patterns that don't work:
- "I'm a thought leader in the space." (meaningless)
- "I have extensive experience." (vague)
- "I've been doing this for years." (not credible without specifics)

### The ask (1 sentence)

The ask is specifically for interest in the topic, not permission to send a full draft.

Patterns that work:
- "Would this angle be of interest? Happy to send a full outline if so."
- "If this sounds like a potential fit, I can follow up with a more detailed outline."
- "Let me know if you'd like to see the outline or if a different angle would work better."

Avoid:
- "Please let me know if you'd like me to send the full 1,500-word draft." (high-friction — the prospect has to commit before knowing what they're getting)
- "I've attached the full draft." (presumptuous — editors haven't agreed to read it)

### Signoff

Standard signature. For guest post pitches specifically, including a link to the partner's existing written work (blog, LinkedIn articles, bylined pieces elsewhere) significantly strengthens the pitch. If `credibility_points` includes a reference to published writing, link it in the signature.

---

## Example of a full initial email using this template

**Subject**: Guest post pitch: Denver's post-hail roofing claim patterns

> Hi Marla,
>
> I'm reaching out about a possible guest post for Colorado Home Report. I noticed your ongoing coverage of Front Range weather events and have a specific angle I think fits.
>
> The piece would be about the claim-filing patterns Colorado homeowners run into in the 60 days after a hail event — specifically, the gap between what insurers initially offer and what contractors actually document in their inspections. Most coverage treats hail damage as a binary "you have damage or you don't" issue, but what I've seen in 22 years of running roofing inspections is that the initial insurance offers miss real damage ~40% of the time. I'd structure it as ~1,600 words with a data section (we have claim outcomes from 300+ Denver-area inspections post-2023 hailstorm) and three practical steps for homeowners.
>
> For context on credibility: I've been running Mile High Roofing for 22 years, I've served on the Colorado Roofing Association's claims education committee since 2018, and I was a source for 9News Denver's 2023 hailstorm coverage.
>
> Would this angle be of interest? Happy to send a full outline if so.
>
> Thanks,
>
> Sarah Hernandez
> Owner, Mile High Roofing Co.
> milehighroofing.example.com
> (303) 555-0100

### Why this works

- Opener references specific prospect coverage area without fake flattery
- Topic is specific and distinctive, with a clear why-this-angle argument
- Credibility points are specific and verifiable (committee role, named news coverage)
- The claim about claim patterns is backed by specific data the sender has
- Ask is low-friction (interest, not commitment to review a full draft)
- Length is around 200 words — longer than most outreach but appropriate for a pitch that requires establishing credibility

---

## Follow-up templates

### First follow-up (4 business days later)

Structure: Brief. Can add one piece of new information.

Example:
> Hi Marla,
>
> Following up on my guest post pitch from last week about Colorado post-hail claims.
>
> I realized I didn't mention — I can share the raw claim outcome data as a companion to the piece if you'd want to publish with some interactive elements. Totally fine either way.
>
> Let me know if the angle's interesting.
>
> Thanks,
> Sarah

### Second follow-up (10 business days later)

Structure: Graceful exit. Offer to stay in touch for future editorial calendar needs.

Example:
> Hi Marla,
>
> Understand if the hail claims piece isn't a fit for your editorial calendar. I'll leave it here, and feel free to reach out if the topic becomes relevant later in the year — happy to contribute when the timing works.
>
> Best,
> Sarah

---

## What not to include in the pitch

- **A full draft of the proposed piece.** Editors want to see the angle and your voice, not a finished product they didn't agree to review.
- **A rate card or payment demand.** Most guest posts on link-building targets don't involve payment; if the sender wants paid contribution, that's a different conversation channel entirely.
- **Mentions of SEO, backlinks, or link-building goals.** This is presumed but shouldn't be stated — editors discount pitches that admit their primary goal is SEO benefit.
- **Requests for specific anchor text or link placement.** Those conversations happen (or don't) after acceptance.

---

## Subject line options

- "Guest post pitch: [specific topic]"
- "Pitch: [specific angle] for [publication name]"
- "Idea for [publication section name]: [specific topic]"

Avoid:
- "Guest post opportunity for you"
- "Contribution inquiry"
- "Looking to contribute"

The specific-topic subject lines perform meaningfully better than generic ones.
