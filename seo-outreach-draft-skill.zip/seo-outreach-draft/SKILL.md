---
name: seo-outreach-draft
description: Use this skill whenever a partner needs link-building outreach emails drafted for a specific prospect. Takes a prospect profile, an outreach angle, and the partner's value proposition, and produces a 3-email sequence (initial email + two follow-ups) tailored to the prospect. Designed to produce outreach that a human would actually send — conversational, specific, genuinely useful to the recipient, and not detectable as AI-generated template spam. Do NOT use this skill for: cold sales outreach (this is for editorial/link-building contacts only), partner-to-client communication (this is outbound to third parties), or mass automated outreach (the skill produces one sequence at a time, by design). The skill refuses to produce outreach that makes false claims about the sender's familiarity with the prospect's work.
---

# SEO Outreach Draft

This skill generates a 3-email outreach sequence (initial email + two follow-ups) for link-building outreach from a partner to a prospect. It's tone-heavy and judgment-based — the output quality depends on whether the email sounds like something a thoughtful human would send, not whether it fills a structured template correctly.

The skill is opinionated about what good outreach looks like. It will refuse to produce certain common patterns (fake flattery, generic "I loved your article on [topic]" openers, manipulative urgency, false claims of having read the prospect's work) even if asked directly.

## When to use this skill

Activate when the engineer (or tool) needs outreach emails drafted for a specific prospect opportunity identified during the backlinks workflow. Specifically:

- When a prospect has been researched and approved for outreach
- When a specific angle has been chosen (resource page, broken link, guest post, local partnership, expert source)
- When there's a concrete asset or offer to extend to the prospect (not just "please link to us")

Do not use for:
- Mass unsolicited outreach (the skill produces one sequence per invocation, by design — don't use it as a template generator for hundreds of prospects)
- Sales outreach to prospective customers (this skill is for editorial/link-building contacts only)
- Client-facing communication for the partner's own customers (different tone, different purpose)
- Responding to incoming inquiries (this skill generates outbound cold outreach, not replies)
- Outreach where the sender has no real value to offer (if the email doesn't have a genuine value exchange, the skill will flag this and refuse to produce a manipulative-feeling alternative)

## Required inputs

The caller must provide, in structured form:

1. **Partner profile** (object — the SENDER side)
   - `business_name` (string)
   - `business_type` (string)
   - `services` (array of service names)
   - `service_areas` (array of cities/regions)
   - `primary_location` (object: `locality`, `region`)
   - `website_url` (string)
   - `sender_name` (string — the actual human whose name goes on the email, typically partner owner or a named staff member)
   - `sender_title` (string — e.g. "Owner", "Marketing Manager")
   - `sender_email` (string — the from address)
   - `credibility_points` (array of strings — concrete, verifiable things about the partner that make them worth linking to. Examples: "In business for 22 years", "Certified by the Colorado Roofing Association", "Featured in 9News Denver coverage of the 2023 hailstorm response". Never fabricate these — only include what the caller provides.)

2. **Prospect details** (object)
   - `prospect_domain` (string)
   - `prospect_name` (string — if known; use null if unknown, and the skill will use a generic salutation)
   - `prospect_title` (string — if known)
   - `prospect_email` (string)
   - `prospect_organization` (string — the organization or publication the prospect is part of)
   - `target_page_url` (string — the specific page on the prospect's site relevant to the outreach, e.g. the resource page being targeted, the page with the broken link, the guest post guidelines page)
   - `target_page_context` (string — 2–4 sentences describing what the target page is about, ideally in the caller's own words rather than scraped copy, since scraped copy can mislead the skill)
   - `existing_relationship` (enum: `none` | `past_interaction` | `mutual_connection` | `warm_intro_pending`)
   - `relationship_context` (string, optional — details if `existing_relationship` is not `none`)

3. **Outreach angle** (object)
   - `angle_type` (enum: `resource_page_add` | `broken_link_replacement` | `guest_post_pitch` | `local_partnership` | `expert_source_offer` | `testimonial_offer` | `unique_data_share`)
   - `angle_specifics` (string — what's being offered, specifically. For resource page: the partner page being suggested for inclusion. For broken link: the broken URL + the replacement URL. For guest post: the proposed topic. For local partnership: the nature of the partnership. Etc.)
   - `asset_url` (string — the partner URL being promoted, if applicable)
   - `asset_description` (string — brief description of the asset, in the caller's own words)

4. **Tone preferences** (optional object)
   - `formality` (enum: `casual` | `professional` | `formal` — default `professional`)
   - `warmth` (enum: `direct` | `warm` | `friendly` — default `direct`)
   - `length_preference` (enum: `brief` | `standard` | `detailed` — default `brief`; the skill defaults to shorter because shorter outreach has materially higher response rates)

## Output format

Return a single JSON object with this structure:

```json
{
  "sequence_summary": {
    "prospect_name_used": "string (actual name or generic fallback)",
    "angle_type": "string",
    "total_emails": 3,
    "expected_send_cadence": "initial + followup_day_4 + followup_day_10"
  },
  "emails": [
    {
      "sequence_position": 1,
      "send_timing": "initial",
      "subject_line": "string (under 55 characters, specific, no clickbait)",
      "body": "string (plain text, paragraphs separated by blank lines)",
      "cta": "string (the specific ask — 1 sentence, low-friction)",
      "signature": "string (sender name, title, business name, website)",
      "word_count": "integer",
      "personalization_elements_used": ["array of strings — specific prospect details referenced in this email"]
    },
    {
      "sequence_position": 2,
      "send_timing": "4 business days after initial",
      "subject_line": "string (usually 'RE: [initial subject]' or a short variation)",
      "body": "string (meaningfully shorter than initial, ~40-60 words)",
      "cta": "string",
      "signature": "string (abbreviated signature — just name and business)",
      "word_count": "integer",
      "personalization_elements_used": ["array of strings"]
    },
    {
      "sequence_position": 3,
      "send_timing": "10 business days after initial",
      "subject_line": "string (different from initial — fresh subject signals this isn't just chasing)",
      "body": "string (shortest of the three, ~30-50 words, graceful exit)",
      "cta": "string (often a very low-friction alternative ask or a graceful 'no worries if not')",
      "signature": "string (abbreviated signature)",
      "word_count": "integer",
      "personalization_elements_used": ["array of strings"]
    }
  ],
  "skill_notes": {
    "angle_type": "string",
    "formality_used": "string",
    "warmth_used": "string",
    "length_preference_used": "string",
    "template_base_used": "string (which template from templates/ directory was used as the starting structure)",
    "credibility_points_incorporated": ["array of strings — which partner credibility points made it into the copy"],
    "authenticity_checks": {
      "no_fake_familiarity": "pass|fail (did the email avoid claiming to have read/loved the prospect's work when the caller didn't confirm the sender actually did?)",
      "no_manipulative_urgency": "pass|fail",
      "no_template_fill_phrasing": "pass|fail",
      "genuine_value_exchange": "pass|fail"
    },
    "flags_for_engineer_review": ["array of strings"]
  }
}
```

## Execution procedure

Follow these steps in order.

1. **Load the outreach principles** at `rules/outreach_principles.md`. This file is the core of the skill — if you're ever uncertain about whether a specific phrase or approach is appropriate, the principles file has the guidance.

2. **Load the personalization rules** at `rules/personalization_rules.md` for specific guidance on how to reference the prospect without sounding creepy, over-familiar, or obviously AI-generated.

3. **Load the appropriate template** from `templates/` based on the `angle_type`:
   - `resource_page_add` → `templates/resource_page_angle.md`
   - `broken_link_replacement` → `templates/broken_link_angle.md`
   - `guest_post_pitch` → `templates/guest_post_angle.md`
   - `local_partnership` → `templates/local_partnership_angle.md`
   - `expert_source_offer` → `templates/expert_source_angle.md`
   - `testimonial_offer` → `templates/testimonial_angle.md`
   - `unique_data_share` → `templates/data_share_angle.md`

   Templates are structural starting points, not copy-paste patterns. They describe the natural arc of each angle type but leave specific language open to match tone preferences and prospect context.

4. **Draft the initial email** following the template structure, with these priorities (in order):
   - Start with something genuinely specific to the prospect's work, drawn only from what the caller provided in `target_page_context`. Never fabricate details about what the prospect wrote or said.
   - State the value exchange clearly in the second paragraph — what the sender is offering, concisely.
   - Make the ask once, near the end, low-friction. A yes/no question the prospect can answer in one sentence.
   - Sign off with the sender's actual credentials. The signature should include enough detail that the prospect can verify the sender is legitimate.
   - Target word count: 90–130 words for initial email (brief preference), 130–180 (standard), 180–250 (detailed). Do not exceed these caps.

5. **Draft the first follow-up** (send timing: 4 business days after initial):
   - Reference the initial email briefly but don't restate it in full
   - Add one genuinely new element — a different angle on the value exchange, a specific detail about the prospect's context that wasn't in the initial email, or an acknowledgment that timing may not be right
   - Target word count: 40–60 words. Meaningfully shorter than the initial.
   - Never accuse the prospect of ignoring the email or imply they've been rude

6. **Draft the second follow-up** (send timing: 10 business days after initial):
   - This is the graceful exit. Assume this email will not get a response.
   - Acknowledge that the ask might not be a fit and offer a graceful out
   - Optional: offer a lower-friction alternative (e.g. "If the full suggestion isn't a fit, I'd be glad to stay in touch for future pieces")
   - Target word count: 30–50 words. Shortest of the three.
   - Never guilt, never escalate, never threaten removal from a list the prospect didn't opt into

7. **Run the authenticity checks** and populate the `authenticity_checks` field in `skill_notes`:
   - `no_fake_familiarity`: Did the email avoid claims like "I've been following your work for years" or "Your recent article on X was fantastic" unless the caller explicitly confirmed in the inputs that the sender has done so?
   - `no_manipulative_urgency`: Did the email avoid fake deadlines, scarcity framing, or pressure tactics?
   - `no_template_fill_phrasing`: Did the email avoid obvious AI-generated template patterns (see the list in `rules/outreach_principles.md`)?
   - `genuine_value_exchange`: Does the email offer the prospect something genuinely useful, not just ask for a link?

   If any check fails, rewrite the affected section and re-check. If a check cannot be made to pass (e.g. there's no genuine value to offer), flag it in `flags_for_engineer_review` and surface the issue to the engineer rather than producing manipulative copy.

8. **Populate the output JSON** with all three emails, personalization elements used, and skill notes.

## Authenticity principles (summary — full version in `rules/outreach_principles.md`)

The skill adheres to these principles and will refuse to produce outreach that violates them:

**Never fake familiarity with the prospect's work.** Unless the caller explicitly provides evidence that the sender has read or engaged with specific prospect content, the skill does not produce openers like "I loved your article on X" or "I've been reading your blog for years." Fake familiarity is the single most common AI-outreach tell and destroys credibility instantly.

**Every email needs a genuine value exchange.** The skill is not designed to produce "please link to me for no reason" outreach. If the inputs don't describe what the sender is offering the prospect, the skill will flag this and refuse to produce manipulative alternatives.

**Be specific about what's on offer.** Vague offers ("I'd love to collaborate", "We'd be a great fit") signal template spam. Specific offers ("We have a state-by-state cost breakdown for roof repair that fills the gap in the 'Further Reading' section of your guide") signal genuine outreach.

**Make the ask once, low-friction.** Good outreach has exactly one ask, placed near the end, phrased so the prospect can respond in under 60 seconds. Multiple asks and high-effort CTAs ("Would you be willing to schedule a 30-minute call to discuss...") significantly reduce response rates.

**Follow-ups shorten, not lengthen.** The first follow-up is shorter than the initial. The second is shorter still. Each email should be easy to skim and respond to in under 30 seconds.

**Never use pressure or guilt.** Manipulative patterns like "I'll take your silence as disinterest," "final follow-up," or "circling back to make sure this doesn't fall through the cracks" are banned. The second follow-up exits gracefully and does not threaten.

**The sender is always a real human with a real name.** Generic sign-offs like "The Team at [Partner]" signal automated outreach. The skill always uses the partner's designated sender name, title, and contact details.

## Constraints and guardrails

- **Never fabricate credibility points.** Use only what's in the partner profile's `credibility_points` field. Do not invent certifications, awards, featured-in mentions, or years in business that weren't provided.
- **Never fabricate prospect-specific details.** Use only what's in `target_page_context` and `relationship_context`. If those fields are thin, the email will be more general — that's acceptable. Generic-but-honest beats specific-but-fabricated.
- **Never produce outreach with no genuine value exchange.** If the caller provides no real offer (or the offer is weak), the skill flags this and declines to produce manipulative copy that disguises the lack of value.
- **Refuse to produce manipulative or deceptive outreach.** This includes: fake urgency, false claims of prior contact, manufactured flattery, pressure tactics, or framing that implies the prospect has already agreed to something.
- **Follow the length caps.** Initial: 90–250 words depending on preference. First follow-up: 40–60 words. Second follow-up: 30–50 words. These caps exist because longer outreach has lower response rates — the skill will not exceed them even if asked.
- **Write subject lines like a human would.** No clickbait, no all-caps, no spammy punctuation, no "{prospect_first_name}, you'll want to see this." Subject lines should be short, specific, and match the body content.

## Reference files

The skill includes these reference files, loaded on demand when their content is needed:

- `rules/outreach_principles.md` — full authenticity principles and anti-patterns
- `rules/personalization_rules.md` — how to reference prospect details without overreach
- `templates/resource_page_angle.md` — template structure for resource page inclusion outreach
- `templates/broken_link_angle.md` — template structure for broken link replacement outreach
- `templates/guest_post_angle.md` — template structure for guest post pitch outreach
- `templates/local_partnership_angle.md` — template structure for local partnership outreach
- `templates/expert_source_angle.md` — template structure for offering the sender as an expert source
- `templates/testimonial_angle.md` — template structure for offering a testimonial for a product/tool
- `templates/data_share_angle.md` — template structure for sharing unique data with journalists/bloggers
- `examples/resource_page_example.json` — worked example of resource page outreach
- `examples/broken_link_example.json` — worked example of broken link replacement outreach
