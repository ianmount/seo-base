# Personalization Rules

How to reference prospect-specific details in outreach without sounding creepy, over-familiar, or obviously AI-generated.

---

## The core tension

Personalized outreach responds materially better than generic outreach. But attempted personalization that gets the details wrong — or that references details in a way that feels surveillance-adjacent — is worse than no personalization.

The skill navigates this tension by being aggressive about referencing what the caller explicitly provided and conservative about inferring or guessing.

---

## Three categories of prospect detail

### Category 1: Provided by the caller — use freely

These are details the caller included in the input structure. The skill can reference them directly:

- `prospect_name`, `prospect_title`, `prospect_organization`
- `target_page_url`, `target_page_context`
- `existing_relationship`, `relationship_context`
- Anything in `angle_specifics` that's specific to the prospect

Example uses:
- "Marla, I was reading your Denver home maintenance resources guide..." (uses prospect name and target page context)
- "I noticed the 'Further Reading' section of your guide currently points to generic national sources..." (uses specific structural detail from target_page_context)
- "Since we met at the Denver Home Show in March..." (uses relationship_context)

### Category 2: Inferable from the target page context — use carefully

These are details the caller didn't explicitly state but can be reasonably inferred from what they did provide. The skill can reference them only when the inference is conservative and the phrasing makes room for being wrong.

Example:
- If `target_page_context` says "The page is a curated list of licensed home service providers in Denver," the skill can safely say "Since your guide focuses on licensed providers..."
- If `target_page_context` says "The page is about emergency preparedness for Colorado homeowners," the skill can say "Given the emergency focus of your guide..."

What NOT to infer:
- The prospect's tone preferences, writing style, or personality beyond what's demonstrably in the provided text
- The prospect's audience, readership numbers, or authority
- The prospect's personal experiences or views
- The prospect's relationships with competitors or other senders

### Category 3: Not provided and not inferable — don't reference

These are details the skill might be tempted to fabricate to make outreach feel more personalized. The skill does not reference them, even when it would make the outreach stronger.

Examples:
- The prospect's years of experience ("As someone who's been covering this space for years..." — don't say this unless explicitly confirmed)
- Specific things the prospect has written ("Your recent piece on X..." — don't say this unless the caller confirmed in `relationship_context` that the sender actually read specific content)
- The prospect's credentials or background ("As a former [industry]..." — don't invent)
- The prospect's relationship to other people ("Your colleague [name] mentioned..." — never, unless explicitly provided)
- Mutual connections that weren't specified

---

## Specific patterns for different input states

### When prospect_name is known

Use the name in the salutation and occasionally in the body (once, in the first or second paragraph, not in every paragraph — repeated name use reads as sales-trainer-technique).

Good: "Hi Marla, I was researching..."
Also good: "This is because of how your site handles..." (paragraph 2, no name)

Bad: Using the name in every paragraph ("Marla, I was researching... Marla, what I wanted to ask you about...")

### When prospect_name is unknown (null)

Use "Hi" or "Hi there" — not "Hi [First Name]" with brackets, not "Dear Sir/Madam" (which sounds like 19th-century correspondence), not "To whom it may concern" (which reads as bulk mail).

If the `prospect_organization` is known, mention it specifically rather than using a generic greeting: "Hi — I'm reaching out about the resource guide on DenverHomeGuide.com..."

### When prospect_title is known but name is unknown

If `prospect_title` is "Editor" or "Marketing Director" or similar, the skill can use that context in the opener ("Hi — I'm reaching out to the editorial team at [publication]") without using the title as a salutation.

Never use "Dear Editor" or "Dear Marketing Director" — it reads as form letter.

### When existing_relationship is past_interaction

Reference the specific prior interaction from `relationship_context` in the first paragraph. This is the single strongest legitimate personalization signal available.

Good: "Hi Marla — we met briefly at the Denver Home Show in March when I stopped by your booth. Following up with something I thought might be useful for your guide..."

The reference should be brief and specific. Don't dwell on the relationship (which can read as trying too hard to establish it); establish it and move on to the value exchange.

### When existing_relationship is mutual_connection

Reference the mutual connection by name only if the `relationship_context` confirms the sender has permission to name-drop. Otherwise, keep it generic.

Good (with permission): "Hi — Alex Chen at Rocky Mountain Contractor Coalition suggested I reach out to you..."
Good (without explicit permission confirmation): "Hi — a mutual connection in the Denver contractor community suggested your guide might be a good fit for a resource I've put together..."

### When existing_relationship is warm_intro_pending

The skill treats this as cold outreach but flags in `skill_notes.flags_for_engineer_review` that the caller should wait for the warm intro to happen before sending. Do not reference the pending intro in the email itself — that's presumptuous.

### When there's no specific personalization available

The skill falls back to more general framing but stays honest. Don't invent personalization. A brief, honest, well-written general email is much more effective than a forced-personal email that feels manufactured.

General framing that still works:
- "I was researching resource pages that list licensed contractors in the Denver metro area and came across [prospect_organization]..."
- "While working on a link-building initiative for our roofing business, your guide came up as one of the better-curated resources in the space..."

Note: The second example is slightly risky because it admits "link-building initiative" — but in the right context (e.g. pitching to a resource curator who's used to these requests), honesty about intent is fine and often better than pretending.

---

## References to the prospect's content

### What the skill CAN reference

- The existence and general topic of the target page (from `target_page_context`)
- The page's URL
- Structural elements of the page that the caller described (e.g. "the 'Further Reading' section," "the list of local service providers")
- Anything explicitly noted in `relationship_context` about prior engagement

### What the skill CANNOT reference

- Specific arguments, claims, or conclusions the prospect made (unless explicitly provided by the caller)
- The prospect's writing style or voice
- The prospect's emotional tone or "take" on an issue
- Specific examples or case studies the prospect used
- Dates, statistics, or facts from the prospect's content

Even if Claude has actually fetched and can see the prospect's page content during generation, the skill does not reference content beyond what the caller described. The reason: the caller is the one who's accountable for the outreach, and the caller should explicitly signal what's appropriate to reference. If the caller wanted specific content referenced, they would have included it in `target_page_context`.

### A specific anti-pattern: scraped quotes

The skill will not quote or paraphrase specific passages from the prospect's content, even if asked. Quoting back the prospect's own words in outreach — even correctly — reads as surveillance-adjacent and often produces worse response rates than more general framing.

If a specific point needs to be made, make it in the sender's own words and reference the prospect's content generally:

Bad: "As you wrote in your piece, 'Denver's hail season produces more roof claims than any other Colorado city' — that's exactly why I thought..."
Better: "Your guide emphasizes the scale of Denver's hail-related roof claims — that's the context for why I thought this resource might fit."

---

## References to the prospect's organization

### Name dropping the prospect's publication or company

Use the exact name as the caller provided it. Don't abbreviate, nickname, or casualize. If `prospect_organization` is "Denver Home Guide," don't call it "DHG" or "Denver Home" — use the full name.

### Referring to the prospect's audience

Don't claim knowledge of the audience the skill doesn't have. Phrases like "your audience would love this" or "your readers are exactly the target for this" imply the sender knows the prospect's audience well enough to speak for them — usually they don't.

Better framing: "If this is a fit for the kind of resources you cover, I'd love to share the link."

This puts the decision with the prospect (who actually knows their audience) rather than the sender claiming to.

---

## Balancing specificity and length

Personalization is valuable but has diminishing returns relative to email length. A 200-word email with three personalization touches will usually outperform a 400-word email with six personalization touches — recipients aren't reading the extra details, they're scanning for the ask.

Rule of thumb:
- 90–130 word initial email: 1–2 personalization touches
- 130–180 word initial email: 2–3 personalization touches
- 180–250 word initial email: 3–4 personalization touches maximum

More than 4 personalization references in a single email reads as trying too hard, regardless of email length.
