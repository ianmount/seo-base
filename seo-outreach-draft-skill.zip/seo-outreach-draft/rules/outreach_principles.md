# Outreach Principles

The authoritative reference on what good outreach looks like, what bad outreach looks like, and why the skill refuses to produce certain patterns.

This file is the most important reference in the skill. If the main SKILL.md is ambiguous about tone or phrasing, this file is the source of truth.

---

## The central principle

**Every email should read like something a specific, thoughtful human wrote to a specific, thoughtful human.**

That sentence is doing real work. Unpacking it:

- "A specific human" — the sender has a name, title, and business. The sender's credibility is on the line. Anonymous or team-signed outreach signals automation.
- "Thoughtful" — the sender has thought about why this prospect, specifically, should care. Mass templated outreach thinks about none of that.
- "To a specific, thoughtful human" — the recipient is not a KPI, a link target, or a conversion. They're a person who has their own work, priorities, and judgment. Good outreach treats them that way.
- "Wrote" — not generated, not templated, not assembled from variables. Even when a skill is generating the email, the final output should read as if a human wrote it from scratch.

Every other rule in this file derives from that one principle.

---

## The anti-patterns — what the skill will not produce

These patterns are banned. The skill will refuse to produce outreach that uses them, even if directly asked.

### Fake familiarity

**Banned phrases**:
- "I've been following your work for years"
- "I loved your article on [topic]"
- "Your recent piece on X was excellent"
- "As a longtime reader of your blog"
- "I've been a fan since..."
- "Your work on [topic] really resonated with me"

**Why banned**: These phrases are the single most common AI-outreach tell. Recipients can usually sense them immediately because they lack specific evidence of actual engagement. A sender who has genuinely followed someone's work will reference a specific detail ("your argument in the March piece about zone-2 restrictions stuck with me because...") that can only come from real reading.

**Exception**: If the caller explicitly provides evidence that the sender has engaged with specific prospect content (e.g. `relationship_context: "The sender attended Marla's talk at the Denver Home Show in March and exchanged business cards"`), the skill can reference that — but only that specific interaction, not generalized "following your work."

### Manufactured flattery

**Banned phrases**:
- "I love what you're doing"
- "Your site is incredible"
- "You're a thought leader in this space"
- "I'm a huge admirer of [company/publication]"
- "What you've built is truly impressive"

**Why banned**: Vague praise without specific referents is transparently formulaic. Recipients of link-building outreach see these phrases dozens of times a week. They don't build goodwill — they trigger skepticism.

**What to do instead**: Skip the flattery entirely. Start with the reason for reaching out. "I came across your resource page on [topic] while researching [sender's specific question]" is a better opener than any flattery-based alternative.

### Manipulative urgency and scarcity

**Banned patterns**:
- "I need this by end of week"
- "Only reaching out to a few select [publications/sites]"
- "This offer is time-sensitive"
- "If I don't hear back by [date], I'll assume you're not interested"
- "Limited availability for guest posts this month"

**Why banned**: The sender does not, in fact, have genuine urgency in link-building outreach. Fake urgency is manipulation. Even when genuine timing constraints exist (e.g. the sender is only in town for a week), they should be stated neutrally, not used as pressure.

### Pressure-based follow-ups

**Banned phrases in follow-ups**:
- "I'll take your silence as disinterest"
- "Just bumping this to the top of your inbox"
- "Wanted to make sure this didn't fall through the cracks"
- "Last chance before I close the loop on this"
- "Following up one final time"
- "Since I haven't heard back..."

**Why banned**: These phrases assume the prospect has an obligation to respond. They don't. The sender is asking for something; the prospect has no duty to engage. Pressure-framing follow-ups damage the sender's reputation for future outreach to the same prospect or their network.

**What to do instead**: Follow-ups should add something new (a different angle, a specific new offer) rather than complain about not getting a reply.

### Fake peer-to-peer framing

**Banned phrases**:
- "I thought we might be a great fit"
- "I see a real opportunity for us to collaborate"
- "We'd be thrilled to partner with [prospect's org]"
- "I think our audiences would really align"

**Why banned**: These phrases treat cold outreach as if there's already a relationship. There isn't. The prospect has no idea who the sender is. Peer-to-peer framing before a relationship exists is presumptuous.

**What to do instead**: Be clear that this is cold outreach. Introduce who you are briefly and get to the point.

### Template-fill signals

**Banned patterns** (obvious template variables that remained filled in):
- "Hi [First Name]" or "Dear [Name]" (use the actual name, or a generic "Hi" if name unknown)
- "I came across your [website]" (use the actual website name)
- "your work on [topic]" (use the actual topic)
- "as someone in the [industry] space"

**Why banned**: These are giveaway signals that the email was mass-templated. Even if the variables are filled correctly in the actual send, the skill should produce copy where the fill-in nature is invisible.

**What to do instead**: Write the specific details inline. If the prospect name isn't known, use "Hi" or "Hi there" without brackets. If the topic isn't known specifically, the email should be more general but honest about it.

### Multi-ask emails

**Banned**: Any initial email that contains more than one ask. Examples of multi-ask emails the skill will reduce to single-ask:
- Asking for a link AND asking for a share AND asking for a follow
- Asking for a guest post slot AND asking for an interview AND asking for a newsletter mention
- Asking for a resource page inclusion AND asking for a partnership conversation

**Why banned**: Multi-ask emails have response rates materially lower than single-ask emails. Prospects scan and look for the simplest path forward; multiple asks invite a "no" on all of them.

**What to do instead**: Pick the highest-value single ask. Everything else goes in the skill's `flags_for_engineer_review` as potential future outreach, not in this sequence.

### High-friction CTAs

**Banned patterns**:
- "Would you be open to scheduling a 30-minute call to discuss?"
- "I'd love to jump on a quick call to share more details"
- "Can we set up a time to explore this further?"

**Why banned**: These CTAs ask the prospect to invest 30+ minutes before they've agreed to anything. Response rates drop steeply as CTA friction increases.

**What to do instead**: Ask a single yes/no question that can be answered in one sentence. "Would it be helpful if I sent over the resource link?" is a much better CTA than "Would you be open to a call?"

---

## What good outreach looks like

The skill produces outreach with these characteristics:

### Opens with a specific reason for reaching out

Not "I came across your site" (vague). Not "I loved your article" (fake familiarity).

Better: "I was researching which Denver resource sites list licensed roofing contractors and your guide on home maintenance resources was one of the first that came up." This opener is specific, honest, and gives the prospect context for why they're hearing from this particular sender.

### States the value exchange clearly and concisely

The second paragraph (usually) should answer the prospect's implicit question: "What's in this for me, and why should I care?"

Bad: "I'd love to discuss how we might collaborate."
Better: "We published a detailed state-by-state cost breakdown for roof repair in January, and it covers the Colorado-specific factors (hail, HOA rules) that your guide's 'Further Reading' section doesn't currently address. Happy to share if it'd be useful."

The better version says exactly what's being offered, exactly where it would fit, and leaves the decision clearly with the prospect.

### Makes the ask once, low-friction

One ask. Near the end. Phrased so the prospect can say yes or no in a single sentence.

Good CTAs:
- "Would it be helpful if I sent over the link?"
- "Interested in seeing a draft of the guest post topic?"
- "Happy to share the data — want me to send it over?"

### Uses the sender's real name, title, and contact details

Signature should include:
- Sender's real name
- Sender's title at the partner business
- Partner business name
- Website URL
- (Optional) Direct phone number, which signals the sender is genuinely reachable

No pseudonyms. No "The Marketing Team." No signatures with only a first name and no business affiliation.

### Matches the formality of the prospect's own publication

If the prospect writes for a formal industry publication, the outreach should be slightly more formal. If the prospect runs a casual personal blog, the outreach should be slightly more casual. The skill uses the `tone_preferences` input for this but should also consider what the target page looks like (based on `target_page_context`) and adjust naturally.

### Follows up only when adding something new

A follow-up that just says "wanted to bump this" is a waste of the prospect's attention. A follow-up that says "I also noticed your guide mentions tankless water heaters — we have specific Denver installation cost data if that's useful" adds new value and is a legitimate reason to write again.

### Exits gracefully on the second follow-up

The second follow-up assumes no response will come. It offers a graceful out, wishes the prospect well, and does not threaten escalation or removal from a list.

Good second follow-up pattern:
> Totally understand if this isn't the right fit or the timing is off. I'll leave it here and stay in touch for future pieces you work on. Wishing you well — [name]

---

## Tone calibration

The `tone_preferences` input shapes tone within these ranges:

### Formality axis

- `casual`: Contractions used freely. Can open with "Hey" instead of "Hi." Can end with "Cheers" or "Take care" instead of "Best regards." Appropriate for bloggers, independent creators, small business contacts.
- `professional` (default): Light contractions. Standard "Hi [name]" opener. "Best" or "Thanks" signoff. Works for most B2B contacts, editorial staff, and business owners.
- `formal`: Few contractions. "Dear [Title Name]" opener. "Sincerely" or "Best regards" signoff. Appropriate for academic publications, government-facing contacts, traditional corporate communications.

### Warmth axis

- `direct`: Gets to the point in the first sentence. Minimal small talk. Appropriate when the prospect is busy and values efficiency.
- `warm` (default): One sentence of genuine context before the ask. Appropriate for most outreach.
- `friendly`: Two or three sentences of genuine context before the ask. Appropriate when existing relationship is `past_interaction` or `mutual_connection`, or when the prospect's own content signals a warm communication style.

Warmth should never tip into false friendliness — over-warmth to strangers reads as manipulative.

---

## A word on AI-detection tools

Some prospects use AI-detection tools to flag and discard obviously AI-generated outreach. The skill's goal isn't to evade detection tools — it's to produce outreach genuinely indistinguishable from what a thoughtful human would write. Those two goals usually align: copy that reads as genuinely human also passes detection tools because it lacks the patterns those tools look for.

The skill avoids:
- Uniformly "polished" sentence structures (real human outreach has some variation, some sentence fragments, occasional em dashes)
- Over-use of tricolons and parallel structures (a common AI tell)
- Opener-plus-flattery-plus-transition templates
- Corporate-speak vocabulary where plain words work better ("leverage," "synergy," "collaborate" can all be replaced with simpler verbs)

What the skill does:
- Varies sentence length naturally
- Uses contractions at natural rates (tone-dependent)
- Picks specific verbs over generic ones
- Occasionally uses informal constructions (starting a sentence with "And" or "But," using em dashes for rhythm)
- Makes the sender's voice feel like a specific person rather than a generic corporate voice

---

## When to flag for engineer review rather than producing

The skill should flag (not produce) outreach in these cases:

- The `credibility_points` field is empty or weak (no real reason the prospect should trust the sender)
- The `asset_description` doesn't describe something the prospect would genuinely value
- The `target_page_context` is so generic that any personalization would be fabricated
- The `angle_type` doesn't match the prospect's site structure (e.g. `resource_page_add` when the target page isn't actually a resource page)
- The caller has asked for a specific manipulative element that the skill won't produce (fake deadline, pressure tactic, etc.)

In flagged cases, `flags_for_engineer_review` should be specific: "No credibility points provided — the initial email would have no basis for the sender's authority claims. Recommend caller provide at least 2–3 specific, verifiable credentials before regenerating."

The skill never silently produces weak outreach. Either the output is strong enough to send, or the issue is surfaced to the engineer.
