---
name: seo-strategy-light
description: Use this skill whenever a partner's approved keyword list needs to be converted into an actionable 6-month cycle strategy. Takes the output of seo-keyword-research plus partner site crawl data and produces a page roadmap — which new pages to create, which existing pages to optimize, which to consolidate or redirect, plus a light internal linking plan and an FAQ bank per cluster. Critically includes a "don't break what's working" check: for every approved keyword, the skill verifies whether an existing partner page already ranks in the top 20, and surfaces consolidation/redirect decisions before a new page is proposed that would split ranking signal. Designed for the MVP migration workflow — produces a page list, not a full campaign strategy document. Do NOT use this skill to generate content briefs, body copy, or technical SEO wrappers — those belong to downstream skills (seo-technical-package and, eventually, seo-body-content).
---

# SEO Strategy (Light)

This skill converts an approved keyword list into an actionable 6-month page roadmap for a partner cycle. It's the second step in the cycle planning workflow, running immediately after `seo-keyword-research`.

The skill is judgment-heavy by design — it makes decisions about whether to create new pages, optimize existing pages, or consolidate/redirect thin content. The output is a structured page plan that downstream skills (technical package, body content, publishing) consume directly.

## When to use this skill

Activate when the engineer (or tool) has an approved keyword list from `seo-keyword-research` and needs to convert it into a page roadmap for the cycle.

Do not use for:
- Generating the keyword list itself → use `seo-keyword-research`
- Generating title tags, meta, schema, or other technical SEO wrappers → use `seo-technical-package`
- Generating body copy → use `seo-body-content` (when that exists)
- Generating backlink outreach → different skill, different workflow
- Generating the full cycle strategy document with executive narrative → this skill produces a page list, not a narrative doc

## Required inputs

The caller must provide, in structured form:

1. **Partner profile** (object)
   - Same structure as the `seo-keyword-research` skill: `business_name`, `business_type`, `services`, `service_areas`, `primary_location`, `partner_type`, `priority_services`, `priority_locations`
   - Should match the partner profile that produced the keyword list

2. **Approved keyword list** (object — the output of `seo-keyword-research`)
   - Pass through the full output from the keyword research skill, including clusters, opportunity scores, intent, geographic relevance, current ranking positions, and striking distance flags
   - The skill reads the cluster structure and preserves it where appropriate, but will consolidate or split clusters based on page roadmap needs

3. **Site crawl data** (array of objects)
   - Each object represents an existing partner page. Fields:
     - `url` (string — full URL)
     - `title` (string — current title tag)
     - `h1` (string — current H1)
     - `word_count` (number)
     - `page_type` (enum: `homepage` | `service` | `location` | `blog` | `other` | `unknown`)
     - `top_ranking_keywords` (array of strings — keywords where this page ranks in positions 1–30, from GSC)
     - `current_best_position` (number — best ranking position across the top_ranking_keywords)
     - `has_schema` (boolean)
     - `is_indexable` (boolean)
     - `last_updated` (ISO date string, if known)
   - If site crawl data is not available, caller should indicate `crawl_data_available: false` and the skill will produce a roadmap assuming no existing pages cover the keywords — but flag this heavily in the output, since it significantly raises the risk of ranking displacement

4. **GSC existing-ranking map** (object, strongly recommended)
   - Maps each approved keyword to: `current_page_url` (string or null), `current_position` (number or null)
   - Required for the "don't break what's working" check to function accurately
   - If not provided, the skill falls back to the `top_ranking_keywords` field in the site crawl data, which is less reliable

5. **Cycle constraints** (optional object)
   - `max_new_pages` (number, default 4) — cap on new pages proposed for the cycle
   - `max_page_optimizations` (number, default 3) — cap on existing pages to optimize this cycle
   - `max_consolidations` (number, default 2) — cap on consolidation/redirect operations proposed this cycle
   - Rationale: MVP throughput is limited; the skill should plan within realistic capacity

6. **MD/MC constraints** (optional object)
   - `services_to_deprioritize` (array of service names — partner is phasing these out)
   - `services_to_emphasize` (array of service names — partner wants extra focus this cycle)
   - `pages_off_limits` (array of URLs — existing pages that cannot be modified this cycle, e.g. homepage during brand refresh)
   - `preferred_publish_cadence` (enum: `front_loaded` | `even` | `back_loaded` — default `even`)

## Output format

Return a single JSON object with this structure:

```json
{
  "cycle_summary": {
    "total_new_pages": "integer",
    "total_optimizations": "integer",
    "total_consolidations": "integer",
    "clusters_covered": "integer",
    "flagged_conflicts_count": "integer"
  },

  "page_roadmap": [
    {
      "roadmap_item_id": "string (e.g. 'roadmap-01')",
      "action": "create_new | optimize_existing | consolidate_redirect",
      "status": "proposed",
      "priority": "critical | high | medium | low",
      "cluster_name": "string (from keyword research)",
      "primary_keyword": "string",
      "secondary_keywords": ["array of strings"],
      "target_url": "string (for create_new and consolidate_redirect — the intended final URL)",
      "existing_url": "string (for optimize_existing and consolidate_redirect — the current page)",
      "redirect_from": ["array of URLs (for consolidate_redirect — all URLs being merged)"],
      "redirect_to": "string (for consolidate_redirect — the surviving URL)",
      "page_type": "homepage | service | location | blog | pillar | other",
      "word_count_target": "integer (800-1500 for service, 1000-2000 for blog, etc.)",
      "recommended_cycle_month": "integer 1-6",
      "rationale": "string (2-3 sentences explaining why this action was chosen over alternatives)",
      "preserve_signals_note": "string (for consolidate_redirect and optimize_existing — explicit note about what ranking signals are being preserved and how)"
    }
  ],

  "internal_linking_plan": [
    {
      "source_page": "string (URL or 'new: roadmap-XX' reference)",
      "destination_page": "string (URL or 'new: roadmap-XX' reference)",
      "suggested_anchor_text": "string",
      "anchor_text_variants": ["array of 2-3 alternatives for anchor rotation"],
      "placement_context": "string (e.g. 'first paragraph', 'in Services section', 'closing CTA')",
      "rationale": "string (why this link matters)"
    }
  ],

  "faq_bank_by_cluster": [
    {
      "cluster_name": "string",
      "faqs": [
        {
          "question": "string",
          "suggested_answer_direction": "string (1-2 sentences guiding the answer — not the answer itself)",
          "source": "paa_derived | service_knowledge | competitor_gap | partner_specific"
        }
      ]
    }
  ],

  "displacement_conflicts": [
    {
      "keyword": "string",
      "existing_ranking_page": "string (URL)",
      "existing_position": "number",
      "proposed_new_page_roadmap_id": "string",
      "recommended_resolution": "optimize_existing | consolidate | create_new_and_redirect_old | defer_to_next_cycle",
      "rationale": "string"
    }
  ],

  "skill_notes": {
    "partner_type": "string",
    "crawl_data_available": "boolean",
    "gsc_ranking_map_available": "boolean",
    "cycle_constraints_applied": "object (echoes the cycle_constraints input)",
    "keywords_not_covered_this_cycle": ["array of strings — approved keywords that didn't make it into the roadmap, with one-line reasons"],
    "flags_for_engineer_review": ["array of strings"]
  }
}
```

## Execution procedure

Follow these steps in order.

1. **Load the decision rules** at `rules/page_action_decision_tree.md`. This file contains the authoritative logic for choosing between create-new, optimize-existing, and consolidate-redirect.

2. **Build a keyword-to-existing-page map.** For each approved keyword in the input:
   - If the GSC existing-ranking map is provided, use it directly
   - Otherwise, search the site crawl data for a page whose `top_ranking_keywords` includes the keyword (or a close variant)
   - Tag each keyword as one of: `no_existing_page`, `existing_page_ranking_striking_distance` (positions 11–30), `existing_page_ranking_top_10`, `existing_page_ranking_beyond_30`, or `existing_page_not_ranking_yet`

3. **Run the "don't break what's working" check** for every approved keyword. For each keyword:
   - If an existing page ranks in the top 10 for this keyword: DO NOT propose a new page for the same keyword. The default action is `optimize_existing`. Any other action must be explicitly justified and logged in `displacement_conflicts`.
   - If an existing page ranks in positions 11–30 (striking distance): default action is `optimize_existing`. A new page only makes sense if the existing page is fundamentally the wrong target (e.g. a homepage ranking for a specific service keyword that deserves its own service page). In that case, the action becomes `create_new_and_redirect_old`.
   - If no existing page ranks for the keyword: default action is `create_new`, subject to cluster-level batching (see step 5).
   - If an existing page is ranking for the keyword but is thin (under 500 words) and poorly structured: default action is `consolidate_redirect` — the new substantive page absorbs the old thin page via 301.

4. **Apply MD/MC constraints** if provided:
   - Any keyword cluster whose primary service is in `services_to_deprioritize` gets its max roadmap items cut in half (or removed if only 1 item would be proposed)
   - Any keyword cluster whose primary service is in `services_to_emphasize` gets priority for roadmap inclusion
   - Any proposed action against a URL in `pages_off_limits` is replaced with `defer_to_next_cycle` and logged in `displacement_conflicts`

5. **Cluster-level batching and pillar-cluster structure:**
   - Review the cluster structure from the keyword research input
   - For each cluster with multiple high-opportunity keywords, decide whether to:
     - Create a single substantive page targeting the cluster's primary keyword, with secondary keywords addressed as H2/H3 subsections
     - Create a pillar page + cluster pages structure (pillar for the broad service, cluster pages for specific variants) — use this when the cluster has 5+ keywords with distinct subtopics
     - Spread across multiple geographic variants (e.g. one service page + location pages for each service area)
   - The decision is shaped by the partner type:
     - Hyper-local partners typically get one page per service, with secondary keywords as subsections. Location pages are less necessary when the service area is a single city.
     - Multi-city local partners often need a service page + location pages per city for the primary services
     - Regional partners may need pillar-cluster structures to cover broad service categories

6. **Apply cycle constraints (capacity limits):**
   - Sort all proposed roadmap items by priority × opportunity (pulling opportunity from the keyword research scores)
   - Trim to the caps: `max_new_pages`, `max_page_optimizations`, `max_consolidations`
   - Keywords that don't make the cut get added to `skill_notes.keywords_not_covered_this_cycle` with a one-line reason and suggestion for next cycle

7. **Assign cycle months.** Distribute roadmap items across cycle months 1–6 based on `preferred_publish_cadence`:
   - `front_loaded`: 60% of new pages in months 2–3, remainder in 4–5 (content in month 1 is reserved for strategy finalization, not production)
   - `even`: roughly even across months 2–5
   - `back_loaded`: 60% of new pages in months 4–5
   - Optimizations typically happen in the same month as the related new page, or earlier if they're independent quick wins
   - Consolidations should happen in month 2 to minimize risk of the old URL being re-crawled in an ambiguous state

8. **Generate the internal linking plan.** For each pair of roadmap items that share a cluster or topic relationship:
   - Propose 1–2 links between them with suggested anchor text
   - Include links from existing high-authority partner pages (homepage, top-performing service page) to new pages where appropriate
   - Rotate anchor text variants so no destination has 100% exact-match anchors
   - Typical internal linking plan for a cycle with 4 new pages + 3 optimizations: 12–20 planned links

9. **Generate the FAQ bank per cluster.** For each cluster covered in the roadmap:
   - Propose 6–10 FAQ questions with answer directions (NOT the answers themselves — those are the body content skill's job)
   - FAQs should cover: pricing questions, "how to choose" questions, timeline/duration questions, warranty/guarantee questions, common objections
   - Source each FAQ as either: `paa_derived` (from People Also Ask data if available), `service_knowledge` (common questions for the service type), `competitor_gap` (questions competitors answer poorly), or `partner_specific` (questions about the partner's differentiators)

10. **Populate the output JSON** with all roadmap items, displacement conflicts, linking plan, FAQ bank, and skill notes. The `flags_for_engineer_review` should highlight:
    - Any consolidation/redirect decisions (these carry the highest risk — engineer should confirm before execution)
    - Any case where a proposed new page might conflict with an existing ranking page not yet surfaced in the data
    - Any cluster where the capacity cap forced significant keywords to be deferred
    - Any case where the skill had to make a judgment call that would benefit from MD/MC review (e.g. priority service has fewer roadmap items than expected due to difficulty or overlap with competitors)

## The don't-break-what's-working principle

This is the most important rule in the skill. When an existing partner page already ranks for a target keyword — especially if it's in the top 10 — creating a new page that targets the same keyword splits ranking signal between the two URLs, typically resulting in both ranking worse than the original did alone.

The skill's default bias is toward optimizing the existing ranking page rather than replacing it. Override this bias only when:

- The existing page is fundamentally the wrong target (e.g. a homepage ranking #7 for "emergency plumbing service" — the right target is a dedicated service page, and the homepage ranking will gracefully transfer once the new page gets internal links and the homepage de-emphasizes the keyword)
- The existing page is thin (under 500 words) and broken enough that consolidation is clearly better than optimization
- The partner's URL structure needs a specific change that requires a new URL (e.g. moving from `/services/page-45/` to `/services/roof-repair/`) — in which case the action is `create_new_and_redirect_old`, not `create_new` alone

In every override case, the `preserve_signals_note` field must document how ranking signals are being protected: what 301 redirects are planned, what internal links will be updated, what timeline applies.

## Constraints and guardrails

- **Never propose a new page without checking for existing rankings.** Every `create_new` action must have a corresponding `keyword-to-existing-page` lookup result of `no_existing_page` or `existing_page_ranking_beyond_30`. Any other state requires a different action.
- **Never propose a redirect without an explicit preserve_signals_note.** Consolidation and redirect carry the highest risk in the skill's outputs. Every one needs a deliberate plan for how ranking signals survive the transition.
- **Respect the capacity caps.** If the roadmap would exceed `max_new_pages`, `max_page_optimizations`, or `max_consolidations`, trim to the caps rather than exceeding them. Document deferred items in `keywords_not_covered_this_cycle`.
- **Never invent pages that don't exist in the crawl data.** If the caller hasn't provided crawl data, the skill's assumption is that no existing pages cover the keywords — which is often wrong. Flag this heavily rather than guessing at what pages might exist.
- **Preserve the FAQ bank's role as answer direction, not full answers.** FAQ suggested answers should be 1–2 sentences guiding the answer direction. Full answers are the body content skill's job and require partner-specific knowledge (pricing ranges, specific certifications, warranty terms) that this skill doesn't have.
- **Don't generate title tags, meta descriptions, schema markup, or body copy.** All of that is downstream of this skill. Outputs here feed into `seo-technical-package` for the technical wrapper and `seo-body-content` for the page copy.

## Reference files

The skill includes these reference files, loaded on demand when their content is needed:

- `rules/page_action_decision_tree.md` — authoritative decision logic for create/optimize/consolidate choices
- `rules/clustering_patterns.md` — patterns for deciding between single-page, pillar-cluster, and geographic-variant structures
- `examples/multi_city_roadmap_example.json` — worked example for a Denver-metro roofer, chained from the keyword research multi-city example
- `examples/consolidation_example.json` — worked example showing a consolidation/redirect decision with ranking preservation
