# Clustering Patterns

Reference for deciding how to structure pages around keyword clusters. When to use single-page coverage, pillar-cluster structures, or geographic-variant rollouts — shaped by partner type and cluster characteristics.

---

## The three main structural patterns

### Pattern 1: Single-page cluster coverage

**Use when**: A cluster has 3–6 keywords that all map to the same service and user intent, and the primary keyword has enough search volume to justify a dedicated page.

**Structure**: One substantive page (1,000–1,500 words for service pages) targeting the primary keyword. Secondary keywords addressed as H2/H3 subsections within the same page.

**Example**: The cluster "Water Heater Services" with keywords:
- water heater repair Boulder (primary)
- water heater installation Boulder (secondary, subsection)
- tankless water heater Boulder (secondary, subsection)
- water heater not working (supporting, within body)
- water heater repair cost (supporting, cost guide subsection)

One page: `/services/water-heater-repair/` with H2 sections for installation, tankless options, troubleshooting, and pricing.

**When NOT to use**: If secondary keywords have materially different intents (e.g. "water heater repair" is commercial/transactional, "how does a water heater work" is informational) — those deserve separate pages or separate content types.

### Pattern 2: Pillar + cluster pages

**Use when**: A cluster has 7+ keywords spanning multiple subtopics with distinct user intents, AND the primary service category is broad enough that no single page can cover it well.

**Structure**: One pillar page (1,500–3,000 words) covering the broad service at a high level, plus 2–5 cluster pages (800–1,500 words each) covering specific subtopics in depth. Pillar and cluster pages link to each other.

**Example**: "Roofing Services" cluster for a regional partner:
- Pillar: `/services/roofing/` — overview of all roofing services, links to cluster pages
- Cluster: `/services/roofing/roof-repair/` — targets "roof repair" variants
- Cluster: `/services/roofing/roof-replacement/` — targets "roof replacement" variants
- Cluster: `/services/roofing/gutter-services/` — targets gutter-related keywords
- Cluster: `/services/roofing/storm-damage/` — targets storm damage and emergency keywords

**When NOT to use**: When the partner is hyper-local and the service category is narrow enough that a pillar page would just be a thin summary of the cluster pages. Better to pick the most important cluster page as the primary landing page.

### Pattern 3: Service + geographic variants

**Use when**: A multi-city local partner or regional partner has the same service offered across multiple cities, and each city has its own search volume and competitive landscape.

**Structure**: One core service page covering the service generally, plus one location page per priority city where the service is offered. Location pages include genuine local differentiation — project examples, local regulations, neighborhood-specific context — not just city-name swaps.

**Example**: Denver-metro roofer, "Roof Repair" service:
- Core service page: `/services/roof-repair/` — targets "roof repair Denver" (primary metro) and general service content
- Location page: `/service-areas/aurora/roof-repair/` — targets "roof repair Aurora CO"
- Location page: `/service-areas/lakewood/roof-repair/` — targets "roof repair Lakewood"
- Location page: `/service-areas/arvada/roof-repair/` — targets "roof repair Arvada"

**When NOT to use**: When all service areas have low search volume individually (under 50/month) — location pages often don't justify their production cost in that case. Better to serve the multi-city coverage through a strong service page with a location-listing section.

**Risk flag**: Location pages are the most common source of near-duplicate content issues. If each location page is just the service page with the city name swapped in, Google recognizes the pattern and either refuses to rank them or ranks them weakly. Every location page must have:
- City-specific project examples or testimonials
- Neighborhood-specific or local regulatory context
- Local address and NAP variations (if the partner has multiple physical locations)
- Unique H1 and unique first paragraph

---

## Decision matrix by partner type and cluster size

| Partner type | Cluster size (keyword count) | Recommended pattern |
|---|---|---|
| Hyper-local | 1–4 keywords | Single-page coverage |
| Hyper-local | 5–10 keywords | Single-page coverage (aggressive subsection use) OR pillar + 2 cluster pages for highest-opportunity subtopics |
| Hyper-local | 10+ keywords | Unusual for hyper-local; likely the cluster is over-broad and should be split by the keyword research skill before strategy runs |
| Multi-city local | 1–3 keywords | Single-page coverage |
| Multi-city local | 4–8 keywords | Single-page coverage + geographic variants if geography is distinct, otherwise single page |
| Multi-city local | 8+ keywords | Pillar + cluster pages, with geographic variants on the cluster pages for priority cities |
| Regional | 1–4 keywords | Single-page coverage |
| Regional | 5–10 keywords | Pillar + cluster pages |
| Regional | 10+ keywords | Pillar + cluster pages + geographic variants |

---

## When clusters should be split or merged

### Split a cluster into multiple pages when:

- Keywords in the cluster have distinct user intents (some transactional, some informational) — split by intent
- Keywords fall into different services (a cluster titled "Roofing" that includes both "roof repair" and "gutter installation" is too broad — split by service)
- A subset of keywords has meaningfully different geographic coverage (e.g. partner offers roof repair everywhere but only offers tile roofing in two cities — tile roofing gets its own page targeting those two cities)

### Merge clusters (or represent with fewer pages) when:

- Two clusters both target the same primary service but differ only in modifier (e.g. "Roof Repair Emergency" and "Roof Repair Services" — one page can cover both with subsections)
- Cluster-level keyword volume is very low (under 100/month total across all keywords in the cluster) — a dedicated page may not be justified; fold the cluster into a related larger page

---

## Internal linking patterns by structure

### For single-page cluster coverage
- 2–4 internal links from the page to related service pages, pillar pages, or blog posts
- 1–2 links from the homepage to the primary service page in this cluster
- Links from related service pages (for cross-sell) where appropriate

### For pillar + cluster pages
- Every cluster page links to the pillar page (usually in the introduction and closing CTA)
- Pillar page links to all cluster pages (in a structured "Services We Offer" or similar section)
- Cluster pages link to 1–2 related cluster pages (e.g. roof repair page links to roof replacement page as "upgrade path")
- Homepage links to the pillar page, NOT directly to individual cluster pages (preserves the pillar's authority signal)

### For service + geographic variants
- Every location page links to the core service page ("Our [Service] Services" link in the header or intro)
- Core service page has a "Service Areas" section linking to all location pages
- Location pages link to other location pages for adjacent cities (with descriptive anchor text — "We also serve [adjacent city]")
- Homepage may link to core service pages but typically does NOT link to individual location pages (too many links would dilute the homepage's authority distribution)

---

## Common structural mistakes to avoid

- **Creating a pillar page that's too thin**: A pillar page under 1,500 words won't rank well for the broad service keyword. If the partner doesn't have enough to say for a substantive pillar, skip the pillar and use single-page cluster coverage instead.
- **Creating location pages without differentiation**: Near-duplicate location pages often rank worse than a single strong service page. If genuine local context isn't available, don't create the page.
- **Separating closely related keywords across pages**: Splitting "roof repair Denver" and "Denver roof repair" (which target the same SERP) across two pages is worse than consolidating them on one page.
- **Pillar-cluster structure for narrow services**: If the partner only offers 1–2 services, pillar-cluster doesn't make sense. Single-page coverage per service is the right structure.
- **Ignoring intent when clustering**: Two keywords that target different SERP types (one dominated by commercial pages, one by informational blog posts) should not share a page even if they share the same topic.
