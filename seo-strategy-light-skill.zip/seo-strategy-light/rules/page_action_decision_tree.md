# Page Action Decision Tree

Authoritative decision logic for choosing between `create_new`, `optimize_existing`, `consolidate_redirect`, and `create_new_and_redirect_old` for each approved keyword. When the main SKILL.md is ambiguous, this file is the source of truth.

---

## The core decision tree

For each approved keyword, walk through this decision tree in order. The first matching condition determines the action.

```
Is there an existing partner page ranking for this keyword?
│
├── No, keyword not ranking for any partner page
│   │
│   └── Is a sibling keyword in the same cluster already covered by an existing page?
│       │
│       ├── Yes → optimize_existing (expand the sibling page to cover this keyword)
│       │
│       └── No → create_new
│
├── Yes, ranking in positions 1–10 (top of page 1)
│   │
│   └── Default: optimize_existing (never displace a top-10 ranking page without strong cause)
│       │
│       └── EXCEPTION: The existing page is a fundamentally wrong target
│           (e.g. homepage ranking for a specific service keyword)
│           → create_new_and_redirect_old (only with explicit justification)
│
├── Yes, ranking in positions 11–30 (striking distance)
│   │
│   └── Is the existing page thin (<500 words) or structurally poor?
│       │
│       ├── Yes → consolidate_redirect (build a substantive new page, 301 the old one)
│       │
│       └── No → optimize_existing (improve title/meta/content/links on the existing page)
│
├── Yes, ranking beyond position 30 (technically ranking but not meaningfully)
│   │
│   └── Is the existing page still the right page type for this keyword?
│       │
│       ├── Yes → optimize_existing or consolidate_redirect (based on content quality)
│       │
│       └── No → create_new (treat the distant ranking as not material — the new page will outrank it)
│               PLUS: add the old URL to the redirect plan once new page is indexed
│
└── Yes, ranking but position data unclear
    │
    └── Flag for engineer review. Do not propose an action until ranking clarity is established.
```

---

## Key thresholds

- **Top 10** — positions 1–10. Preserving these rankings is the highest priority. Default is always optimize unless structural reasons force a different action.
- **Striking distance** — positions 11–30. These are high-ROI optimization targets. Moving from position 15 to position 5 produces meaningful traffic gains and is typically achievable with on-page work alone.
- **Thin content threshold** — under 500 words. Pages below this threshold are candidates for consolidation rather than optimization, because the content effort required to bring them up to ranking-competitive length (1,000–1,500 words for service pages) is roughly equivalent to creating a new page.
- **Not ranking threshold** — beyond position 30 OR not appearing in GSC data at all. Treated as "not ranking" for action decisions.

---

## When to use each action

### `create_new`

**Use when**: No existing partner page ranks for the keyword, AND no sibling keyword in the same cluster is already covered by an existing page that could be expanded.

**Output requirements**:
- `target_url` (the intended URL for the new page)
- `primary_keyword` and `secondary_keywords`
- `page_type` and `word_count_target`
- `recommended_cycle_month`
- Rationale explaining why a new page is the right action (vs. expanding an existing page)

**Risk level**: Low. Creating new pages doesn't threaten existing rankings.

### `optimize_existing`

**Use when**: An existing partner page ranks for the keyword (positions 1–30), AND the page is structurally sound (over 500 words, correct page type, not broken) — regardless of whether it's in the top 10 or striking distance.

**Output requirements**:
- `existing_url` (the URL to optimize)
- `primary_keyword` (what's being targeted)
- Specific optimization thesis (what's being changed — title rewrite for CTR, add schema, expand content, add internal links, add FAQ section, etc.)
- `preserve_signals_note` documenting that the URL is unchanged and ranking signals are protected

**Risk level**: Low to moderate. Optimizing an existing page occasionally causes short-term ranking wobbles (especially title rewrites), but rarely causes cliff drops.

### `consolidate_redirect`

**Use when**: An existing thin page (under 500 words) ranks for a keyword in striking distance, AND building a substantive new page targeting the same keyword is preferable to trying to expand the thin page in place.

**Output requirements**:
- `target_url` (where the new substantive page will live)
- `redirect_from` (array of URLs being merged, including the old thin page)
- `redirect_to` (the surviving URL — same as `target_url`)
- `primary_keyword` and `secondary_keywords`
- `preserve_signals_note` documenting the 301 plan and timeline

**Risk level**: Moderate. Redirects are a high-leverage operation — done well, they transfer ranking signals cleanly. Done poorly (wrong redirect target, broken redirect chains, old URLs left unredirected), they cause significant ranking drops.

**Mandatory protocol for consolidation**:
1. New substantive page is built and published first
2. New page is crawled and indexed by Google (typically 2–7 days)
3. 301 redirect from old URL to new URL is implemented
4. Internal links across the site are updated to point directly to the new URL (not via the redirect)
5. Old URL is monitored for 30 days post-redirect to confirm traffic transfers

### `create_new_and_redirect_old`

**Use when**: An existing page ranks for the keyword but is fundamentally the wrong target type (e.g. homepage ranking for a specific service keyword that deserves its own dedicated service page), AND a new page at a different URL is the correct long-term structure.

**Output requirements**:
- Same as `create_new` PLUS `preserve_signals_note` and redirect plan for the old URL
- Explicit justification for why the old page is the wrong target (not just "we want a new page")

**Risk level**: High. This is the action most likely to cause ranking displacement if executed poorly. Reserve for cases where the existing URL structure is genuinely wrong.

**Mandatory protocol**:
1. New page is built and published
2. New page gets internal links from the homepage or top-tier service pages to build authority
3. Old page's content covering this keyword is removed or de-emphasized (so it's no longer a ranking target for this keyword)
4. Monitor rankings for 4–8 weeks — the transfer is often not clean for keywords where both old and new pages have some relevance
5. Only implement a full 301 redirect from old to new if (a) the old page has no other ranking keywords worth preserving, or (b) the new page successfully takes over the ranking

---

## Edge cases and disambiguation

### Edge case: Existing page ranks for the keyword but is on the wrong URL

**Scenario**: Partner has a page at `/about-us/services-we-offer/` ranking #9 for "roof repair Denver." The correct URL structure would be `/services/roof-repair/`.

**Decision**: `create_new_and_redirect_old`. Build the new page at the correct URL, migrate content, implement 301 redirect from the old URL after the new page is indexed.

**Risk**: High. The old page is already ranking well, and forcing a URL change can cause temporary ranking drops. Only do this if URL structure matters for the partner's long-term SEO strategy.

### Edge case: Multiple existing pages rank for related keywords in the same cluster

**Scenario**: Partner has `/services/roof-repair/` ranking #12 for "roof repair Denver" and `/services/emergency-roof/` ranking #18 for "emergency roof repair Denver." These two keywords are in the same cluster.

**Decision**: Evaluate whether the two pages are distinct services or should be consolidated:
- If they serve genuinely different user intents (repair vs. emergency), keep both and optimize each
- If they cover overlapping ground with shallow differentiation, consolidate into one substantive page (likely `/services/roof-repair/`) with emergency repair as an H2 subsection
- Never create a third page targeting either keyword when two already exist

### Edge case: Existing page ranks for the keyword but the page is in `pages_off_limits`

**Scenario**: Homepage ranks for a service keyword, but homepage is off-limits this cycle (brand refresh in progress).

**Decision**: `defer_to_next_cycle`. Log the keyword in `keywords_not_covered_this_cycle` with the reason "existing ranking page is off-limits this cycle." Do NOT propose a new page targeting the same keyword while the homepage ranking is still active.

### Edge case: Keyword has `is_striking_distance: true` but no existing page data

**Scenario**: Keyword research flagged the keyword as striking distance (positions 11–30), but the site crawl data or GSC existing-ranking map doesn't identify which page is ranking.

**Decision**: Flag for engineer review. Do not propose an action. Missing data here risks proposing a `create_new` that would displace an unidentified ranking page. Action is `flag_for_review` with a note: "Keyword is in striking distance but ranking page is unidentified. Engineer must confirm page before action is assigned."

### Edge case: Two approved keywords target the same existing page

**Scenario**: Two keywords from keyword research both map to `/services/roof-repair/`. Both are in striking distance.

**Decision**: One `optimize_existing` action covers both keywords. Include both in `primary_keyword` + `secondary_keywords` of the same roadmap item. Don't create two separate roadmap items for the same page.

### Edge case: Consolidation would merge pages across different service categories

**Scenario**: A thin `/services/roof-repair/` page ranks for both "roof repair Denver" AND "gutter installation Denver" (the page is semi-generic and mentions multiple services).

**Decision**: Do NOT consolidate into a single page — the two keywords belong to different services and deserve distinct pages. Instead:
- Build a new substantive roof repair page
- Build a new substantive gutter installation page (or optimize an existing one if it exists elsewhere)
- The thin generic page can either be redirected to a services hub page or kept as a lighter overview that links to both new pages

---

## Summary table: action by ranking position and content quality

| Existing ranking position | Existing content quality | Action |
|---|---|---|
| Not ranking | Any | `create_new` |
| 1–10 | Any | `optimize_existing` (default — override requires strong justification) |
| 11–30 | Substantive (500+ words, correct structure) | `optimize_existing` |
| 11–30 | Thin (<500 words) or structurally poor | `consolidate_redirect` |
| 11–30 | On wrong URL structure | `create_new_and_redirect_old` |
| Beyond 30 | Substantive | `optimize_existing` |
| Beyond 30 | Thin | `create_new` (treat the distant ranking as non-material) |
| Ranking but data unclear | Any | `flag_for_review` |
